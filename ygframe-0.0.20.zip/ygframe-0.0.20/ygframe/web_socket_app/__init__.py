# -*- coding:utf-8 -*-
"""
-------------------------------------------------------------
File Name:.py
Aut
Author:long
Copyright:ht:yiguotech.com
dat
date:7/20/19 4:35 PM
-------------------------------------------------------------
"""
import asyncio
import json
import threading
import time

import tornado.websocket
from setuptools import find_packages
from tornado.web import Application

from queue import Empty
from ygframe.logger import logger
from ygframe.redis_wrapper import get_redis_conn
from ygframe.util.import_util import get_all, module_exists


class YgWebSocket(tornado.websocket.WebSocketHandler):
    @property
    def chatroom(self):
        return self.application.chat_room


class YgWeb(tornado.web.RequestHandler):
    pass


class ChatRoom(object):
    chat_container = {}
    chat_stats = {}
    r_conn = get_redis_conn()
    REDIS_QUEUE_KEY = 'websocket_msg_queue'

    def __init__(self):
        threading.Thread(target=self.get_queue).start()

    def init_stats_item(self, key):
        return {'key': key, 'message': 0}

    def register(self, ws_handler, key):
        try:
            ws_handler_set = self.chat_container.get(key)
            if ws_handler_set:
                self.chat_container[key].add(ws_handler)
            else:
                ws_handler_set = set()
                ws_handler_set.add(ws_handler)
                self.chat_container[key] = ws_handler_set
            logger.info('new connection registered, key: {} / chat_container size: {} / key handler size: {}'.
                        format(key, len(self.chat_container), len(ws_handler_set)))

        except Exception as e:
            logger.exception(str(e))

    def unregister(self, key, ws_handler):
        try:
            ws_handlers_set = self.chat_container.get(key)
            if ws_handlers_set:
                ws_handlers_set.remove(ws_handler)
            logger.info('connection closed, key: {} / key handler size: {}'.
                        format(key, len(ws_handlers_set)))

        except Exception as e:
            logger.exception(str(e))

    @classmethod
    def put_task(cls, key, msg):
        data = {key: msg}
        if not cls.r_conn:
            cls.r_conn = get_redis_conn()
        cls.r_conn.rpush(cls.REDIS_QUEUE_KEY, json.dumps(data).encode(encoding="utf-8"))

    def get_queue(self):
        new_loop = asyncio.new_event_loop()
        asyncio.set_event_loop(new_loop)
        while True:
            try:
                _value = self.r_conn.blpop(self.REDIS_QUEUE_KEY, timeout=60)
                if _value:
                    value = json.loads(_value[1].decode(encoding="utf-8"))
                    for client_key, msg in value.items():
                        ws_handler_set = self.chat_container.get(client_key)
                        error_ws_handler = []
                        if ws_handler_set:
                            # 有时候ws_handler_set会被改变，这里要重试
                            for i in range(3):
                                try:
                                    for ws_handler in ws_handler_set:
                                        try:
                                            ws_handler.write_message(msg)
                                            logger.info(
                                                'client key: {}, websocket: {}, send message {} success'.format(
                                                    client_key,
                                                    ws_handler,
                                                    msg))
                                        except Exception as e:
                                            logger.error(e)
                                            try:
                                                error_ws_handler.append(ws_handler)
                                            except Exception as e:
                                                logger.error(e)
                                    break
                                except Exception as e:
                                    logger.exception(str(e))
                                    time.sleep(1)

                            for ws_handler in error_ws_handler:
                                try:
                                    logger.info('remove {} due to send message failed.'.format(ws_handler))
                                    ws_handler_set.remove(ws_handler)
                                except Exception as e:
                                    logger.error(e)
                        else:
                            logger.info('ws_handler_set is null ws_handler_set_key={}'.format(client_key))
                else:
                    logger.info('websocket_msg_queue queue is empty')
            except Empty:
                logger.info('websocket_msg_queue queue is empty')
            except Exception as e:
                try:
                    logger.exception(e)
                    time.sleep(1)
                    self.r_conn = get_redis_conn()
                except Exception as e:
                    pass

    @classmethod
    def get_connection(cls, key):
        return cls.chat_container.get(key)


class RegisterApplication(Application):
    def __init__(self, handlers, tornado_settings):
        super(RegisterApplication, self).__init__(handlers, **tornado_settings)
        self.chat_room = ChatRoom()


def get_web_socket_resource():
    if not module_exists('api'):
        return []

    for version in find_packages('api'):
        if '.' in version or not version.startswith('v'):
            continue
        for resource in get_all('api.' + version, YgWebSocket):
            if resource == YgWebSocket:
                continue
            yield resource, version


def get_web_resource():
    if not module_exists('api'):
        return []

    for version in find_packages('api'):
        if '.' in version or not version.startswith('v'):
            continue
        for resource in get_all('api.' + version, YgWeb):
            if resource == YgWeb:
                continue
            yield resource, version
