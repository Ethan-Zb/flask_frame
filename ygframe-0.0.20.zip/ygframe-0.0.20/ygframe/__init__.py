# -*- coding:utf-8 -*-
#
# Author:jing
# Copyright:yiguotech.com
# date:2018/05/06
import threading
from multiprocessing import Manager

from ygframe.abstract_system_config import AbstractSystemConfig

__author__ = 'jing'
__version__ = '0.0.20'
__copy_right__ = 'yiguotech.com'

# from ygframe.util.ascii_util import colored_print
print("""

version: {}

""".format(__version__))

try:
    module = __import__('system_config').SYSTEM_CONFIG
    if isinstance(module, AbstractSystemConfig):
        SYSTEM_CONFIG = module
    else:
        raise AttributeError

except (ImportError, AttributeError):
    SYSTEM_CONFIG = AbstractSystemConfig()

shared_memory = Manager()
thread_local = threading.local()
