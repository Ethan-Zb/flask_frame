# -*- coding:utf-8 -*-
#
# Author:jing
# Copyright:yiguotech.com
# date:2018/05/06

# pylint:disable=missing-docstring
import collections

__author__ = 'jing'


def flatten_dict(data_dict: dict, separator: str = '/') -> dict:
    """
    :param data_dict: the original dict data
    :param separator: key separator
    :return: convert a structured dict to a flatten dict.
    """
    result = {}
    for key, value in data_dict.items():
        pre_key = separator + key
        if isinstance(value, dict):
            sub_flatten = flatten_dict(value, separator)
            for sub_key, sub_value in sub_flatten.items():
                result[pre_key + sub_key] = sub_value
        else:
            result[pre_key] = value
    return result


def structured_dict(flat_data: dict, separator: str = '/'):
    """
    :param flat_data: the original flatten dict data
    :param separator: key separator
    :return: convert a flatten dict dict to a structured dict.
    """
    result = {}
    for key, value in flat_data.items():
        key_list = key.split(separator)
        length = len(key_list)
        sub = result
        for i, k in enumerate(key_list):
            if k:
                if i < length - 1:
                    if k not in sub:
                        sub[k] = dict()
                        sub = sub[k]
                    else:
                        sub = sub[k]
                else:
                    sub[k] = value
    return dict(result)


def deep_update(orig_dict, new_dict):
    for key, val in new_dict.items():
        if isinstance(val, collections.Mapping):
            tmp = deep_update(orig_dict.get(key, {}), val)
            orig_dict[key] = tmp
        elif isinstance(val, list):
            orig_dict[key] = (orig_dict.get(key, []) + val)
        else:
            orig_dict[key] = new_dict[key]
    return orig_dict


def get_dict(*args, **kwargs):
    if not args and not kwargs:
        return {}
    if len(args) == 1 and not kwargs and isinstance(args[0], dict):
        return args[0]
    if kwargs and not args:
        return kwargs

    raise ValueError('neither a dict nor a **kwargs')
