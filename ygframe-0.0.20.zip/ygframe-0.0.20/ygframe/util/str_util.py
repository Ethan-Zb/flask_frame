# -*- coding:utf-8 -*-
#
# Author:jing
# Copyright:yiguotech.com
# date:2018/05/06
"""str util"""
import difflib
import re

from ygframe.util.ascii_util import FormatCode

__author__ = 'jing'


def get_between(
        target: str,
        left: str = None,
        right: str = None,
        include_left=False,
        include_right=False,
) -> str:
    """
    :param target: origin str
    :param left: left substring
    :param right: right substring
    :param include_left: left append to left
    :param include_right: right append to right
    :return: substring in target between left and right
    """
    left_index = 0
    right_index = None
    if left:
        left_index = target.index(left) + len(left)
    if right:
        right_index = target.index(right, left_index)

    if right_index is None:
        between = target[left_index:]
    else:
        between = target[left_index:right_index]
    return '{}{}{}'.format(
        left if include_left else '',
        between,
        right if include_right else ''
    )


def get_all_between(
        target: str,
        left: str = None,
        right: str = None,
        include_left=False,
        include_right=False
):
    """
    get all substring in target between left and right
    """
    remain = target
    result = []
    if left is None or right is None:
        return [get_between(target, left, right, include_left, include_right)]

    while remain and (left in remain) and (right in remain):
        between = get_between(remain, left, right, include_left, include_right)
        result.append(between)
        next_left = left + between + right
        remain = get_between(remain, left=next_left)
    return result


def split(
        target: str,
        sub: str,
        merge_to_left: bool = False,
        merge_to_right: bool = False,
        with_sub: bool = False
):
    """split string with substring"""
    index = target.index(sub)
    mindex = index + len(sub)
    if merge_to_left:
        return target[0:mindex], target[mindex:]
    if merge_to_right:
        return target[0:index], target[index:]
    if with_sub:
        return target[0:index], sub, target[mindex:]
    return target[0:index], target[mindex:]


def get_snake_case(name, separator='_'):
    """:return snake case of given string"""
    com = re.compile('((?<=[a-z0-9])[A-Z]|(?!^)[A-Z](?=[a-z]))')
    return com.sub(r'{}\1'.format(separator), name).lower()


def highlight(target, color=FormatCode.Red, reset=FormatCode.Color_Off):
    return color + target + reset


def get_similarity(str1, str2, exclude_function=None):
    seq = difflib.SequenceMatcher(exclude_function, str1, str2)
    return seq.ratio()
