# -*- coding:utf-8 -*-
#
# Author:jing
# Copyright:yiguotech.com
# date:2018/05/06
"""common file util"""
import os
import platform
import re
from contextlib import contextmanager
from stat import S_IRGRP, S_IROTH, S_IWGRP, S_IWOTH, S_IRUSR, S_IWUSR

__author__ = 'jing'

FILE_PATH_SEP_CHARS = '\\/'
FILE_PATH_SEP_REG = '[/|\\\\]'


def ensure_file(path: str):
    """if not exist, create one"""
    dir_path = re.split(FILE_PATH_SEP_REG, path)[0:-1]
    if dir_path:
        ensure_dir('/'.join(dir_path))
    if not os.path.isfile(path):
        with open(path, 'w'):
            pass
    return path


def ensure_dir(path: str):
    """if not exist, create one"""
    os.makedirs(path, exist_ok=True)
    return path


def make_read_only(file_name):
    """mark file as read only"""
    ensure_file(file_name)
    os.chmod(file_name, S_IRUSR | S_IRGRP | S_IROTH)


def remove_read_only(file_name):
    """remove read only flag"""
    ensure_file(file_name)
    os.chmod(file_name, S_IWUSR | S_IWGRP | S_IWOTH | S_IRUSR | S_IRGRP | S_IROTH)


def read_chunk(file_name, chunk_size=20 * 1024 * 1024):
    """chunk read file"""
    with open(file_name, 'rb') as target_file:
        while True:
            chunk = target_file.read(chunk_size)
            if not chunk:
                break
            yield chunk


@contextmanager
def protect_open(file_name: str, read_only=True):
    """context when edit read only file"""
    remove_read_only(file_name)
    with open(file_name, 'w') as file:
        yield file
    if read_only:
        make_read_only(file_name)


def get_creation_date(path_to_file):
    """
    Try to get the date that a file was created, falling back to when it was
    last modified if that isn't possible.
    See http://stackoverflow.com/a/39501288/1709587 for for explanation.
    """
    if platform.system() == 'Windows':
        return os.path.getctime(path_to_file)
    else:
        stat = os.stat(path_to_file)
        try:
            return stat.st_birthtime
        except AttributeError:
            # We're probably on Linux. No easy way to get creation dates here,
            # so we'll settle for when its content was last modified.
            return stat.st_mtime
