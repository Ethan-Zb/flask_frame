# -*- coding:utf-8 -*-
#
# Author:jing
# Copyright:yiguotech.com
# date:2018/05/06

# pylint:disable=missing-docstring,invalid-name
import json
from contextlib import contextmanager
from functools import partial

from ygframe.serialize.yg_encoder import loads, dumps

__author__ = 'jing'


@contextmanager
def serialized(
        source: dict,
        key: str, expect_type=dict,
        loads_method=json.loads,
        dumps_method=json.dumps
):
    value_str = source.get(key)
    value = loads_method(value_str) if value_str else expect_type()
    if not isinstance(value, expect_type):
        raise ValueError('value of {} is not a dict'.format(key))
    yield value
    source[key] = dumps_method(value)


yg_serialized = partial(serialized, loads_method=loads, dumps_method=dumps)
