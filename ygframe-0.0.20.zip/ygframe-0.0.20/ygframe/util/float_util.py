# -*- coding:utf-8 -*-
#
# Author:jing
# Copyright:yiguotech.com
# date:2018/05/06
"""float util"""

BIG_FLOAT = float("inf")
