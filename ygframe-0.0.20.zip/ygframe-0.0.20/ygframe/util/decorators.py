# -*- coding:utf-8 -*-
# File Name:decorators.py
# Author:jing
# Copyright:yiguotech.com
# date:2018/10/29

__author__ = 'jing'


def bind(func):
    def _wrapper(*args, **kwargs):
        return func(func, *args, **kwargs)

    return _wrapper
