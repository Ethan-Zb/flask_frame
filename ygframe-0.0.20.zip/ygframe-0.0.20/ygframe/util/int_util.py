# -*- coding:utf-8 -*-
#
# Author:jing
# Copyright:yiguotech.com
# date:2018/05/06

"""int util"""
import sys

__author__ = 'jing'

BIG_INT = sys.maxsize
