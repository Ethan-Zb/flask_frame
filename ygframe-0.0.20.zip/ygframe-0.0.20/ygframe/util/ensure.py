# -*- coding:utf-8 -*-
#
# Author:jing
# Copyright:yiguotech.com
# date:2018/05/06

"""
ensure value is given type.
"""
__author__ = 'jing'


def ensure_str(value) -> str:
    """ensure str"""
    if isinstance(value, bytes):
        return value.decode()
    return str(value)


def ensure_bytes(value) -> bytes:
    """ensure bytes"""
    if isinstance(value, bytes):
        return value
    return ensure_str(value).encode()


def ensure_list(value) -> list:
    """ensure list"""
    try:
        return list(value)
    except TypeError:
        return []
