# -*- coding:utf-8 -*-
#
# Author:jing
# Copyright:yiguotech.com
# date:2018/05/06
"""util that help to import or load python module programmatically"""
import traceback
from importlib import import_module

from werkzeug.utils import find_modules

from ygframe.logger import logger

__author__ = 'jing'


def chain_find_modules(*package_names):
    """find all modules in packages"""
    for package_name in package_names:
        if not module_exists(package_name):
            continue

        try:
            for module_name in find_modules(package_name, recursive=True):
                yield module_name
        except:  # pylint:disable=bare-except
            logger.info(traceback.format_exc())
            continue


def find_all(package_name):  # pylint:disable=inconsistent-return-statements
    """recursively find all modules"""
    if not module_exists(package_name):
        return
    try:
        for module_name in find_modules(package_name, recursive=True):
            logger.info('importing module: {}'.format(module_name))
            yield import_module(module_name)
    except:  # pylint:disable=bare-except
        logger.info(traceback.format_exc())
        return


def import_all(package_name):
    """import all module under the package"""
    if not module_exists(package_name):
        return
    for module in find_all(package_name):
        logger.info('imported {}'.format(module.__name__))


def get_all(package_name, class_type):
    """filter module in package with class_type"""
    for module in find_all(package_name):
        for attr in dir(module):
            if attr.startswith('__'):
                continue
            value = getattr(module, attr)
            if not isinstance(value, type):
                continue
            if issubclass(value, class_type) and value != class_type:
                yield value


def module_exists(module_name):
    try:
        __import__(module_name)
        return True
    except:
        return False

