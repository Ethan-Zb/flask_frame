# -*- coding:utf-8 -*-
#
# Author:jing
# Copyright:yiguotech.com
# date:2018/05/06
"""persistence util"""
from abc import abstractmethod

from ygframe.interface.handler_interface import HandlerInterface

__author__ = 'jing'


class PersistenceHandler(HandlerInterface):
    """base class"""

    @abstractmethod
    def reset(self, init_value=None):
        """reset value"""
        raise NotImplementedError

    @abstractmethod
    def save(self, value: str):
        """save value"""
        raise NotImplementedError

    @abstractmethod
    def load(self) -> str:
        """load value"""
        raise NotImplementedError

    @abstractmethod
    def delete(self):
        raise NotImplementedError
