# -*- coding:utf-8 -*-
#
# Author:jing
# Copyright:yiguotech.com
# date:2018/05/06

"""
backoff algorithm
"""
import random
from functools import partial

__author__ = 'jing'


def get_exponential_backoff(start: int = 1, max_wait_seconds: int = 600, jitter: bool = True):
    """
    :param start:
    :param max_wait_seconds:
    :param jitter:
    :return: a backoff function based on `exponential_backoff`
    """
    return partial(
        exponential_backoff,
        start=start,
        max_wait_seconds=max_wait_seconds,
        jitter=jitter
    )


def exponential_backoff(
        retry_turn: int,
        start: float = 1,
        max_wait_seconds: int = 180,
        jitter: bool = True
) -> float:
    """
    :param retry_turn: turn of retry
    :param start:  a number, if this option is set to 3, the first retry will delay 3 seconds,
    the second will delay 6 seconds, the third will delay 12 seconds, the fourth will delay 24
    seconds, and so on.
    :param max_wait_seconds: A number. If retry_backoff is enabled, this option will set a
    maximum delay in seconds between task retries. By default, this option is set to 600, which
    is 10 minutes.
    :param jitter: A boolean. Jitter is used to introduce randomness into exponential backoff
    delays, to prevent all tasks in the queue from being executed simultaneously. If this option
    is set to True, the delay value calculated by retry_backoff is treated as a maximum, and the
    actual delay value will be a random number between last and that maximum. By default, this
    option is set to True.
    :return: seconds to delay
    """
    multi = 1 << (retry_turn - 1)
    min_wait = min(start * (1 << retry_turn - 2), max_wait_seconds / 2) if retry_turn > 1 else 0
    max_wait = min(start * multi, max_wait_seconds)

    return random.randint(min_wait, max_wait) if jitter else max_wait
