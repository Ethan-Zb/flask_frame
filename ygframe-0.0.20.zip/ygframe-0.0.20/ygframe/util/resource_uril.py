# -*- coding:utf-8 -*-
# #
# # Author:jing
# # Copyright:yiguotech.com
# # date:2018/05/06
#
# pylint:disable=missing-docstring,import-error
import resource

from ygframe.logger import logger

__author__ = 'jing'


def log_resource():
    for item in _get_resource():
        logger.info(item)


def print_resource():
    print('\n'.join(_get_resource()))


def _get_resource():
    """
    Index 	Field 	Resource
    0 	ru_utime 	time in user mode (float)
    1 	ru_stime 	time in system mode (float)
    2 	ru_maxrss 	maximum resident set size
    3 	ru_ixrss 	shared memory size
    4 	ru_idrss 	unshared memory size
    5 	ru_isrss 	unshared stack size
    6 	ru_minflt 	page faults not requiring I/O
    7 	ru_majflt 	page faults requiring I/O
    8 	ru_nswap 	number of swap outs
    9 	ru_inblock 	block input operations
    10 	ru_oublock 	block output operations
    11 	ru_msgsnd 	messages sent
    12 	ru_msgrcv 	messages received
    13 	ru_nsignals 	signals received
    14 	ru_nvcsw 	voluntary context switches
    15 	ru_nivcsw 	involuntary context switches
    """
    lines = [
        'usage stats=> {}'.format(resource.getrusage(resource.RUSAGE_SELF)),
        'max cpu=> {}'.format(resource.getrlimit(resource.RLIMIT_CPU)),
        'max data=> {}'.format(resource.getrlimit(resource.RLIMIT_DATA)),
        'max processes=> {}'.format(resource.getrlimit(resource.RLIMIT_NPROC)),
        'page size=> {}'.format(resource.getpagesize())
    ]
    return lines
