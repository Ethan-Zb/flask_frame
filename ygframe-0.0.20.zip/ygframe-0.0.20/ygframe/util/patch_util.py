# -*- coding:utf-8 -*-
#
# Author:jing
# Copyright:yiguotech.com
# date:2018/05/06

# pylint:disable=missing-docstring
import types
from importlib import import_module

__author__ = 'jing'


def patch(func, instead):
    if isinstance(func, types.FunctionType):
        module = import_module(func.__module__)
        setattr(module, func.__name__, instead)
        return instead
    raise ValueError('not supported')
