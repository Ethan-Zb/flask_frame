# -*- coding:utf-8 -*-
#
# Author:jing
# Copyright:yiguotech.com
# date:2018/05/06

# pylint:disable=missing-docstring

__author__ = 'jing'


def convert_method_to_static(cls, obj):
    for attr in dir(obj):
        if attr.startswith('_'):
            continue

        setattr(cls, attr, getattr(obj, attr))
