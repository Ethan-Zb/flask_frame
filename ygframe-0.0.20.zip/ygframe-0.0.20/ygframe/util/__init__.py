# -*- coding:utf-8 -*-
#
# Author:jing
# Copyright:yiguotech.com
# date:2018/05/06

# pylint:disable=missing-docstring
import os

from ygframe.serialize.type_serializable import TypeSerializable

__author__ = 'jing'


class _NotSetMeta(type, TypeSerializable):
    def __bool__(cls):
        return False

    def __str__(self):
        return '`NotSet`'


class NotSet(metaclass=_NotSetMeta):  # pylint:disable=too-few-public-methods
    """
    since sometimes `None` is a meaningful value, we can use NotSet for 'not set'
    """
    pass


def get_possible_system_name():
    path_split = os.getcwd().split(os.sep)
    if 'src' in path_split:
        path_split = path_split[:path_split.index('src')]
    if len(path_split) > 2:
        return path_split[-2]


def get_possible_subsystem_name():
    path_split = os.getcwd().split(os.sep)
    if 'src' in path_split:
        path_split = path_split[:path_split.index('src')]
    if len(path_split) > 2:
        default_sub = path_split[-1]
        return default_sub
