# -*- coding:utf-8 -*-
# File Name:uuid_util.py
# Author:jing
# Copyright:yiguotech.com
# date:2018/11/01
import uuid

from ygframe.util.precondition import positive_integer

__author__ = 'jing'


def generate_unique_id(intercept=0, splitter=''):
    intercept = min(positive_integer(intercept, 64), 64)
    return str(uuid.uuid4()).replace('-', splitter)[0:intercept]
