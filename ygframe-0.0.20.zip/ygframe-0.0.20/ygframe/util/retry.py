# -*- coding:utf-8 -*-
#
# Author:jing
# Copyright:yiguotech.com
# date:2018/05/06

# pylint:disable=missing-docstring,import-error,bare-except,not-context-manager
import time
import traceback
from functools import wraps

from ygframe.logger import logger
from ygframe.logger.logger_context import error_exception, warning_exception
from ygframe.util import NotSet
from ygframe.util.backoff import exponential_backoff
from ygframe.util.precondition import positive_integer

__author__ = 'jing'


class Retry:  # pylint: disable=too-few-public-methods
    """retry times"""
    FOREVER = None


class MaxRetryError(Exception):
    pass


def retry(  # pylint:disable=too-many-arguments,catching-non-exception,unused-argument
        max_retries: int = Retry.FOREVER,
        autoretry_for=NotSet,
        task_name: str = None,
        backoff=exponential_backoff,
        accept_none=True,
        default=NotSet,
        exception_handler=None,
):
    """
    :param exception_handler: handle exception
    :param autoretry_for: a type or tuple of types, default is Exception
    :param max_retries: retry times. None means keep retry forever until function call success
            it can also be a callable, to decorate directly
    :param task_name: retry task name. if omit, name will be the function name
    :param backoff: a callable takes turn number as param, returns sleep seconds.
    :param accept_none: set to `True` if None is an acceptable result,default is True
    :param default: when retry failed. we return the value of `default` or raise MaxRetryError
        for the case default is `NotSet`
    """
    if callable(max_retries):
        return retry()(max_retries)

    # check params
    if max_retries != Retry.FOREVER:
        max_retries = positive_integer(max_retries, instead=1)
    if not isinstance(autoretry_for, tuple):
        autoretry_for = (autoretry_for if autoretry_for else Exception,)

    def _decorate(func):
        @wraps(func)
        def _wrapper(*args, **kwargs):
            nonlocal task_name
            nonlocal default
            if not task_name:
                task_name = func.__name__
            retry_turn = 0
            while True:
                try:
                    return_value = func(*args, **kwargs)
                    if not accept_none and return_value is None:
                        raise ValueError('{} returns None'.format(task_name))
                    if retry_turn > 0:
                        logger.info('{} success after retying {} times'.format(
                            task_name, retry_turn
                        ))
                    return return_value
                except autoretry_for:
                    retry_turn += 1
                    msg = '{} failed, args:{}, kwargs:{}, retry turn:{}. error: {}'.format(
                        task_name, args, kwargs, retry_turn, traceback.format_exc())
                    logger.warning(msg)

                    if max_retries and retry_turn > max_retries:
                        break

                    sleep_seconds = 180
                    if backoff:
                        with warning_exception(message='invalid backoff'):
                            sleep_seconds = backoff(retry_turn)

                    logger.warning('next turn retry {} will start after {} seconds'.format(
                        task_name, sleep_seconds))
                    time.sleep(sleep_seconds)

                    if callable(exception_handler):
                        with error_exception(message='error handling task {}'.format(task_name)):
                            exception_handler()

            if default is NotSet:
                raise MaxRetryError('{} failed, retry times:{}'.format(task_name, retry_turn))
            else:
                return default

        return _wrapper

    return _decorate


def scope_retry(
        task_name='',
        start=1,
        retry_backoff_max=180,
        retry_jitter: bool = True,
        max_retries=Retry.FOREVER,
):
    retry_turn = 0
    while True:
        yield retry_turn
        retry_turn += 1
        msg = '{} task failed,retry turn:{}.'.format(
            task_name, retry_turn)
        logger.warning(msg)

        if max_retries and retry_turn > max_retries:
            break

        if start:
            sleep_seconds = 180
            with error_exception(message='invalid backoff'):
                sleep_seconds = exponential_backoff(
                    retry_turn,
                    start=start,
                    max_wait_seconds=retry_backoff_max,
                    jitter=retry_jitter
                )

            logger.warning('next turn retry {} will start after {} seconds'.format(
                task_name, sleep_seconds))
            time.sleep(sleep_seconds)
