# -*- coding:utf-8 -*-
#
# Author:jing
# Copyright:yiguotech.com
# date:2018/05/06

"""wrap generator"""
from ygframe.logger import logger
from ygframe.util.precondition import assert_iterable, assert_positive

__author__ = 'jing'


def with_log(scanner, interval: int = 1000, scanner_name: str = '', message_func=None):
    """
    :param scanner: original scanner
    :param interval: interval of logging
    :param scanner_name: name for message to identifier which scanner is scanning
    :param message_func: take an item as param to product message
    :return: yield items with logger per interval
    """
    assert_positive(interval, instead=1000)
    index = 0
    done = False
    scanner_name = 'scanner {}'.format(scanner_name) if scanner_name else 'scanner'

    logger.info('{} begin scanning'.format(scanner_name))
    try:
        for index, item in enumerate(scanner, 1):
            yield item
            if index % interval == 0:
                message = message_func(item) if callable(message_func) else ''
                logger.info('{} current index: {}{}'.format(
                    scanner_name,
                    index,
                    ' / [{}]'.format(message) if message else '',
                ))
        done = True
    finally:
        logger.info('{} {}, index is {}.'.format(
            scanner_name,
            'done' if done else 'interrupt',
            index))


def group_scanner(scanner, group_size: int = 64):
    """
    :param scanner:  original scanner
    :param group_size:  size of each group yield
    :return:  generator scanner items group by group
    """
    assert_iterable(scanner, instead=[], error_message='scanner must be iterable')
    group = []
    try:
        for index, item in enumerate(scanner, 1):
            group.append(item)
            if index % group_size == 0:
                yield group
                group = []
    finally:
        if group:
            yield group
