# -*- coding:utf-8 -*-
#
# Author:jing
# Copyright:yiguotech.com
# date:2018/05/06

# pylint:disable=missing-docstring,line-too-long,bare-except
from requests import Response

from ygframe.const.common_const import CommonConst

__author__ = 'jing'


def is_success(response: Response):
    try:
        return response.status_code == 200 and response.json().get(CommonConst.RESULT) == CommonConst.SUCCESS
    except:
        return False
