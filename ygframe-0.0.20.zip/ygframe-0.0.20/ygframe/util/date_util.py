# -*- coding:utf-8 -*-
#
# Author:jing
# Copyright:yiguotech.com
# date:2018/05/06

# pylint:disable=missing-docstring
import time

__author__ = 'jing'


def get_date(formatter='%Y-%m-%d'):
    """
    :param formatter:
    :return: current date with given formatter.
    """
    return time.strftime(formatter, time.localtime(time.time()))
