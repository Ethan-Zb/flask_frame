# -*- coding:utf-8 -*-
#
# Author:jing
# Copyright:yiguotech.com
# date:2018/05/06

# pylint:disable=line-too-long

"""
preconditions
check obj,if success, return it.
if failed and instead set, return instead.
else if method startswith assert, raise ValueError
else do nothing.
"""
import collections

from ygframe.logger import logger
from ygframe.util import NotSet

__author__ = 'jing'


def _assert(obj, instead=NotSet, error_message='value error', check=None, strict: bool = False):
    """
    :param obj: the value to be checked
    :param instead:  if set, return this if check failed
    :param error_message: message when check failed
    :param check: check if obj value is valid
    :return:  `obj` itself or `instead`
    :raise `ValueError` if check is failed and 'instead' is `NotSet`
    """
    if not check(obj):
        if instead is NotSet:
            if strict:
                raise ValueError(error_message)
        else:
            if strict:
                logger.warning('{}, the value will be {} instead'.format(error_message, instead))
            obj = instead
    return obj


def not_none(obj, instead=NotSet, error_message: str = 'None is not acceptable'):
    """check not `None`"""
    return _assert(obj, instead, error_message, lambda x: x is not None)


def assert_not_none(obj, instead=NotSet, error_message: str = 'None is not acceptable'):
    """assert not `None`"""
    return _assert(obj, instead, error_message, lambda x: x is not None, strict=True)


def positive_integer(obj, instead=None, error_message: str = 'positive integer is required') -> int:
    """check positive integer"""
    return _assert(obj, instead, error_message, lambda x: (isinstance(x, int) and x > 0))


def assert_positive_integer(obj, instead=None, error_message: str = 'positive integer is required') -> int:
    """assert positive integer"""
    return _assert(obj, instead, error_message, lambda x: (isinstance(x, int) and x > 0), strict=True)


def positive(obj, instead=NotSet, error_message: str = 'positive number required'):
    """check positive"""
    return _assert(obj, instead, error_message, lambda x: x > 0)


def assert_positive(obj, instead=NotSet, error_message: str = 'positive number required'):
    """assert positive"""
    return _assert(obj, instead, error_message, lambda x: x > 0, strict=True)


def assert_callable(obj, instead=NotSet, error_message: str = 'callable required'):
    """check callable"""
    return _assert(obj, instead, error_message, callable, strict=True)


def assert_iterable(obj, instead=NotSet, error_message: str = 'The value is not iterable'):
    """assert callable"""
    return _assert(obj, instead, error_message, lambda x: isinstance(x, collections.Iterable), strict=True)
