# -*- coding:utf-8 -*-
"""
--------------------------------------------
File Name:abstract_test_main.py
Author:jing
Copyright:yiguotech.com
date:2018/07/19
--------------------------------------------
"""
import os
import time
import unittest
from contextlib import contextmanager
from unittest import TestCase

import coverage

from ygframe import SYSTEM_CONFIG
from ygframe.logger import logger
from ygframe.task.task_manager import CoreTaskManager
from ygframe.util.import_util import find_all
from ygframe.util.singleton import Singleton

__author__ = 'jing'


class AbstractTestMain(metaclass=Singleton):
    debug = False
    source = ['../src']
    wait_running = 6
    running = False
    context = {}

    @classmethod
    def start(cls):
        os.environ[SYSTEM_CONFIG.DEBUG_MODE_ENV_KEY] = '1'

        def check(*configs):
            for config in configs:
                file_name = getattr(SYSTEM_CONFIG, config)
                if os.path.isfile(file_name):
                    continue
                src_file = '../src/' + file_name
                if os.path.isfile(src_file):
                    setattr(SYSTEM_CONFIG, config, src_file)

        check(
            'LOGGER_CONFIG_FILE',
            'CONFIG_FILE',
            'SETTING_MODULE_FILE',
            'GLOBALS_MODULE_FILE',
            'INITIALIZER_MODULE_FILE',

        )
        __import__(SYSTEM_CONFIG.INITIALIZER_MODULE_NAME).init()

    @classmethod
    def stop(cls):
        CoreTaskManager.stop_all()

    @classmethod
    @contextmanager
    def running_app(cls):
        cov = coverage.Coverage(source=cls.source)
        if not cls.debug:
            cov.start()
        cls.start()
        yield
        time.sleep(cls.wait_running)
        cls.stop()
        if not cls.debug:
            cov.stop()
            cov.html_report()

    @classmethod
    def main(cls):
        main_module = __import__('__main__')
        with cls.running_app():
            for module in find_all(SYSTEM_CONFIG.TEST_CASE_MODULE_NAME):
                for attr in dir(module):
                    case = getattr(module, attr)
                    if isinstance(case, type) and issubclass(case, TestCase) and case is not TestCase:
                        name = '{}.{}'.format(module.__name__, case.__name__)
                        setattr(main_module, name, case)
                        logger.info('load test case: {}'.format(case.__name__))
            unittest.main()
