# -*- coding:utf-8 -*-
# File Name:mocked_redis.py
# Author:jing
# Copyright:yiguotech.com
# Date:2018/11/09
from fakeredis import FakeStrictRedis

__author__ = 'jing'


def mock_redis(redis_init=None):
    client = FakeStrictRedis()
    from ygframe import redis_wrapper
    redis_wrapper.get_redis_conn = lambda: client
    if redis_init:
        redis_init(client)
