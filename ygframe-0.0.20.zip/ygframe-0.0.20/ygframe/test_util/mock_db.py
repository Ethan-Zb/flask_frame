# -*- coding:utf-8 -*-
# File Name:mock_db.py
# Author:jing
# Copyright:yiguotech.com
# Date:2018/11/09
from functools import cmp_to_key

from ygframe import SYSTEM_CONFIG
from ygframe.db import Filter, GetMode, SortOrder
from ygframe.db.query import Query
from ygframe.db.abstract_model import AbstractModel
from ygframe.util.import_util import get_all

__author__ = 'jing'


class MemoryModel(AbstractModel):
    @classmethod
    def count(cls, query: Query):
        return len(cls.get(query))

    db = []

    @classmethod
    def _check(cls, item: AbstractModel, flt: Filter):
        return flt.check_object(item)

    @classmethod
    def get(cls, query: Query):
        result_list = []
        only_one = query.get_mode_ == GetMode.FIRST
        for item in cls.db:
            if cls._check(item, query.filter_):
                if only_one:
                    return item
                result_list.append(item)
        if query.sort_by_:
            def cmp(a, b):
                for key, direction in query.sort_by_:
                    va = getattr(a, key)
                    vb = getattr(b, key)
                    if va == vb:
                        continue

                    judge = a > b
                    d = direction == SortOrder.ASC

                    if judge and d or not judge and not d:
                        return 1
                    return -1
                else:
                    return 0

            result_list.sort(key=cmp_to_key(cmp))
        total = len(result_list)
        skip = min(query.get_skip(), total)
        limit = min(query.get_limit(), total - skip + 1)
        return result_list[skip:skip + limit]

    @classmethod
    def update(cls, query: Query, obj):
        for item in cls.get(query):
            item.__dict__.update(obj)

    @classmethod
    def delete(cls, query: Query):
        temp = cls.get(query)
        for item in temp:
            if item in cls.db:
                cls.db.remove(item)

    def save(self):
        self.db.append(self)

    @classmethod
    def save_all(cls, obj):
        cls.db.extend(obj)


def mock_db():
    for module in get_all(SYSTEM_CONFIG.MODEL_MODULE_NAME, AbstractModel):
        if not module.__name__.startswith('Abstract'):
            module.__bases__ = (MemoryModel,)
