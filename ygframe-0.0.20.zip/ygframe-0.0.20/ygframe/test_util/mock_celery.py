# -*- coding:utf-8 -*-
# File Name:mock_celery.py
# Author:jing
# Copyright:yiguotech.com
# Date:2018/11/09

__author__ = 'jing'


def mock_celery():
    def delay(self, *args, **kwargs):
        self(*args, **kwargs)

    from celery import Task
    Task.delay = delay
