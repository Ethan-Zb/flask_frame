# -*- coding:utf-8 -*-
"""
--------------------------------------------
File Name:__init__.py.py
Author:jing
Copyright:yiguotech.com
date:2018/05/29
--------------------------------------------
"""
from contextlib import contextmanager
from threading import current_thread

from flask import request
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.ext.declarative import declared_attr
from sqlalchemy.orm import sessionmaker, scoped_session

from ygframe.util.str_util import get_snake_case

__author__ = 'jing'


class BaseModel(object):
    @declared_attr
    def __tablename__(cls):
        return get_snake_case(cls.__name__)

    # id = Column(Integer, primary_key=True, autoincrement=True)
    # create_time = Column(DateTime, default=datetime.now)
    # update_time = Column(DateTime, default=datetime.now, onupdate=datetime.now)


def get_current_request():
    """use for session context"""
    return request or current_thread()


maker = sessionmaker()  # pylint:disable=invalid-name
Session = scoped_session(maker, scopefunc=get_current_request)  # pylint:disable=invalid-name

Base = declarative_base(cls=BaseModel)


@contextmanager
def session_scope():
    """Provide a transactional scope around a series of operations."""
    session = Session()
    try:
        yield session
        session.commit()
    except:  # pylint:disable=bare-except
        session.rollback()
        raise
