# -*- coding:utf-8 -*-
"""
--------------------------------------------
File Name:mysql_initializer.py
Author:jing
Copyright:yiguotech.com
date:2018/05/29
--------------------------------------------
"""
from importlib import import_module

from sqlalchemy import create_engine
from werkzeug.utils import find_modules

from ygframe import SYSTEM_CONFIG
from ygframe.logger import logger

from ygframe.mysql_wrapper import maker, Base

__author__ = 'jing'


def init(
        mysql_url: str,
        pool_size=64,
        max_overflow=64,
        pool_recycle=3600,
        load_classes: list = None,
        auto_load: bool = True,
        pool_pre_ping: bool = True

):
    """
    :param pool_recycle:
    :param max_overflow:
    :param pool_size:
    :param auto_load: auto load classes in module mysql_model
    :param load_classes: classes to load for creating table
    :param mysql_url:
        default: 'mysql://scott:tiger@localhost/foo'
        mysql-python: 'mysql+mysqldb://scott:tiger@localhost/foo'
        MySQL-connector-python: 'mysql+mysqlconnector://scott:tiger@localhost/foo'
        OurSQL: 'mysql+oursql://scott:tiger@localhost/foo'
    :return:
    """
    engine = create_engine(
        mysql_url,
        pool_size=pool_size,
        max_overflow=max_overflow,
        # pool_recycle=pool_recycle,
        pool_pre_ping=pool_pre_ping,
    )
    maker.configure(bind=engine)
    if auto_load:
        try:
            for module_name in find_modules(SYSTEM_CONFIG.MYSQL_MODEL_MODULE_NAME):
                import_module(module_name)
                logger.info('load module {}'.format(module_name))
        except ImportError:
            pass
    if load_classes:
        logger.info('load classes: {}'.format(load_classes))
    Base.metadata.create_all(engine)
