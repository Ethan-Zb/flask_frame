# -*- coding:utf-8 -*-
"""
--------------------------------------------
File Name:flask_app_initializer.py
Author:jing
Copyright:yiguotech.com
date:2018/05/08
--------------------------------------------
"""

import requests
from flask import Flask, request
from flask_restful import Api
from gevent import monkey
from gevent.pywsgi import WSGIServer
from tornado.httpserver import HTTPServer
from tornado.ioloop import IOLoop
from tornado.wsgi import WSGIContainer

from ygframe.api_util.base_admin import register_admin_manager
from ygframe.flask_app import travel_resources, get_url_list
from ygframe.logger import logger
from ygframe.mysql_wrapper import Session
from ygframe.scope.scope import Scope
from ygframe.task.instance_task import InstanceTask
from ygframe.task.task_manager import CoreTaskManager
from ygframe.util import NotSet

__author__ = 'jing'

URL = 'URL'
URL_LIST = 'URL_LIST'
SUB_URL = 'SUB_URL'
SUB_URL_LIST = 'SUB_URL_LIST'


def _default_is_alive():
    return 'yes'


def _default_after_request(response):
    logger.info('{} {} {}'.format(request.method, request.full_path, response.status))
    Session.remove()
    return response


def _check_prefix(routes, prefix):
    for url in routes:
        if not url.startswith(prefix):
            logger.warning('{} does not startswith {}.'.format(url, prefix))


def _load_route(route_list, register_list):
    for resource, version in travel_resources():
        endpoint = resource.__name__.lower() + version
        url_list = tuple(get_url_list(resource, version))
        if url_list:
            route_list.append((resource, url_list, {'endpoint': endpoint}))
        registers = resource.get_register_list()
        if registers:
            register_list.extend(registers)


def init_permission(permission_url, registers):
    return requests.post(
        permission_url,
        json=registers
    )


def init(  # pylint:disable=too-many-arguments
        listen_port: int,
        route_list: list = None,
        is_alive=None,
        before_request=None,
        after_request=None,
        auto_load=True,
        use_gevent=False,
        tornado_proc_num: int = 1,
        permission_url: str = None,
        register_list: list = None,
        admin_manager_list: list = NotSet,  # for default
        ssl_options=None,
        echo_url=True,
        main_task=False,
        external_app=None,
) -> Flask:
    """
    :param admin_manager_list:
    :param ssl_options:
    :param before_request:
    :param register_list:
    :param permission_url:
    :param listen_port: flask listen port
    :param route_list: example: [
                (Resource1, (route,), {}),
                (Resource2, (route2,route3), {endpoint='<endpoint1>'}),
            ]
            item is a tuple, format: (<Resource class>, (routes,), {<kwargs>})
    :param tornado_proc_num: useful only in tornado mode
    :param is_alive: method to check health
    :param after_request: call back method after request
    :param auto_load: default is True, which means the application auto load the Resources
    :param echo_url: print all url routes
    :param use_gevent: use gevent or tornado
    :return: flask app
    """
    name = Scope.get_scope_name(Scope.SUBSYSTEM)
    if external_app:
        app = external_app
        logger.info('init flask with external app (wsgi mode)')
    else:
        app = Flask(name)

    prefix = Scope.get_url_prefix()

    app.route('{}/v{}/alive'.format(prefix, 1))(is_alive or _default_is_alive)
    app.after_request(after_request or _default_after_request)
    if before_request:
        app.before_request(before_request)

    register_admin_manager(app, admin_manager_list)

    api = Api(app)
    route_list = route_list or []
    register_list = register_list or []
    if auto_load:
        _load_route(route_list, register_list)
    for resource, routes, kwargs in route_list:
        _check_prefix(routes, prefix)
        if 'strict_slashes' not in kwargs:
            kwargs['strict_slashes'] = False
        api.add_resource(resource, *routes, **kwargs)

    if permission_url and register_list:
        registers = {}
        for register in register_list:
            registers.update(register)
        init_permission(permission_url, registers)
        # todo result check

    if echo_url:
        logger.info('routes is: ')
        for r in route_list:
            logger.info('{}'.format(r))

    if not external_app:
        # _register_native(app, listen_port, name, tornado_proc_num, ssl_options, main_task)
        if not use_gevent:
            _register_tornado(app, listen_port, name, tornado_proc_num, ssl_options, main_task)
        else:
            _register_gevent(app, listen_port, name, ssl_options, main_task)

        logger.info('{} listening on port:{}'.format(name, listen_port))

    return app


def _register_gevent(app, listen_port, name, ssl_options, main_task):
    monkey.patch_all(
        # select=False, ssl=False,
        # sys=True,
    )

    logger.info('listening {}..'.format(listen_port))
    ssl_options = ssl_options or {}

    http_server = WSGIServer(('0.0.0.0', listen_port), app, backlog=1024, **ssl_options)
    CoreTaskManager.register(InstanceTask(
        do_start=http_server.serve_forever,
        do_stop=http_server.stop,
        status='running on port {} / gevent'.format(listen_port),
        description='Flask app: {}'.format(name),
        handle_key='flask_{}'.format(name),
        main_task=main_task
    ))


def _register_tornado(app, listen_port, name, tornado_proc_num, ssl_options, main_task):
    container = WSGIContainer(app)
    if ssl_options:
        http_server = HTTPServer(container, ssl_options=ssl_options)
    else:
        http_server = HTTPServer(container)

    logger.info('listening {}..'.format(listen_port))
    http_server.bind(listen_port)
    http_server.start(tornado_proc_num)
    instance = IOLoop.instance()
    if tornado_proc_num == 1:
        CoreTaskManager.register(InstanceTask(
            do_start=instance.start,
            do_stop=instance.stop,
            status='running on port {} / tornado'.format(listen_port),
            description='Flask app: {}'.format(name),
            handle_key='flask_{}'.format(name),
            main_task=main_task
        ))
    else:
        instance.start()


def _register_native(app, listen_port, name, tornado_proc_num, ssl_options, main_task):
    logger.info('listening {}..'.format(listen_port))
    app.run(host='0.0.0.0', port=listen_port)