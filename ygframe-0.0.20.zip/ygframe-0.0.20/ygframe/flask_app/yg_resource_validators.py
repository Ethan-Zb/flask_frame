# -*- coding:utf-8 -*-
"""
--------------------------------------------
File Name:yg_resource_validators.py
Author:jing
Copyright:yiguotech.com
date:2018/07/27
--------------------------------------------
"""
from functools import wraps

import requests
from flask import request
from jsonschema import validate, ValidationError, SchemaError

from ygframe import SYSTEM_CONFIG
from ygframe.api_util.schema_builder import Args
from ygframe.const.common_const import CommonConst
from ygframe.flask_app import YgResource
from ygframe.setting import get_setting
from ygframe.util.inspect_util import get_class_that_defined_method
from ygframe.util.request_util import is_success

__author__ = 'jing'


def _pre_validate(instance_type):
    def _validate(func):
        @wraps(func)
        def _wrapper(*args, **kwargs):
            try:
                func_cls = get_class_that_defined_method(func)
                if not isinstance(func_cls, type) or not issubclass(func_cls, YgResource):
                    raise Exception
                name = func.__name__
                schema_name = '__{}_{}_schema__'.format(name, instance_type)
                schema = getattr(func_cls, schema_name)
                if isinstance(schema, Args):
                    schema = schema.get()

                if schema:
                    if instance_type == 'json':
                        if not request.is_json:
                            return func_cls.failure(10001, 'request is not json')
                        else:
                            instance = request.get_json()
                    elif instance_type == 'args':
                        instance = request.args
                    else:
                        raise ValueError('wrong type: must be json or args')
                    try:
                        validate(instance, schema)
                    except ValidationError as ve:
                        return func_cls.failure(10002, str(ve))
                    except SchemaError as se:
                        raise ValueError('schema not valid: {}'.format(se))

                return func(*args, **kwargs)
            except Exception as e:  # pylint:disable=bare-except
                return YgResource.failure(10004, 'unknown error of {}'.format(str(e)))

        return _wrapper

    return _validate


def get_permission_url():
    return '{register_url}?{ygtoken_key}={token}&{sid_key}={sid}&{sessionid_key}={sessionid}&{permission_key}='.format(
        register_url=get_setting(SYSTEM_CONFIG.REGISTER_URL_SETTING_KEY),
        ygtoken_key=CommonConst.SESSION_TOKEN,
        token=request.cookies.get(CommonConst.SESSION_TOKEN),
        sid_key=CommonConst.SID,
        sid=request.cookies.get(CommonConst.SID),
        sessionid_key=CommonConst.SESSION_ID,
        sessionid=request.cookies.get(CommonConst.SESSION_ID),
        permission_key=CommonConst.PERMISSION
    )


def check_permission():
    try:
        if request.cookies:
            if not is_success(requests.get(get_permission_url())):
                return YgResource.failure(10003, 'permission denied')
        return None
    except Exception as e:  # pylint:disable=bare-except
        return YgResource.failure(10004, 'unknown error of {}'.format(str(e)))


def validate_permission(func):
    @wraps(func)
    def _dec(*args, **kwargs):
        try:
            func_cls = get_class_that_defined_method(func)
            if not isinstance(func_cls, type) or not issubclass(func_cls, YgResource):
                raise Exception
            permission_result = check_permission()
            if permission_result:
                return permission_result
            return func(*args, **kwargs)
        except Exception as e:  # pylint:disable=bare-except
            return YgResource.failure(10004, 'unknown error of {}'.format(str(e)))

    return _dec


validate_args = _pre_validate('args')
validate_json = _pre_validate('json')
