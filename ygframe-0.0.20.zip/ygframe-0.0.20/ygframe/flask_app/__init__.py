# -*- coding:utf-8 -*-
"""
--------------------------------------------
File Name:__init__.py.py
Author:jing
Copyright:yiguotech.com
date:2018/05/08
--------------------------------------------
"""
from collections import namedtuple
from typing import List, Dict

from flask import Response
from flask_restful import Resource
from setuptools import find_packages

from ygframe.const.common_const import CommonConst
from ygframe.logger import logger
from ygframe.scope.scope import Scope
from ygframe.util.dict_util import get_dict
from ygframe.util.file_util import read_chunk
from ygframe.util.import_util import get_all, module_exists
from ygframe.util.str_util import get_snake_case

__author__ = 'jing'


class Sample(namedtuple('Sample', ['data', 'description'])):
    """
    use in python 3.5.
    when updated to 3.6, change to:
        class Sample(NamedTuple):
            data:dict
            description:str = ''
    witch is much better to write and read
    """
    __slots__ = ()

    # noinspection PyInitNewSignature,PyArgumentList
    def __new__(cls, data: dict, description: str = ''):
        return super(Sample, cls).__new__(cls, data, description)


ErrorCode = namedtuple('ErrorCode', ['code', 'description'])


class YgResource(Resource):  # pylint: disable=too-few-public-methods
    """
    abstract class of all api
    """
    __sub_url__ = None
    __sub_url_list__ = None
    __url__ = None
    __url_list__ = None
    __permission_register_list__ = None
    __get_args_schema__ = None
    __get_json_schema__ = None
    __post_args_schema__ = None
    __post_json_schema__ = None
    __put_json_schema__ = None
    __put_args_schema__ = None
    __delete_args_schema__ = None
    __delete_json_schema__ = None
    __get_request_sample__ = None
    __post_request_sample__ = None
    __put_request_sample__ = None
    __delete_request_sample__ = None
    __get_response_sample__ = None
    __post_response_sample__ = None
    __put_response_sample__ = None
    __delete_response_sample__ = None
    __error_code_list__ = None

    @classmethod
    def success(cls, *args, **kwargs) -> dict:
        result = {
            CommonConst.RESULT: CommonConst.SUCCESS
        }
        result.update(get_dict(*args, **kwargs))
        return result

    @classmethod
    def failure(cls, error_code=-1, reason=None, *args, **kwargs) -> dict:
        result = {
            CommonConst.RESULT: CommonConst.FAILURE,
            CommonConst.ERROR_CODE: error_code,
            CommonConst.REASON: reason
        }
        result.update(get_dict(*args, **kwargs))
        logger.error(result)
        return result

    @classmethod
    def busy(cls, count_down):
        pass

    @classmethod
    def redirect(cls):
        pass

    @classmethod
    def get_register_list(cls) -> List[Dict]:
        return []

    @classmethod
    def _get_register(cls, func_id, func_name, func_status='release'):
        return {
            func_id: {
                'func_name': func_name,
                'func_status': func_status
            }
        }

    @classmethod
    def send_file(cls, file_name):
        return Response(read_chunk(file_name), content_type='application/octet-stream')


class YgCallback(YgResource):
    pass


def travel_resources():
    # for version in find_packages('api'):
    if not module_exists('api'):
        return []

    for version in find_packages('api'):
        if '.' in version or not version.startswith('v'):
            continue
        for resource in get_all('api.' + version, YgResource):
            if resource == YgCallback:
                continue
            yield resource, version


def get_url_list(value, version):
    if value.__url__:
        return [value.__url__]
    if value.__url_list__:
        return value.__url_list__
    prefix = '{}/{}/'.format(Scope.get_url_prefix(), version)
    if value.__sub_url__:
        return [prefix + value.__sub_url__]
    if value.__sub_url_list__:
        return [prefix + sub_url for sub_url in value.__sub_url_list__]
    return [prefix + get_snake_case(value.__name__)]
