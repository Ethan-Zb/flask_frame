# -*- coding:utf-8 -*-
"""
--------------------------------------------
File Name:builder.py
Author:jing
Copyright:yiguotech.com
date:2018/08/07
--------------------------------------------
"""
import time
from typing import List, Optional

from mongoengine import connect

from ygframe import SYSTEM_CONFIG
from ygframe.celery_app import Worker
from ygframe.const.common_const import CommonConst
from ygframe.es_wrapper import es_initializer
from ygframe.flask_app import flask_app_initializer
from ygframe.interface.manager_interface import ManagerInterface
from ygframe.logger import logger
from ygframe.logger import logger_initializer
from ygframe.rabbitmq_wrapper import Consumer
from ygframe.scope import scope_initializer
from ygframe.serialize.dict_serializable import DictSerializable
from ygframe.serialize.yg_encoder import Encoder, YgEncoder
from ygframe.setting import setting_initializer, get_setting
from ygframe.task.cyclic_task import CyclicTask
from ygframe.task.instance_task import InstanceTask
from ygframe.task.task_manager import CoreTaskManager
from ygframe.util import NotSet
from ygframe.util.import_util import find_all, get_all
from ygframe.util.singleton import Singleton

GLOBALS = getattr(__import__(SYSTEM_CONFIG.GLOBALS_MODULE_NAME), 'GLOBALS')

__author__ = 'jing'


class Builder(metaclass=Singleton):
    scope_initialized = False
    etcd_initialized = False
    celery_initialized = False
    flask_initialized = False
    web_socket_initialized = False
    hbase_initialized = False
    mysql_initialized = False
    mongo_initialized = False
    mongoengine_initialized = False
    rabbitmq_initialized = False
    redis_initialized = False
    es_initialized = False
    etcd_client = None
    flask_app = None
    route_list = None
    auto_load = True

    @classmethod
    def init_scope(cls, system_name=None, subsystem_short_name=None):
        if system_name and subsystem_short_name:
            scope_initializer.init_scope(system_name, subsystem_short_name)
        logger_initializer.init_default_logger()
        cls.scope_initialized = True
        return cls

    @classmethod
    def init_etcd(cls):
        if not cls.scope_initialized:
            raise ValueError('scope must be initialized')
        cls.etcd_client = setting_initializer.init_default(GLOBALS.debug)
        cls.etcd_initialized = GLOBALS.debug
        time.sleep(1)
        return cls

    @classmethod
    def init_mongo(cls):
        cls.mongo_initialized = True
        return cls

    @classmethod
    def init_mongoengine(cls):
        cls.mongoengine_initialized = True
        return cls

    @classmethod
    def init_celery(
            cls,
            custom_encoder: Encoder = YgEncoder,
            workers: List[Worker] = None,
            app_config: dict = None,
            common_worker_argv: List[str] = None,
            custom_local_task_names: List[str] = None,
            custom_remote_task_names: List[str] = None,
            start_local_task=True,
    ):
        cls._custom_encoder = custom_encoder
        cls._workers = workers
        cls._celery_app_config = app_config
        cls._common_worker_argv = common_worker_argv
        cls._custom_local_task_names = custom_local_task_names
        cls._custom_remote_task_names = custom_remote_task_names
        cls._start_local_task = start_local_task
        cls.celery_initialized = True
        return cls

    @classmethod
    def init_rabbitmq(cls, consumers: List[Consumer] = None):
        cls.rabbitmq_initialized = True
        cls._rabbitmq_consumers = consumers or []
        return cls

    @classmethod
    def init_flask(
            cls,
            is_alive=None,
            before_request=None,
            after_request=None,
            use_gevent=False,
            ssl_options=None,
            port=None,
            route_list=None,
            auto_load=True,
            main_task=False,
            extern_app=None
    ):
        cls._flask_is_alive = is_alive
        cls._flask_before_request = before_request
        cls._flask_after_request = after_request
        cls._use_gevent = use_gevent
        cls._flask_ssl_options = ssl_options
        cls._flask_main_task = main_task
        cls.route_list = route_list
        cls.auto_load = auto_load
        cls.flask_initialized = True
        cls._flask_port = port
        cls._flask_app = extern_app
        return cls

    @classmethod
    def init_web_socket(cls, ssl_options=None):
        cls.web_socket_ssl_options = ssl_options
        cls.web_socket_initialized = True
        return cls

    @classmethod
    def init_hbase(cls, table_prefix: Optional[str] = NotSet):
        cls._hbase_table_prefix = table_prefix
        cls.hbase_initialized = True
        return cls

    @classmethod
    def init_mysql(cls):
        cls.mysql_initialized = True
        return cls

    @classmethod
    def init_redis(cls):
        cls.redis_initialized = True
        return cls

    # @classmethod
    # def init_es(cls):
    #     host = get_setting(SYSTEM_CONFIG.ES_HOST_SETTING_KEY)
    #     if host:
    #         cls._es_hosts = (host,)
    #     else:
    #         cls._es_hosts = get_setting(SYSTEM_CONFIG.ES_HOSTS_SETTING_KEY).split(',')
    #     cls.es_initialized = True
    #     return cls
    @classmethod
    def init_es(cls):
        cls.es_initialized = True
        return cls

    @classmethod
    def _start_tasks(cls, start_local_task=True):
        if start_local_task:
            for module in find_all(SYSTEM_CONFIG.INSTANCE_TASK_MODULE_NAME):
                for item in dir(module):
                    value = getattr(module, item)
                    if isinstance(value, InstanceTask):
                        CoreTaskManager.register(value)

            for module in find_all(SYSTEM_CONFIG.CYCLIC_TASK_MODULE_NAME):
                for item in dir(module):
                    value = getattr(module, item)
                    if isinstance(value, CyclicTask):
                        CoreTaskManager.register(value)

        CoreTaskManager.start_all()

    # noinspection PyUnresolvedReferences,PyProtectedMember
    @classmethod
    def _start_flask(cls):
        if not cls.flask_initialized:
            return
        if cls._flask_port:
            port = cls._flask_port
        else:
            port = get_setting(SYSTEM_CONFIG.LISTEN_PORT_SETTING_KEY)
        cls.flask_app = flask_app_initializer.init(
            route_list=cls.route_list,
            auto_load=cls.auto_load,
            listen_port=port,
            tornado_proc_num=get_setting(SYSTEM_CONFIG.TORNADO_PROC_NUM_SETTING_KEY, 1),
            permission_url=get_setting(SYSTEM_CONFIG.PERMISSION_URL_SETTING_KEY),
            is_alive=cls._flask_is_alive,
            before_request=cls._flask_before_request,
            after_request=cls._flask_after_request,
            use_gevent=cls._use_gevent,
            ssl_options=cls._flask_ssl_options,
            main_task=cls._flask_main_task,
            external_app=cls._flask_app
        )

    @classmethod
    def _start_web_socket(cls):
        if not cls.web_socket_initialized:
            return
        from ygframe.web_socket_app import web_socket_initialized
        web_socket_initialized.init(
            web_socket_port=get_setting(SYSTEM_CONFIG.LISTEN_PORT_SETTING_KEY),
            tornado_proc_num=get_setting(SYSTEM_CONFIG.TORNADO_PROC_NUM_SETTING_KEY, 1),
            ssl_options=cls.web_socket_ssl_options,
            settings={}
        )

    # noinspection PyUnresolvedReferences,PyProtectedMember
    @classmethod
    def build(cls, init_base=True, start_task=True):
        if init_base:
            cls.init_base()

        if cls.rabbitmq_initialized:
            from ygframe.rabbitmq_wrapper import rabbitmq_initializer
            from ygframe.rabbitmq_wrapper.rabbitmq_initializer import register_consumers
            rabbitmq_initializer.init(
                get_setting(SYSTEM_CONFIG.RABBITMQ_URL_SETTING_KEY)
            )
            register_consumers(cls._rabbitmq_consumers)

        if cls.hbase_initialized:
            from ygframe.hbase_wrapper import hbase_initializer
            hbase_initializer.init(
                host=get_setting(SYSTEM_CONFIG.HBASE_HOST_SETTING_KEY),
                port=get_setting(SYSTEM_CONFIG.HBASE_PORT_SETTING_KEY, 9090),
                size=get_setting(SYSTEM_CONFIG.HBASE_POOL_SIZE_SETTING_KEY, 64),
                timeout=get_setting(SYSTEM_CONFIG.HBASE_TIMEOUT_SETTING_KEY, 60000),
                table_prefix=cls._hbase_table_prefix
            )

        if cls.mysql_initialized:
            from ygframe.mysql_wrapper import mysql_initializer
            mysql_initializer.init(
                mysql_url=get_setting(SYSTEM_CONFIG.MYSQL_URL_SETTING_KEY),
                pool_size=get_setting(SYSTEM_CONFIG.MYSQL_POOL_SIZE_SETTING_KEY, 64),
                max_overflow=get_setting(SYSTEM_CONFIG.MYSQL_MAX_OVERFLOW_SETTING_KEY, 64),
                pool_recycle=get_setting(SYSTEM_CONFIG.MYSQL_POOL_RECYCLE_SETTING_KEY, 3600),
            )
        if cls.redis_initialized:
            from ygframe.redis_wrapper import redis_initializer
            redis_initializer.init(
                get_setting(SYSTEM_CONFIG.REDIS_HOST_SETTING_KEY),
                get_setting(SYSTEM_CONFIG.REDIS_PORT_SETTING_KEY, 6379),
                get_setting(SYSTEM_CONFIG.REDIS_PASSWORD_SETTING_KEY, ''),
                get_setting(SYSTEM_CONFIG.REDIS_DB_SETTING_KEY, 0),
                get_setting(SYSTEM_CONFIG.REDIS_DEFAULT_EXPIRE_SETTING_KEY, 3 * CommonConst.MONTH_SECONDS)
            )
        if cls.mongo_initialized:
            from ygframe.mongo_wrapper import mongo_initializer
            mongo_initializer.init(
                get_setting(SYSTEM_CONFIG.MONGO_HOST_SETTING_KEY),
                get_setting(SYSTEM_CONFIG.MONGO_PORT_SETTING_KEY, 27017),
                get_setting(SYSTEM_CONFIG.MONGO_USERNAME_SETTING_KEY),
                get_setting(SYSTEM_CONFIG.MONGO_PASSWORD_SETTING_KEY),
                get_setting(SYSTEM_CONFIG.MONGO_MAX_CONNECTION_POOL_SIZE_SETTING_KEY),
            )

        if cls.mongoengine_initialized:
            connect_instance = connect(host=get_setting(SYSTEM_CONFIG.MONGO_HOST_SETTING_KEY))
            logger.info("SUCCESS to connect mongodb by mongo engine, connect info: {}".format(connect_instance))

        if cls.celery_initialized:
            from ygframe.celery_app import celery_app_initializer
            celery_app_initializer.init(
                get_setting(SYSTEM_CONFIG.CELERY_BROKER_URL_SETTING_KEY),
                get_setting(SYSTEM_CONFIG.CELERY_BACKEND_URL_SETTING_KEY),
                custom_encoder=cls._custom_encoder,
                workers=cls._workers,
                app_config=cls._celery_app_config,
                common_worker_argv=cls._common_worker_argv,
                custom_local_tasks=cls._custom_local_task_names,
                custom_remote_tasks=cls._custom_remote_task_names,
                start_local_task=cls._start_local_task
            )

        # load all DictSerializable
        for _ in get_all(SYSTEM_CONFIG.MODEL_MODULE_NAME, DictSerializable):
            pass
        # load all manager
        for manager in get_all(SYSTEM_CONFIG.MANAGER_MODULE_NAME, ManagerInterface):
            if issubclass(manager, ManagerInterface):
                manager.after_class_loaded()

        if start_task:
            # use tornado
            cls.start_tasks()

    @classmethod
    def init_base(cls):
        if not cls.scope_initialized:
            cls.init_scope()
        cls.init_etcd()
        if cls.es_initialized:
            host = get_setting(SYSTEM_CONFIG.ES_HOST_SETTING_KEY)
            if host:
                cls._es_hosts = (host,)
            else:
                cls._es_hosts = get_setting(SYSTEM_CONFIG.ES_HOSTS_SETTING_KEY).split(',')
            es_initializer.init(*cls._es_hosts)

    @classmethod
    def start_tasks(cls, start_local_task=True):
        tornado_proc_num = get_setting(SYSTEM_CONFIG.TORNADO_PROC_NUM_SETTING_KEY, 1)
        if tornado_proc_num == 1:
            cls._start_flask()
            cls._start_tasks(start_local_task)
        else:
            cls._start_tasks(start_local_task)
            time.sleep(1)
            cls._start_flask()
        cls._start_web_socket()
