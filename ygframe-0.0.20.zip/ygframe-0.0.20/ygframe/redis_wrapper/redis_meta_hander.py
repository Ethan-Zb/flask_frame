# -*- coding:utf-8 -*-
"""
--------------------------------------------
File Name:redis_meta_hander.py
Author:jing
Copyright:yiguotech.com
date:2018/07/19
--------------------------------------------
"""
from redis import Redis

from ygframe.redis_wrapper import get_redis_conn, generate_redis_key, RedisConst
from ygframe.scope.scope import Scope
from ygframe.statistic.base_meta_handler import BaseMetaHandler

__author__ = 'jing'


class RedisMetaHandler(BaseMetaHandler):

    def __init__(self, key, scope: str = Scope.SUBSYSTEM) -> None:
        self.conn = get_redis_conn()
        self.key = generate_redis_key(key, scope, RedisConst.STATISTIC_TYPE)

    def increase(self, value: int = 1) -> int:
        return self.conn.incrby(self.key, value)

    def reset(self, value: int = 0):
        self.conn.set(self.key, value)

    def get(self) -> int:
        value = self.conn.get(self.key)
        return int(value.decode()) if value else 0

    def expire(self, ex: int):
        self.conn.expire(self.key, ex)

    def exist(self) -> bool:
        return self.conn.exists(self.key)
