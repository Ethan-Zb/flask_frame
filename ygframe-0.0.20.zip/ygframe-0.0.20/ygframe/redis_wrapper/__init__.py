# -*- coding:utf-8 -*-
"""
--------------------------------------------
File Name:__init__.py.py
Author:jing
Copyright:yiguotech.com
date:2018/04/27
--------------------------------------------
"""
from redis import Redis

from ygframe.const.common_const import CommonConst
from ygframe.scope.scope import Scope
from ygframe.setting.setting_protocol import resolve_download_value
from ygframe.util.precondition import not_none

__author__ = 'jing'
__redis_op = None
__default_expire = None


class RedisConst:
    DEFAULT_EXPIRE = 3 * CommonConst.MONTH_SECONDS
    STATISTIC_TYPE = 's'
    PERSISTENCE_TYPE = 'p'


def generate_redis_key(key, scope=Scope.SUBSYSTEM, item_type=None):
    prefix = Scope.get_scope_name(scope)
    if item_type:
        prefix = '{}:{}'.format(prefix, item_type)
    if not key.startswith(prefix):
        key = '{}:{}'.format(prefix, key)
    return key


def scoped_set(
        key: str,
        value,
        scope=Scope.SUBSYSTEM,
        item_type=None,
        ex=RedisConst.DEFAULT_EXPIRE,
        **kwargs
):
    ex = None if ex is None else (ex or __default_expire)
    redis_conn = not_none(__redis_op)  # type:Redis
    redis_conn.set(generate_redis_key(key, scope, item_type), value, ex=ex, **kwargs)


def scoped_get(
        key: str,
        scope=Scope.SUBSYSTEM,
        item_type=None,
        refresh_expire: int = None,
        auto_resolve=True
):
    redis_conn = not_none(__redis_op)  # type:Redis
    redis_key = generate_redis_key(key, scope, item_type)
    if refresh_expire:
        redis_conn.expire(redis_key, refresh_expire)
    value = redis_conn.get(redis_key)
    if value is None:
        return value

    return resolve_download_value(value) if auto_resolve else value.decode()


def scoped_delete(
        key: str,
        scope=Scope.SUBSYSTEM,
        item_type=None,
):
    redis_conn = not_none(__redis_op)  # type:Redis
    redis_conn.delete(generate_redis_key(key, scope, item_type))


def scoped_incr(
        key: str,
        amount=1,
        scope=Scope.SUBSYSTEM,
        item_type=None,
):
    get_redis_conn().incr(generate_redis_key(key, scope, item_type), amount)


def get_redis_conn(new_host=None) -> Redis:
    return Redis(new_host) if new_host else not_none(__redis_op)
