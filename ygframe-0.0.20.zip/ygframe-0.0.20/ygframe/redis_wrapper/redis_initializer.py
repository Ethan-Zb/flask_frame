# -*- coding:utf-8 -*-
"""
--------------------------------------------
File Name:redis_initializer.py
Author:jing
Copyright:yiguotech.com
date:2018/04/27
--------------------------------------------
"""
import redis

from ygframe import redis_wrapper
from ygframe.const.common_const import CommonConst

__author__ = 'jing'


def init(
        host: str,
        port: int = 6379,
        password: str = None,
        db: int = 0,
        default_ex: int = 3 * CommonConst.MONTH_SECONDS
):
    if password:
        redis_op = redis.Redis(host=host, port=port, password=password, db=db)
    else:
        redis_op = redis.Redis(host=host, port=port, db=db)
    redis_wrapper.__redis_op = redis_op
    redis_wrapper.__default_expire = default_ex
    return redis_op
