# -*- coding:utf-8 -*-
"""
--------------------------------------------
File Name:redis_persistence_handler.py
Author:jing
Copyright:yiguotech.com
date:2018/08/29
--------------------------------------------
"""
from ygframe.redis_wrapper import scoped_set, RedisConst, scoped_get, get_redis_conn, generate_redis_key

from ygframe.util.persistence_util import PersistenceHandler

__author__ = 'jing'


class RedisPersistenceHandler(PersistenceHandler):
    def delete(self):
        get_redis_conn().delete(generate_redis_key(self.key, item_type=RedisConst.PERSISTENCE_TYPE))

    def get_status(self) -> str:
        pass

    def get_description(self) -> str:
        pass

    def get_handle_key(self) -> str:
        pass

    def __init__(self, key) -> None:
        self.key = key

    def reset(self, init_value=None):
        if init_value:
            self.save(init_value)
        else:
            get_redis_conn().delete(generate_redis_key(self.key, item_type=RedisConst.PERSISTENCE_TYPE))

    def save(self, message: str):
        scoped_set(self.key, message, item_type=RedisConst.PERSISTENCE_TYPE)

    def load(self) -> str:
        return scoped_get(self.key, item_type=RedisConst.PERSISTENCE_TYPE)
