# -*- coding:utf-8 -*-
"""
--------------------------------------------
File Name:redis_statistic.py
Author:jing
Copyright:yiguotech.com
date:2018/04/27
--------------------------------------------
"""

from redis import Redis

from ygframe.redis_wrapper.redis_meta_hander import RedisMetaHandler
from ygframe.scope.scope import Scope
from ygframe.statistic.base_meta_handler import BaseMetaHandler
from ygframe.statistic.base_simple_counter import BaseSimpleCounter
from ygframe.statistic.statistic_manager import BaseStatisticManager

__author__ = 'jing'


class RedisStringHandler(BaseSimpleCounter):

    def __init__(
            self,
            key: str = None,
            scope: str = Scope.SUBSYSTEM,
            description: str = None,
            with_h: int = 0,
            with_d: int = 0,
            other_ts_strategies=None
    ) -> None:
        self.scope = scope
        self.description = description
        super().__init__(key, with_h, with_d, other_ts_strategies)

    def get_meta_handler(self, key) -> BaseMetaHandler:
        return RedisMetaHandler(key, self.scope)

    def get_description(self):
        return self.description or super().get_description()


class RedisStatisticManager(BaseStatisticManager):
    pass
