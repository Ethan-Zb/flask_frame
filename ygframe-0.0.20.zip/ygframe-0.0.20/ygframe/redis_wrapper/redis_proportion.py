# -*- coding:utf-8 -*-
"""
--------------------------------------------
File Name:redis_proportion.py
Author:jing
Copyright:yiguotech.com
date:2018/07/23
--------------------------------------------
"""
from redis import Redis

from ygframe.redis_wrapper.redis_meta_hander import RedisMetaHandler
from ygframe.scope.scope import Scope

from ygframe.statistic.base_meta_handler import BaseMetaHandler
from ygframe.statistic.base_proportion import BaseSimpleProportion

__author__ = 'jing'


class RedisProportion(BaseSimpleProportion):

    def __init__(
            self,
            key: str,
            counters: list,
            redis_conn: Redis = None,
            scope: str = Scope.SUBSYSTEM,
    ):
        self.scope = scope
        self.redis_conn = redis_conn
        super().__init__(key, counters)

    def get_meta_handler(self, key) -> BaseMetaHandler:
        return RedisMetaHandler(key, self.scope, self.redis_conn)
