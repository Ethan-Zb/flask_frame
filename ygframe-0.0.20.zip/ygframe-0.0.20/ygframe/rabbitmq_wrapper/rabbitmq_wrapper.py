# -*- coding:utf-8 -*-
"""
--------------------------------------------
File Name:rabbitmq_wrapper.py
Author:jing
Copyright:yiguotech.com
date:2018/05/08
--------------------------------------------
"""
import json

import pika
import pika_pool
from ygframe.decorator.logger_decorator import log_error
from ygframe.decorator.retry import retry

from ygframe.queue import get_task_queue_name
from ygframe.utils.int_util import BIG_NUM
from ygframe.utils.preconditions import not_none

__author__ = 'jing'

__pool = None

"""
params = pika.URLParameters(
   'amqp://guest:guest@localhost:5672/?'
   'socket_timeout=10&'
   'connection_attempts=2'
 )
"""


@log_error(msg='init rabbitmq error')
def init(
        params: str,
        max_size: int = 10,
        max_overflow=10,
        timeout=30,
        recycle=None,
        stale=None,
):
    global __pool

    params = pika.URLParameters(params)
    __pool = pika_pool.QueuedPool(
        create=lambda: pika.BlockingConnection(parameters=params),
        max_size=max_size,
        max_overflow=max_overflow,
        timeout=timeout,
        recycle=recycle,
        stale=stale,
    )


def get_task_queue_size():
    return get_queue_size(get_task_queue_name())


@log_error(
    msg='error when trying to get queue size, will return a large number to prevent error',
    value_on_exception=BIG_NUM
)
def get_queue_size(queue_name):
    not_none(__pool)
    with __pool.acquire() as cxn:
        return cxn.channel.queue_declare(
            queue_name,
            passive=True
        ).method.message_count


@retry()
def put_message(queue_name, body: (str, dict)):
    not_none(__pool)
    if isinstance(body, dict):
        body = json.dumps(body)
    with __pool.acquire() as cxn:
        return cxn.channel.basic_publish(
            exchange='',
            routing_key=queue_name,
            body=body
        )


def start_consuming(queue_name, callback):
    not_none(__pool)
    with __pool.acquire() as cxn:
        cxn.channel.basic_consume(
            callback,
            queue=queue_name,
            no_ack=True
        )
        cxn.channel.start_consuming()


def create_queue(queue_name):
    not_none(__pool)
    with __pool.acquire() as cxn:
        cxn.channel.queue_declare(queue=queue_name)


def check_health():
    try:
        not_none(__pool)
        with __pool.acquire() as cxn:
            return cxn.channel.is_open
    except:
        return False
