# -*- coding:utf-8 -*-
"""
--------------------------------------------
File Name:package_util.py
Author:jing
Copyright:yiguotech.com
date:2018/05/15
--------------------------------------------
"""
import time
from functools import partial

import requests

from ygframe.logger import logger
from ygframe.queue import get_package_result_queue_name
from ygframe.rabbitmq_wrapper.rabbitmq_initializer import start_consuming, put_message
from ygframe.task.cyclic_task import CyclicTask
from ygframe.task.instance_task import InstanceTask
from ygframe.task.task_manager import CoreTaskManager
from ygframe.util.request_util import is_success

__author__ = 'jing'

RESULT_URL = 'result_url'
DATA = 'data'


class Package(object):

    def __init__(self, result_url) -> None:
        self.result_url = result_url
        self.ts = time.time()
        self.package = []

    def size(self):
        return len(self.package)

    def append(self, item):
        self.package.append(item)
        self.ts = time.time()

    def clear(self):
        self.package.clear()
        self.ts = time.time()

    def is_timeout(self, ttl):
        return time.time() - self.ts >= ttl


class PackageUtil(object):
    context_package = {}

    def __init__(
            self,
            queue_name_key: str = 'default',
            result_key: str = 'result',
            package_size: int = 64,
            timeout: int = 60,
            call_back=None
    ) -> None:
        self.queue_name = get_package_result_queue_name(queue_name_key)
        self.package_size = package_size
        self.result_key = result_key
        self.timeout = timeout
        self.call_back = call_back or default_call_back

    def put(self, result_url, data):
        put_message(self.queue_name, {
            RESULT_URL: result_url,
            DATA: data
        })

    def call_back_package(self, body, message):
        result_url = body.get(RESULT_URL)
        if not result_url:
            logger.info('result url is required')
            return None
        pkg = self.context_package.get(result_url)
        if not pkg:
            pkg = Package(result_url)
            self.context_package[result_url] = pkg
        pkg.append(body.get(DATA))

        if pkg.size() >= self.package_size:
            self._make_package(result_url, pkg)
        message.ack()

    def _make_package(self, result_url, pkg):
        reject_items = self.call_back(result_url, self.result_key, pkg.package) or []
        pkg.clear()
        for item in reject_items:
            self.put(result_url, item)

    def check_all(self):
        for result_url, pkg in self.context_package.items():
            if pkg.size() > 0 and pkg.is_timeout(self.timeout):
                self._make_package(result_url, pkg)

    def init_consumer_and_beat(self):
        self.init_consumer()
        self.init_beat()

    def init_consumer(self):
        CoreTaskManager.register(
            InstanceTask(
                do_start=partial(start_consuming, queue_name=self.queue_name, callback=self.call_back_package),
                handle_key='consuming_package_result_callback'
            )
        )

    def init_beat(self):
        CoreTaskManager.register(
            CyclicTask(
                task=self.check_all,
                cyclic_wait=self.timeout,
                handle_key='consuming_package_result_callback_timeout_beat'
            )
        )


def default_call_back(result_url: str, result_key: str, items: list):
    try:
        resp = requests.post(result_url, json={result_key: items})
    except:
        resp = None
        logger.error('result_url: {} not open'.format(result_url))
    if not resp or not is_success(resp):
        return items.copy()
    return []
