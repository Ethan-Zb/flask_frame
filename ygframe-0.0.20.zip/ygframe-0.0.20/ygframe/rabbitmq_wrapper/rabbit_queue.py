# -*- coding:utf-8 -*-
"""
--------------------------------------------
File Name:rabbit_queue.py
Author:jing
Copyright:yiguotech.com
date:2018/05/29
--------------------------------------------
"""
from kombu import connections

from ygframe.task.instance_task import InstanceTask

from ygframe.task.task_manager import CoreTaskManager

from ygframe.queue.queue_handler import QueueHandler
from ygframe.rabbitmq_wrapper import get_rabbitmq_connection
from ygframe.rabbitmq_wrapper.rabbitmq_initializer import get_queue
from ygframe.scope.scope import Scope

__author__ = 'jing'


class RabbitQueue(QueueHandler):

    def __init__(self, key, callback_function=None, ack=True, scope=Scope.SYSTEM) -> None:
        self.key = key
        self.callback_function = callback_function
        self.ack = ack
        self.queue_name = '{}_{}'.format(Scope.get_scope_name(scope), key)
        if callback_function:
            self.start_rabbitmq_callback()

    def get_status(self) -> str:
        pass

    def get_description(self) -> str:
        return 'name:{}'.format(self.queue_name)

    def get_handle_key(self) -> str:
        return self.queue_name

    def clear(self):
        # todo delete and rebuild queue
        raise NotImplemented

    def empty(self) -> bool:
        return get_queue(self.queue_name).queue_declare()[1] == 0

    def full(self) -> bool:
        pass

    def put(self, body):
        with get_rabbitmq_connection() as connection:
            queue = connection.SimpleQueue(self.queue_name)
            queue.put(body)

    def get(self, block=True, timeout=None):
        with get_rabbitmq_connection() as connection:
            queue = connection.SimpleQueue(self.queue_name)
            message = queue.get(block=block, timeout=timeout)
            if self.ack:
                message.ack()
            queue.close()
            connection.close()
            return message.payload

    def rabbitmq_callback(self, block=True, timeout=None):
        with get_rabbitmq_connection() as connection:
            queue = connection.SimpleQueue(self.queue_name)
            while True:
                try:
                    message = queue.get(block=block, timeout=timeout)
                    self.callback_function(**message.payload)
                    if self.ack:
                        message.ack()
                    queue.close()
                    connection.close()
                except Exception as e:
                    queue = connection.SimpleQueue(self.queue_name)
                    continue

    def start_rabbitmq_callback(self):
        CoreTaskManager.register(
            InstanceTask(
                do_start=self.rabbitmq_callback,
                handle_key='rabbitmq_callback'
            )
        )
