# -*- coding:utf-8 -*-
"""
--------------------------------------------
File Name:__init__.py.py
Author:jing
Copyright:yiguotech.com
date:2018/05/08
--------------------------------------------
"""
from collections import namedtuple
from contextlib import contextmanager

from kombu import connections

__author__ = 'jing'

rabbitmq_url = None
connection = None


class Consumer(namedtuple('Consumer', ['queue_name', 'callback', 'exchange_name', 'exchange_type', 'routing_key', ])):
    """
    use in python 3.5.
    when updated to 3.6, change to:
        class Consumer(NamedTuple):
            queue_name:str
            callback
            exchange_name:str = ''
            exchange_type:str = 'direct'
            routing_key:str = ''
    witch is much better to write and read
    """
    __slots__ = ()

    # noinspection PyInitNewSignature,PyArgumentList
    def __new__(
            cls,
            queue_name: str,
            callback,
            exchange_name: str = '',
            exchange_type: str = 'direct',
            routing_key: str = '',
    ):
        return super(Consumer, cls).__new__(
            cls,
            queue_name,
            callback,
            exchange_name,
            exchange_type,
            routing_key,
        )


@contextmanager
def get_rabbitmq_connection():
    with connections[connection].acquire(block=True) as conn:
        yield conn
