# -*- coding:utf-8 -*-
"""
--------------------------------------------
File Name:rabbitmq_initializer.py
Author:jing
Copyright:yiguotech.com
date:2018/05/08
--------------------------------------------
"""
from functools import lru_cache, partial
from typing import List

from kombu import Queue, Exchange, Connection, Producer, Consumer, eventloop

from ygframe import rabbitmq_wrapper
from ygframe.logger.logger_context import error_exception
from ygframe.rabbitmq_wrapper import get_rabbitmq_connection
from ygframe.task.instance_task import InstanceTask
from ygframe.task.task_manager import CoreTaskManager
from ygframe.util.int_util import BIG_INT
from ygframe.util.retry import retry

__author__ = 'jing'


@error_exception(message='init rabbitmq error')
def init(url: str):
    rabbitmq_wrapper.rabbitmq_url = url
    rabbitmq_wrapper.connection = Connection(url)


@lru_cache()
def get_queue(queue_name, exchange_name=None, exchange_type='direct', routing_key=''):
    exchange_name = exchange_name or queue_name
    routing_key = routing_key or queue_name
    return Queue(queue_name, get_exchange(exchange_name, exchange_type), routing_key=routing_key)


@lru_cache()
def get_exchange(exchange_name, exchange_type):
    return Exchange(exchange_name, exchange_type)


@error_exception(
    message='error when trying to get queue size, will return a large number to prevent error',
    default=BIG_INT
)
def get_queue_size(queue_name):
    name, msg_count, consumer_count = get_queue(queue_name).queue_declare()
    return msg_count


@retry()
def publish(body: (str, dict), exchange_name='', exchange_type='direct', routing_key=''):
    with get_rabbitmq_connection() as connection:
        producer = Producer(connection)
        producer.publish(
            body,
            exchange=get_exchange(exchange_name, exchange_type),
            routing_key=routing_key,
        )


def put_message(queue_name, body):
    publish(body, exchange_name=queue_name, routing_key=queue_name)


def start_consuming(queue_name, callback, exchange_name=None, exchange_type='direct', routing_key=''):
    with get_rabbitmq_connection() as connection:
        with Consumer(
                connection,
                get_queue(queue_name, exchange_name, exchange_type, routing_key),
                callbacks=[callback]
        ):
            for _ in eventloop(connection):
                pass


def register_consumers(consumers: List[rabbitmq_wrapper.Consumer]):
    for consumer in consumers:
        CoreTaskManager.register(
            InstanceTask(
                do_start=partial(
                    start_consuming,
                    consumer.queue_name,
                    consumer.callback,
                    consumer.exchange_name,
                    consumer.exchange_type,
                    consumer.routing_key
                ),
                handle_key=consumer.queue_name
            )
        )
