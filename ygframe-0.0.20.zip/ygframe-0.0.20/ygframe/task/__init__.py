# -*- coding:utf-8 -*-
#
# Author:jing
# Copyright:yiguotech.com
# date:2018/05/06

# pylint:disable=missing-docstring
__author__ = 'jing'
