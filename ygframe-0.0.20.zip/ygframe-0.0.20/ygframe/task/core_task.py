# -*- coding:utf-8 -*-
#
# Author:jing
# Copyright:yiguotech.com
# date:2018/05/06

# pylint:disable=missing-docstring
from abc import abstractmethod
from threading import Condition, Thread, Event

from ygframe.globals.abstract_globals import AbstractGlobals
from ygframe.logger import logger
from ygframe.task.task_handler import TaskHandler
from ygframe.util.inspect_util import get_full_name

__author__ = 'jing'


class StopCoreTask(Exception):
    pass


class CoreTask(TaskHandler):
    def __init__(self) -> None:
        # control data
        self.condition = Condition()
        self.stop_event = Event()
        self.wait_event = Event()
        self.name = self.get_name()
        self.thread = None
        self.timeout = 0
        self.main_task = False

    def set_main_task(self, main_task):
        self.main_task = main_task

    def wait(self, timeout=None):
        """
        :param timeout: wait method to be called by admin api
        :return:
        """
        self.wait_event.set()
        self.timeout = timeout

    def _wait_for(self, timeout=None):
        """
        :param timeout: wait method to be called by subclass
        :return:
        """
        self.wait(timeout=timeout)
        self._ensure_alive()

    def _transaction_split_line(self):
        if not self._ensure_alive():
            raise StopCoreTask

    def _ensure_alive(self):
        if self.wait_event.is_set():
            with self.condition:
                notify = self.condition.wait_for(
                    lambda: not self.wait_event.is_set(), timeout=self.timeout)
                if notify:
                    logger.info('task {} has been notified'.format(self.name))
                else:
                    if AbstractGlobals().debug:
                        # logger.debug('waiting timeout. task {} continue running'.format(self.name))
                        pass
                self.wait_event.clear()
            self.timeout = 0
        if self.stop_event.is_set():
            logger.info('task {} has been stopped'.format(self.name))
            return False
        return True

    def notify(self):
        if self.is_alive():
            with self.condition:
                self.condition.notify()
        self.wait_event.clear()

    def is_alive(self):
        return self.thread and self.thread.is_alive() and not self.stop_event.is_set()

    def stop(self):
        self.notify()
        self.stop_event.set()

    def start(self):
        if self.is_alive():
            logger.warning('task {} is running, start command will be ignored.'.format(self.name))
        else:
            self.wait_event.clear()
            self.stop_event.clear()
            logger.info('start task: {} / {}'.format(self.name, self.get_description()))
            if self.main_task:
                logger.info('main task, current thread block from here.')
                self.run()
            else:
                logger.info('start new thread for the task.')
                self.thread = Thread(target=self.run)
                self.thread.start()
            self.stop_event.clear()

    def get_name(self):
        return self.get_handle_key()

    def get_status(self):
        if self.wait_event.is_set():
            return self.STATUS_WAITING
        if self.stop_event.is_set():
            return self.STATUS_STOPPING
        if self.is_alive():
            return self.STATUS_RUNNING
        return self.STATUS_INIT

    def get_description(self):
        return self.get_status()

    def get_handle_key(self):
        return get_full_name(self.__class__)

    @abstractmethod
    def run(self):
        pass  # pragma: no cover
