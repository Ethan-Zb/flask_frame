# -*- coding:utf-8 -*-
#
# Author:jing
# Copyright:yiguotech.com
# date:2018/05/06

# pylint:disable=missing-docstring,too-many-instance-attributes,too-many-arguments,broad-except
import datetime
import time
from functools import partial

from ygframe.logger import logger
from ygframe.scope.scope import Scope
from ygframe.task.core_task import CoreTask, StopCoreTask
from ygframe.util.inspect_util import get_full_name
from ygframe.util.int_util import BIG_INT

__author__ = 'jing'


class CyclicTask(CoreTask):

    def __init__(
            self,
            task,
            cyclic_wait,
            handle_key=None,
            max_error: int = BIG_INT,
            description=None
    ) -> None:
        self.task = task
        self.cyclic_wait = cyclic_wait
        self.handle_key = handle_key or super().get_handle_key()
        self.description = description or 'task {} run every {} seconds'.format(
            self.handle_key, cyclic_wait)
        self.max_error = max_error
        self.last_run = None
        self.turn = 0
        self.start_at = datetime.datetime.now()
        self.errors = 0
        super().__init__()

    def get_description(self) -> str:
        return self.description or super().get_description()

    def get_handle_key(self) -> str:
        return self.handle_key

    def clear_errors(self):
        self.errors = 0

    def get_status(self) -> str:
        return 'task {} start at {}, turn: {}, last run {}, next run {}, errs: {}'.format(
            self.handle_key,
            self.start_at,
            self.turn,
            datetime.datetime.fromtimestamp(self.last_run),
            datetime.datetime.fromtimestamp(self.last_run + self.cyclic_wait),
            self.errors
        )

    def get_name(self):
        return self.handle_key

    def run(self):
        while self._ensure_alive():
            self.turn += 1
            self.last_run = time.time()
            try:
                self._transaction_split_line()
                self.task()
            except StopCoreTask:
                break
            except Exception as exception:
                logger.exception('task {} runtime exception: {}'.format(
                    self.handle_key,
                    str(exception)
                ))
                self.errors += 1
                if self.max_error and self.errors >= self.max_error:
                    logger.critical('instance task {} reached error limit'.format(self.handle_key))
                    self.wait()
            self._wait_for(self.cyclic_wait)


def cyclic_task(cyclic_wait, handle_key=None, description='', max_error=BIG_INT, bind=False):
    def _decorate(func):
        task = CyclicTask(
            task=func,
            handle_key=handle_key or '{}.{}'.format(Scope.get_system_name(), get_full_name(func)),
            cyclic_wait=cyclic_wait,
            description=description,
            max_error=max_error,
        )
        if bind:
            task.task = partial(func, task)
        return task

    return _decorate
