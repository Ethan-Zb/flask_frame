# -*- coding:utf-8 -*-
#
# Author:jing
# Copyright:yiguotech.com
# date:2018/05/06

# pylint:disable=missing-docstring
from abc import abstractmethod

from ygframe.interface.handler_interface import HandlerInterface

__author__ = 'jing'


class TaskHandler(HandlerInterface):
    STATUS_INIT = 'init'
    STATUS_RUNNING = 'running'
    STATUS_WAITING = 'waiting'
    STATUS_STOPPING = 'stopping'
    STATUS_STOPPED = 'stopped'

    @abstractmethod
    def start(self):
        raise NotImplementedError  # pragma: no cover

    @abstractmethod
    def stop(self):
        raise NotImplementedError  # pragma: no cover

    @abstractmethod
    def is_alive(self):
        raise NotImplementedError  # pragma: no cover

    @abstractmethod
    def wait(self, timeout=None):
        raise NotImplementedError  # pragma: no cover

    @abstractmethod
    def notify(self):
        raise NotImplementedError  # pragma: no cover
