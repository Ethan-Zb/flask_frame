# -*- coding:utf-8 -*-
#
# Author:jing
# Copyright:yiguotech.com
# date:2018/05/06

# pylint:disable=missing-docstring,too-many-instance-attributes,bare-except,too-many-arguments
import time
import traceback
from functools import partial

from ygframe.logger import logger
from ygframe.task.core_task import CoreTask, StopCoreTask
from ygframe.util.backoff import exponential_backoff
from ygframe.util.inspect_util import get_full_name

__author__ = 'jing'


class InstanceTask(CoreTask):

    def __init__(
            self,
            do_start,
            handle_key,
            do_stop=None,
            status='',
            description='',
            restart_on_exception=True,
            backoff=exponential_backoff,
            main_task=False
    ) -> None:
        self.do_start = do_start
        self.handle_key = handle_key
        self.do_stop = do_stop or (lambda: None)
        self.status = status
        self.description = description
        self.restart_on_exception = restart_on_exception
        self.backoff = backoff
        self.restart_turn = 0

        super().__init__()
        super().set_main_task(main_task)

    def run(self):
        keep_running = True
        while keep_running:
            try:
                self._transaction_split_line()
                self.do_start()
                self._transaction_split_line()
                keep_running = False
            except StopCoreTask:
                keep_running = False
            except:
                logger.exception('task {} runtime exception: {}'.format(
                    self.handle_key,
                    traceback.format_exc(30)
                ))
                if self.restart_on_exception:
                    self.restart_turn += 1
                    wait = self.backoff(self.restart_turn)
                    time.sleep(wait)
                    logger.info('restart turn is {},next turn will start in {}s'.format(
                        self.restart_turn,
                        wait
                    ))

    def stop(self):
        self.do_stop()
        super().stop()

    def get_description(self) -> str:
        return self.description or super().get_description()

    def get_status(self) -> str:
        return self.status or super().get_status()

    def get_handle_key(self) -> str:
        return self.handle_key


def instance_task(
        handle_key=None,
        do_stop=None,
        description='',
        restart_on_exception=True,
        backoff=exponential_backoff,
        bind=False
):
    if callable(handle_key):
        return InstanceTask(do_start=handle_key, handle_key=get_full_name(handle_key))

    def _decorate(func):
        task = InstanceTask(
            do_start=func,
            handle_key=handle_key or get_full_name(func), do_stop=do_stop,
            description=description,
            restart_on_exception=restart_on_exception,
            backoff=backoff
        )
        if bind:
            task.do_start = partial(func, task)
        return task

    return _decorate
