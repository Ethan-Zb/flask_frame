# -*- coding:utf-8 -*-
#
# Author:jing
# Copyright:yiguotech.com
# date:2018/05/06

# pylint:disable=missing-docstring
from ygframe.interface.manager_interface import ManagerInterface

__author__ = 'jing'


class CoreTaskManager(ManagerInterface):
    __url_key__ = 'task'

    @classmethod
    def start(cls, key):
        cls.get_handler_dict().get(key).start()

    @classmethod
    def stop(cls, key):
        cls.get_handler_dict().get(key).stop()

    @classmethod
    def wait(cls, key):
        cls.get_handler_dict().get(key).wait()

    @classmethod
    def notify(cls, key):
        cls.get_handler_dict().get(key).notify()

    @classmethod
    def start_all(cls):
        for handler in cls.get_handler_dict().values():
            handler.start()

    @classmethod
    def stop_all(cls):
        for handler in cls.get_handler_dict().values():
            handler.stop()
