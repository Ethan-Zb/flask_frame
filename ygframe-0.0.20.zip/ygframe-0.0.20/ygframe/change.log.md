v0.0.15
##### #20180703
+) change.log,base_counter_item,
*) scanner with_try
*) logger with try, default print
##### #20180712
+) flask app strict_slashes set to False
*) hbase give up pool, use connection directly
+) scanner util add default size
##### #20180720
+) modify statistic: use meta handler
##### #20180726
+) add system config
+) refactor celery: add route
+) dict util: ensure get
+) pid util

v0.0.16
##### #20180801
*) flask
*) celery


