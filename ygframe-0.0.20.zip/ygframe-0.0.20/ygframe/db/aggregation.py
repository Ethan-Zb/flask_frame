# -*- coding:utf-8 -*-
# File Name:aggregation.py
# Author:jing
# Copyright:yiguotech.com
# Date:2018/11/12
from ygframe.db.column import Column

__author__ = 'jing'


class Aggregation(Column):
    __function__ = None

    def __init__(self, column: Column) -> None:
        object.__init__(self)
        self.key = {
            self.__function__: column
        }


"""
avg	count	first	max	min	stdev	stdevp	sum	var	varp
ucase	lcase	mid	len	instr	left	right	round	mod	now	format	datediff
"""


class Sum(Aggregation):
    __function__ = 'sum'


class Avg(Aggregation):
    __function__ = 'avg'


class Count(Aggregation):
    __function__ = 'count'


class Min(Aggregation):
    __function__ = 'min'


class Max(Aggregation):
    __function__ = 'max'


class Mid(Aggregation):
    __function__ = 'mid'


class Stdev(Aggregation):
    __function__ = 'stdev'


class Stdevp(Aggregation):
    __function__ = 'stdevp'


class Var(Aggregation):
    __function__ = 'var'


class Varp(Aggregation):
    __function__ = 'varp'


class Len(Aggregation):
    __function__ = 'len'
