# -*- coding:utf-8 -*-
# File Name:column_docable.py
# Author:jing
# Copyright:yiguotech.com
# Date:2018/11/28
from functools import lru_cache
from typing import Any

from ygframe.db.column import Column
from ygframe.util import NotSet
from ygframe.util.inspect_util import get_main_file_path
from ygframe.util.str_util import get_between

__author__ = 'jing'


class ColumnDocable:
    def __init__(self, **kwargs) -> None:
        for key, value in self.get_column_dict().items():
            if isinstance(value, Column) and value.default and key not in kwargs:
                default = value.default() if callable(value.default) else value.default
                setattr(self, key, default)
        self.after_init()

    def after_init(self):
        pass

    @classmethod
    def create(cls, **obj):
        ret = object.__new__(cls)
        ret.__dict__.update(obj)
        return ret

    @classmethod
    @lru_cache()
    def get_column_keys(cls):
        return [column.key for column in cls.get_columns()]

    @classmethod
    @lru_cache()
    def get_column_dict(cls):
        return {column.key: column for column in cls.get_columns()}

    @classmethod
    @lru_cache()
    def get_columns(cls):
        columns = []
        for k, v in cls.__dict__.items():
            if isinstance(v, Column):
                if not v.key:
                    v.key = k
                columns.append(v)
        return columns

    @classmethod
    def _get_column_init(cls, column):
        if callable(column.default):
            return 'self.{} = {} or {}()'.format(column.key, column.key, column.default.__name__)
        return 'self.{} = {}'.format(column.key, column.key)

    @classmethod
    def _get_column_line(cls, column):
        type_name = column.key_type.__name__
        if column.default is not NotSet:
            if not callable(column.default):
                return '{}: {} = {}'.format(column.key, type_name, repr(column.default))
        return '{}: {} = None'.format(column.key, type_name)

    def dumps(self):
        return {
            key: value
            for key, value in self.__dict__.items()
            if value is not None
        }

    def __getattribute__(self, name: str) -> Any:
        value = super().__getattribute__(name)
        if isinstance(value, Column):
            return None
        return value

    @classmethod
    def get_init_method(cls):
        template = """    def __init__(
            self,
            {column_lines}
    ) -> None:
        object.__init__(self)
        {init_lines}
        self.after_init()
"""
        columns = cls.get_columns()
        column_list = '"{}"'.format(
            '", "'.join(cls.get_column_keys())
        )
        column_lines = ',\n            '.join([
            cls._get_column_line(column)
            for column in columns
        ])
        init_lines = '\n        '.join([
            cls._get_column_init(column)
            for column in columns
        ])
        return template.format(**dict(
            column_list=column_list, column_lines=column_lines, init_lines=init_lines
        ))

    @classmethod
    def regenerate_init_method(cls):
        file_path = get_main_file_path()
        with open(file_path) as file:
            content = file.read()
            if 'def __init__' in content:
                between = get_between(content, 'def __init__', 'if __name__', include_left=True)
                content = content.replace(between, cls.get_init_method().strip() + '\n\n\n')
            else:
                temp = []
                for line in content.splitlines():  # type:str
                    if line.startswith('if __name__'):
                        temp.append('\n' + cls.get_init_method())
                    temp.append(line)
                content = '\n'.join(temp)
        with open(file_path, 'w') as file:
            file.write(content)
