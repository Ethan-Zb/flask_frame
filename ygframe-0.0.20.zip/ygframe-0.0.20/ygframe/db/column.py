# -*- coding:utf-8 -*-
# File Name:column.py
# Author:jing
# Copyright:yiguotech.com
# Date:2018/11/29
from ygframe.db import SortOrder
from ygframe.db.filter import SimpleFilter, FilterOp
from ygframe.serialize.dict_serializable import DictSerializable

__author__ = 'jing'


class Column(DictSerializable):

    def __init__(
            self,
            key_type: type = str,
            key: str = None,
            default=None,
            index=False,
            unique=False,
            description='',
            one_of: type = None,
    ):
        self.key_type = key_type
        self.key = key
        self.default = default
        self.index = index
        self.unique = unique
        self.description = description
        self.one_of = one_of

    def __eq__(self, value: object):
        return SimpleFilter(self.key, FilterOp.EQUAL, value)

    def __ne__(self, value):
        return SimpleFilter(self.key, FilterOp.NOT_EQUAL, value)

    def __lt__(self, value):
        return SimpleFilter(self.key, FilterOp.LESS_THAN, value)

    def __gt__(self, value):
        return SimpleFilter(self.key, FilterOp.GREATER_THAN, value)

    def __le__(self, value):
        return SimpleFilter(self.key, FilterOp.LESS_OR_EQUAL, value)

    def __ge__(self, value):
        return SimpleFilter(self.key, FilterOp.GREATER_OR_EQUAL, value)

    def in_(self, items):
        return SimpleFilter(self.key, FilterOp.IN, items)

    def not_in(self, value):
        return SimpleFilter(self.key, FilterOp.NOT_IN, value)

    def contains(self, value):
        return SimpleFilter(self.key, FilterOp.CONTAINS, value)

    def exist(self):
        return SimpleFilter(self.key, FilterOp.EXIST, True)

    def missing(self):
        return SimpleFilter(self.key, FilterOp.MISSING, True)

    def prefix(self, value):
        return SimpleFilter(self.key, FilterOp.PREFIX, value)

    def regex(self, regex):
        return SimpleFilter(self.key, FilterOp.REGEX, regex)

    def desc(self):
        return self.key, SortOrder.DESC

    def asc(self):  # default
        return self.key, SortOrder.ASC


def key(k: str):
    return Column(key=k)
