# -*- coding:utf-8 -*-
"""
--------------------------------------------
File Name:abstract_model.py
Author:jing
Copyright:yiguotech.com
date:2018/10/15
--------------------------------------------
"""
from abc import abstractmethod

from ygframe.db.column import Column
from ygframe.db.column_docable import ColumnDocable
from ygframe.db.query import Query, Queryable

__author__ = 'jing'


class AbstractModel(ColumnDocable):
    @classmethod
    def query(cls, *columns: Column):
        registered = cls.get_columns()
        columns = columns or registered
        return Query(cls).query(*[column.key for column in columns if column in registered])

    @classmethod
    def exclude(cls, *columns: Column):
        registered = cls.get_columns()
        return Query(cls).exclude(*[column.key for column in columns if column in registered])

    @abstractmethod
    def save(self):
        raise NotImplementedError

    @classmethod
    @abstractmethod
    def save_all(cls, obj):
        raise NotImplementedError

    @abstractmethod
    def get(self, query: Query):
        raise NotImplementedError

    @abstractmethod
    def delete(self, query: Query):
        raise NotImplementedError

    @abstractmethod
    def update(self, query: Query, obj):
        raise NotImplementedError

    @abstractmethod
    def upsert(self, query: Query, obj):
        raise NotImplementedError

    @abstractmethod
    def count(self, query: Query):
        raise NotImplementedError
