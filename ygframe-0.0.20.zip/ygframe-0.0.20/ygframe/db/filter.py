# -*- coding:utf-8 -*-
# File Name:filter.py
# Author:jing
# Copyright:yiguotech.com
# Date:2018/11/29
import re
from abc import abstractmethod

from ygframe.serialize.dict_serializable import DictSerializable

__author__ = 'jing'


class Filter(DictSerializable):

    @abstractmethod
    def check_dict(self, data: dict) -> bool:
        return False

    def check_object(self, obj) -> bool:
        return self.check_dict(obj.__dict__)


class SimpleFilter(Filter):

    def __init__(self, field, op, value) -> None:
        self.field = field
        self.op = op
        self.value = value

    def __str__(self):
        return "SimpleFilter[{}]".format((self.field, self.op, self.value))

    def check_dict(self, data: dict) -> bool:
        if self.op == FilterOp.EXIST:
            return self.field in data
        if self.op == FilterOp.MISSING:
            return self.field not in data
        if self.field not in data:
            return False
        value = data.get(self.field)
        method = {
            FilterOp.EQUAL: lambda x, y: x == y,
            FilterOp.CONTAINS: lambda x, y: y in x,
            FilterOp.PREFIX: lambda x, y: x.startswith(y),
            FilterOp.GREATER_THAN: lambda x, y: x > y,
            FilterOp.GREATER_OR_EQUAL: lambda x, y: x >= y,
            FilterOp.IN: lambda x, y: x in y,
            FilterOp.LESS_THAN: lambda x, y: x < y,
            FilterOp.LESS_OR_EQUAL: lambda x, y: x <= y,
            FilterOp.NOT_EQUAL: lambda x, y: x != y,
            FilterOp.NOT_IN: lambda x, y: x not in y,
            FilterOp.REGEX: lambda x, y: re.match(y, x) is not None
        }.get(self.op)
        if method:
            return method(value, self.value)


class And(Filter):

    def __init__(self, *filters: Filter):
        self.filters = filters

    def check_dict(self, data: dict) -> bool:
        for flt in self.filters:
            if not flt.check_dict(data):
                return False
        return True


class Or(Filter):
    def __init__(self, *filters: Filter):
        self.filters = filters

    def check_dict(self, data: dict) -> bool:
        for flt in self.filters:
            if flt.check_dict(data):
                return True
        return False


class Not(Filter):
    def __init__(self, flt: Filter):
        self.flt = flt

    def check_dict(self, data: dict) -> bool:
        return not self.flt.check_dict(data)


class FilterOp:
    EQUAL = 'eq'
    NOT_EQUAL = 'ne'
    GREATER_OR_EQUAL = 'ge'
    LESS_OR_EQUAL = 'le'
    GREATER_THAN = 'gt'
    LESS_THAN = 'lt'
    IN = 'in'
    NOT_IN = 'nin'
    CONTAINS = 'contains'
    EXIST = 'exist'
    MISSING = 'missing'
    PREFIX = 'prefix'
    REGEX = 'regex'
    AND = 'and'
    OR = 'or'
    NOT = 'not'