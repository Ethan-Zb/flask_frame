# -*- coding:utf-8 -*-
# File Name:query.py
# Author:jing
# Copyright:yiguotech.com
# Date:2018/11/29
from abc import abstractmethod

from ygframe.db import GetMode
from ygframe.db.filter import Filter, And
from ygframe.serialize.dict_serializable import DictSerializable
from ygframe.util.inspect_util import get_full_name, load_by_full_name

__author__ = 'jing'


class Queryable:
    @abstractmethod
    def get(self):
        raise NotImplementedError

    @abstractmethod
    def delete(self):
        raise NotImplementedError

    @abstractmethod
    def update(self, obj):
        raise NotImplementedError

    @abstractmethod
    def upsert(self, obj):
        raise NotImplementedError

    @abstractmethod
    def count(self):
        raise NotImplementedError


class Query(DictSerializable, Queryable):
    def __init__(self, model_class) -> None:
        self.model_class = get_full_name(model_class)
        self.query_ = []
        self.exclude_ = []
        self.filter_ = []
        self.sort_by_ = []
        self.page_num_ = 0
        self.page_size_ = 0
        self.skip_ = 0
        self.group_by_ = []
        self.having_ = []
        self.get_mode_ = GetMode.ALL

    def get_model_class(self):
        return load_by_full_name(self.model_class)

    def query(self, *columns: str):
        self.query_ = columns
        return self

    def exclude(self, *columns: str):
        self.exclude_ = columns
        return self

    def has_skip_limit(self):
        return self.skip_ or self.page_num_ or self.page_size_

    def get_skip(self):
        if self.skip_:
            return self.skip_
        if self.page_num_ and isinstance(self.page_num_, int):
            return (self.page_num_ - 1) * self.get_limit()
        return 0

    def get_limit(self):
        return self.page_size_ or 10

    def skip(self, n):
        self.skip_ = n
        return self

    def limit(self, n=10):
        self.page_size_ = n
        return self

    def filter(self, *filters: Filter):
        if len(filters) == 1:
            self.filter_ = filters[0]
        else:
            self.filter_ = And(*filters)
        return self

    def having(self, *filters: Filter):
        if len(filters) == 1:
            self.having_ = filters[0]
        else:
            self.having_ = And(*filters)
        return self

    def sort_by(self, *sorters):
        self.sort_by_ = sorters
        return self

    def page_num(self, page_num):
        self.page_num_ = page_num
        return self

    def page_size(self, page_size: int = 10):
        self.page_size_ = page_size
        return self

    def first(self):
        self.get_mode_ = GetMode.FIRST
        return self

    def all(self):
        self.get_mode_ = GetMode.ALL
        return self

    def count(self):
        return self.get_model_class().count(self)

    def get(self):
        return self.get_model_class().get(self)

    def update(self, obj):
        return self.get_model_class().update(self, obj)

    def upsert(self, obj):
        return self.get_model_class().upsert(self, obj)

    def delete(self):
        return self.get_model_class().delete(self)
