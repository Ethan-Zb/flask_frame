# -*- coding:utf-8 -*-
"""
--------------------------------------------
File Name:__init__.py.py
Author:jing
Copyright:yiguotech.com
date:2018/10/18
--------------------------------------------
"""

__author__ = 'jing'


class SortOrder:
    DESC = -1
    ASC = 1


class GetMode:
    FIRST = 1
    ALL = 2
