# -*- coding:utf-8 -*-
# File Name:schema_builder.py
# Author:jing
# Copyright:yiguotech.com
# date:2018/10/24

"""
help to build json schema
"""
__author__ = 'jing'


class Args:
    """
    Base class to provide common attributes to json schema
    """

    def __init__(self, name) -> None:
        self.name = name
        self.schema = {}

    def title(self, title):
        """
        :param title: add attribute `title`
        :return: `self`
        """
        return self.update(title=title)

    def description(self, description):
        """
        :param description: add attribute `description`
        :return: `self`
        """
        return self.update(description=description)

    def update(self, **kwargs):
        """
        :param kwargs: update key-value entry to json schema.
        :return: `self`
        """
        self.schema.update(kwargs)
        return self

    def get(self):
        """
        :return: json schema dict
        """
        return self.schema


class Enum(Args):

    def one_of(self, *items):
        return self.update(enum=list(items))


class Type(Args):
    __type__ = None

    def __init__(self, name: str = None) -> None:
        super().__init__(name)
        self.update(type=self.__type__)

    def type(self, args_type):
        return self.update(type=args_type)


class Num(Type):
    __type__ = 'number'

    def le(self, maximum):
        return self.update(maximum=maximum)

    def lt(self, exclusive_maximum):
        return self.update(exclusiveMaximum=True).le(exclusive_maximum)

    def gt(self, exclusive_minimum):
        return self.update(exclusiveMinimum=True).ge(exclusive_minimum)

    def ge(self, minimum):
        return self.update(minimum=minimum)

    def positive(self):
        return self.gt(0)

    def negative(self):
        return self.lt(0)


class Int(Num):
    __type__ = 'integer'


class Str(Type):
    __type__ = 'string'

    def max_len(self, max_length):
        return self.update(maxLength=max_length)

    def min_len(self, min_length):
        return self.update(minLength=min_length)

    def len(self, length):
        return self.max_len(length).min_len(length)

    def pattern(self, pattern):
        return self.update(pattern=pattern)

    def not_empty(self):
        return self.update(minLength=1)


class List(Type):
    __type__ = 'array'

    def items(self, *schemas: Args):
        if not schemas:
            schema = Str().get()
        elif len(schemas) > 1:
            schema = [s.get() for s in schemas]
        else:
            schema = schemas[0].get()
        return self.update(items=schema)

    def contains(self, *schemas: Args):
        if not schemas:
            schema = Str().get()
        elif len(schemas) > 1:
            schema = [s.get() for s in schemas]
        else:
            schema = schemas[0].get()
        return self.update(contains=schema)

    def max_items(self, max_items):
        return self.update(maxItems=max_items)

    def min_items(self, min_items):
        return self.update(minItems=min_items)

    def unique(self):
        return self.update(uniqueItems=True)

    def not_empty(self):
        return self.min_items(1)

    def len(self, length):
        return self.min_items(length).max_items(length)


class Object(Type):
    __type__ = 'object'

    def __init__(self, name: str = None) -> None:
        super().__init__(name)

    def get_properties(self):
        return self.schema.setdefault('properties', {})

    def requires(self, *properties: Args):
        self.optional(*properties)
        return self.update(required=[p.name for p in properties])

    def optional(self, *properties):
        self.get_properties().update({
            p.name: p.get()
            for p in properties
        })
        return self
