# -*- coding:utf-8 -*-
#
# Author:jing
# Copyright:yiguotech.com
# Date:2018/05/06

from ygframe.interface.manager_interface import ManagerInterface

__author__ = 'jing'


class AdminManager(ManagerInterface):
    pass
