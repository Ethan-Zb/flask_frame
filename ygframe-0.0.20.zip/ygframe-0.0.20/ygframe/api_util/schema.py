# -*- coding:utf-8 -*-
#
# Author:jing
# Copyright:yiguotech.com
# date:2018/05/06

__author__ = 'jing'


class _Schema(object):  # pylint: disable=too-few-public-methods
    DESCRIPTION = 'description'
    TYPE = 'type'
    PROPERTIES = 'properties'
    REQUIRED = 'required'
    ITEMS = 'items'
    MIN_LEN = 'minLength'
    MAX_LEN = 'maxLength'
    ENUM = 'enum'

    class Types:  # pylint: disable=too-few-public-methods
        """ value of types of schema"""
        NULL = 'null'
        BOOLEAN = 'boolean'
        OBJECT = 'object'
        LIST = 'array'
        NUMBER = 'number'
        STRING = 'string'
        INT = 'integer'


SCHEMA = _Schema()
