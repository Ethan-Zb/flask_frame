# -*- coding:utf-8 -*-
#
# Author:jing
# Copyright:yiguotech.com
# date:2018/05/06

from flask import request, jsonify

from ygframe import SYSTEM_CONFIG
from ygframe.interface.handler_interface import HandlerInterface
from ygframe.interface.manager_interface import ManagerInterface
from ygframe.scope.scope import Scope
from ygframe.task.task_manager import CoreTaskManager
from ygframe.util import NotSet
from ygframe.util.import_util import get_all

__author__ = 'jing'


class AdminManagers(object):  # pylint: disable=too-few-public-methods
    """
    manage managers
    """
    managers = set()

    @classmethod
    def register_all(cls, *managers) -> None:
        """
        :param managers: item of manager must be subclass of `ManagerInterface`
        :return: None
        """
        for manager in managers:
            if not issubclass(manager, ManagerInterface):
                raise ValueError('{} is not a subclass of ManagerInterface'.format(manager))
            if not manager.__url_key__:
                raise ValueError('subclass of ManagerInterface must has attribute __url_key__')
            cls.managers.add(manager)

    @classmethod
    def get_manager_dict(cls) -> dict:
        return {
            manager.__url_key__: manager
            for manager in cls.managers
        }


class BaseAdmin(object):  # pylint: disable=too-few-public-methods
    """
    base class of admin
    """

    @classmethod
    def get(cls) -> dict:
        """
        :return: get data and operators
        """
        result = {}
        for manager in AdminManagers.managers:
            if not issubclass(manager, ManagerInterface):
                continue
            if not isinstance(manager.__url_key__, str):
                continue
            handler_data = {}
            result[manager.__url_key__] = handler_data
            for handler in manager.get_handler_dict().values():
                if not isinstance(handler, HandlerInterface):
                    continue
                handler_data[handler.get_handle_key()] = {
                    'description': handler.get_description(),
                    'status': handler.get_status(),
                    'commands': handler.get_commands(),
                }
        return result

    @classmethod
    def execute(cls, url_key, handle_key, command, *args, **kwargs):
        manager = AdminManagers.get_manager_dict().get(url_key)
        if not isinstance(manager, ManagerInterface):
            raise TypeError
        handler = manager.get_handler(handle_key)
        cmd = getattr(handler, command)
        try:
            return cmd(*args, **kwargs)
        except:
            return None


def register_admin_manager(app, admin_manager_list: list = NotSet):
    if admin_manager_list is NotSet:
        admin_manager_list = []
    elif not admin_manager_list:
        return
    admin_manager_list.append(CoreTaskManager)
    for manager in get_all(SYSTEM_CONFIG.MANAGER_MODULE_NAME, ManagerInterface):
        if manager.__name__.startswith('Base'):
            continue
        admin_manager_list.append(manager)
    AdminManagers.register_all(*admin_manager_list)
    app.route(
        '{}/<url_key>/all'.format(Scope.get_admin_prefix()),
        methods=['GET']
    )(get)
    app.route(
        '{}/<url_key>/<handle_key>'.format(Scope.get_admin_prefix()),
        methods=['POST']
    )(post)


def get(url_key):
    for manager in AdminManagers.managers:
        if not isinstance(manager, type) or not issubclass(manager, ManagerInterface):
            continue
        if manager.__url_key__ == url_key:
            data = {}
            for handle_key, handler in manager.get_handler_dict().items():
                data[handle_key] = {
                    'description': handler.get_description(),
                    'status': handler.get_status(),
                    'commands': handler.get_commands()
                }
            return jsonify(data)


def post(url_key, handle_key):
    request_json = request.json
    command = request_json.get('command')
    args = request_json.get('args') or tuple()
    kwargs = request_json.get('kwargs') or dict()
    for manager in AdminManagers.managers:
        if not isinstance(manager, type) or not issubclass(manager, ManagerInterface):
            continue
        if manager.__url_key__ == url_key:
            handler = manager.get_handler_dict().get(handle_key)
            if not isinstance(handler, HandlerInterface):
                continue
            cmd = getattr(handler, command)
            if not callable(cmd):
                continue
            return jsonify(cmd(*args, **kwargs))
