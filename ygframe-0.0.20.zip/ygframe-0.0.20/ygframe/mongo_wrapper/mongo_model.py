# -*- coding:utf-8 -*-
"""
--------------------------------------------
File Name:mongo_model.py
Author:jing
Copyright:yiguotech.com
date:2018/10/13
--------------------------------------------
"""
from functools import lru_cache

from pymongo import DESCENDING, ASCENDING, IndexModel

from ygframe.db import GetMode, SortOrder
from ygframe.db.abstract_model import AbstractModel
from ygframe.db.filter import Filter, SimpleFilter, And, Or, Not, FilterOp
from ygframe.db.query import Query
from ygframe.mongo_wrapper import get_mongo_client
from ygframe.mongo_wrapper.mongo_update_builder import MongoUpdateBuilder
from ygframe.scope.scope import Scope
from ygframe.util.str_util import get_snake_case

__author__ = 'jing'


class AbstractMongoModel(AbstractModel):
    __db_name__ = None
    __collection_name__ = None
    __index_list__ = None

    """
    >>> from pymongo import IndexModel, ASCENDING, DESCENDING
    >>> __index_list__ = [IndexModel([("hello", DESCENDING),
    ...                      ("world", ASCENDING)], name="hello_world"),
    ...                     IndexModel([("goodbye", DESCENDING)])]
    """

    @classmethod
    @lru_cache()
    def _get_op(cls, op):
        return {
            FilterOp.EQUAL: '$eq',
            FilterOp.CONTAINS: '$eq',
            FilterOp.PREFIX: '#',
            FilterOp.GREATER_THAN: '$gt',
            FilterOp.GREATER_OR_EQUAL: '$gte',
            FilterOp.IN: '$in',
            FilterOp.LESS_THAN: '$lt',
            FilterOp.LESS_OR_EQUAL: '$lte',
            FilterOp.NOT_EQUAL: '$ne',
            FilterOp.NOT_IN: '$nin',
            FilterOp.AND: '$and',
            FilterOp.OR: '$or',
            FilterOp.NOT: '$not',
            FilterOp.EXIST: '$exists',
            FilterOp.REGEX: '$regex'
        }.get(op)

    @classmethod
    def _converted_generator(cls, generator):
        for item in generator:
            yield cls.create(**item)

    @classmethod
    def _get_criteria(cls, flt: Filter):
        if isinstance(flt, SimpleFilter):
            if flt.op == FilterOp.PREFIX:
                return cls._get_criteria(SimpleFilter(flt.field, FilterOp.REGEX, '^' + flt.value))
            return {flt.field: {cls._get_op(flt.op): flt.value}}
        if isinstance(flt, And):
            return {cls._get_op(FilterOp.AND): [
                cls._get_criteria(f)
                for f in flt.filters
            ]}
        if isinstance(flt, Or):
            return {cls._get_op(FilterOp.OR): [
                cls._get_criteria(f)
                for f in flt.filters
            ]}
        if isinstance(flt, Not):
            return {cls._get_op(FilterOp.NOT): cls._get_criteria(flt.flt)}

        if not flt:
            return {}

    @classmethod
    def _get_expression(cls, query: Query):
        query_criteria = cls._get_criteria(query.filter_)
        if query.query_:
            projection = {field: 1 for field in query.query_}
        else:
            projection = {field: 0 for field in query.exclude_}
        sorter = [
            (field, DESCENDING if order == SortOrder.DESC else ASCENDING)
            for field, order in query.sort_by_
        ]
        return query_criteria, projection, sorter

    @classmethod
    def get(cls, query: Query):
        query_criteria, projection, sorter = cls._get_expression(query)
        if query.get_mode_ == GetMode.FIRST:
            result_dict = cls.get_collection().find_one(query_criteria, projection)
            if result_dict:
                return cls.create(**result_dict)
        if query.get_mode_ == GetMode.ALL:
            cursor = cls.get_collection().find(query_criteria, projection)
            if sorter:
                cursor.sort(sorter)
            if query.has_skip_limit():
                cursor.skip(query.get_skip()).limit(query.get_limit())
            return cls._converted_generator(cursor)

    @classmethod
    def count(cls, query: Query):
        query_criteria = cls._get_criteria(query.filter_)
        return cls.get_collection().find(query_criteria).count()

    @classmethod
    def update(cls, query: Query, obj, upsert=False):
        if isinstance(obj, AbstractModel):
            obj = cls.create_update_builder().set(obj.dumps()).get()

        if query.get_mode_ == GetMode.FIRST:
            return cls.get_collection().update_one(cls._get_criteria(query.filter_), obj, upsert=upsert)
        else:
            return cls.get_collection().update_many(cls._get_criteria(query.filter_), obj, upsert=upsert)

    @classmethod
    def create_update_builder(cls):
        return MongoUpdateBuilder()

    @classmethod
    def upsert(cls, query: Query, obj):
        return cls.update(query, obj, True)

    @classmethod
    def delete(cls, query: Query):
        if query.get_mode_ == GetMode.FIRST:
            cls.get_collection().delete_one(cls._get_criteria(query.filter_))
        else:
            cls.get_collection().delete_many(cls._get_criteria(query.filter_))

    def save(self):
        return self.get_collection().insert_one(self.dumps())

    @classmethod
    def save_all(cls, obj):
        return cls.get_collection().insert([o.dumps() for o in obj])

    @classmethod
    def get_collection(cls):
        return get_mongo_client().get_database(
            cls.get_db_name()).get_collection(cls.get_collection_name())

    @classmethod
    def get_db_name(cls):
        if not cls.__db_name__:
            cls.__db_name__ = Scope.get_system_name()
        return cls.__db_name__

    @classmethod
    def get_collection_name(cls):
        if not cls.__collection_name__:
            cls.__collection_name__ = get_snake_case(cls.__name__)
        return cls.__collection_name__

    @classmethod
    def get_index_list(cls):
        if not cls.__index_list__:
            cls.__index_list__ = []
        for column in cls.get_columns():
            if column.index:
                if column.index is True:
                    column.index = DESCENDING
                cls.__index_list__.append(IndexModel([(column.key, column.index)], unique=column.unique))
        return cls.__index_list__
