# -*- coding:utf-8 -*-
"""
--------------------------------------------
File Name:__init__.py.py
Author:jing
Copyright:yiguotech.com
date:2018/10/13
--------------------------------------------
"""
from pymongo import MongoClient
from ygframe.util.precondition import not_none

__author__ = 'jing'

auth_args = None
mongo_dict = None
mongo_client = None


def get_mongo_client() -> MongoClient:
    client = not_none(mongo_client, error_message='mongo has not been initialized')  # type:MongoClient
    return client
