# -*- coding:utf-8 -*-
"""
--------------------------------------------
File Name:mongo_initializer.py
Author:jing
Copyright:yiguotech.com
date:2018/10/13
--------------------------------------------
"""
from itertools import chain

import pymongo

from ygframe import SYSTEM_CONFIG, mongo_wrapper
from ygframe.logger import logger
from ygframe.mongo_wrapper.mongo_model import AbstractMongoModel
from ygframe.util.import_util import get_all

__author__ = 'jing'


def init(
        host='127.0.0.1',
        port=27017,
        username=None,
        password=None,
        max_pool_size=None,
        mongo_models=None,
        **kwargs
):
    logger.info('init mongo start...')
    client = pymongo.MongoClient(host=host, port=port, maxPoolSize=max_pool_size, **kwargs)
    if username:
        client.admin.authenticate(username, password)
        mongo_wrapper.auth_args = username, password
    mongo_wrapper.mongo_dict = dict(host=host, port=port, **kwargs)
    mongo_wrapper.mongo_client = client
    mongo_models = mongo_models or []
    mongo_info = {}
    try:
        for mongo_model in chain(mongo_models, get_all(SYSTEM_CONFIG.MONGO_MODEL_MODULE_NAME, AbstractMongoModel)):
            if not issubclass(mongo_model, AbstractMongoModel):
                continue
            mongo_model.get_column_keys()
            db_name = mongo_model.get_db_name()
            collection_dict = mongo_info.setdefault(db_name, dict())
            collection_dict[mongo_model.get_collection_name()] = mongo_model.get_index_list()
    except ImportError as e:
        logger.error('load mongo module error {}'.format(str(e)))

    for db_name, db_info in mongo_info.items():
        db = client.get_database(db_name)
        collections = db.list_collection_names()
        for collection_name, index_list in db_info.items():
            if collection_name in collections:
                collection = db.get_collection(collection_name)
                if collection.count() > 0:
                    logger.info('collection {} is not empty, index will be ignored'.format(collection_name))
                    continue
            else:
                collection = db.create_collection(collection_name)
                logger.info('mongo created collection {} done'.format(collection_name))
            if index_list:
                collection.create_indexes(index_list)
            logger.info('mongo created indexes for collection {} done'.format(collection_name))
