# -*- coding:utf-8 -*-
# File Name:mongo_update_builder.py
# Author:jing
# Copyright:yiguotech.com
# Date:2018/11/30


from ygframe.design_pattern.abstract_builder import AbstractBuilder
from ygframe.util.dict_util import get_dict

__author__ = 'jing'

SET = '$set'
SET_ON_INSERT = '$setOnInsert'
UNSET = '$unset'
CURRENT_DATE = '$currentDate'
INCREASE = '$inc'
MIN = '$min'
MAX = '$max'
MUL = '$mul'
RENAME = '$rename'
TYPE = '$type'


class MongoUpdateBuilder(AbstractBuilder):
    """
    @see: https://docs.mongodb.com/manual/reference/operator/update/#id1
    """

    def set(self, *args, **kwargs):
        """Sets the value of a field in a document."""
        return self.deep_update({SET: get_dict(*args, **kwargs)})

    def unset(self, *args, **kwargs):
        """Removes the specified field from a document."""
        return self.deep_update({UNSET: get_dict(*args, **kwargs)})

    def set_on_insert(self, *args, **kwargs):
        """Sets the value of a field if an update results in an insert of a document.
        Has no effect on update operations that modify existing documents."""
        return self.deep_update({SET_ON_INSERT: get_dict(*args, **kwargs)})

    def ts(self, field):
        """Sets the value of a field to current timestamp."""
        return self.deep_update({CURRENT_DATE: {field: {TYPE: 'timestamp'}}})

    def date(self, field):
        """ Sets the value of a field to current date"""
        return self.deep_update({CURRENT_DATE: {field: {TYPE: 'date'}}})

    def increase(self, *args, **kwargs):
        """ Increments the value of the field by the specified amount."""
        return self.deep_update({INCREASE: get_dict(*args, **kwargs)})

    def min(self, *args, **kwargs):
        """Only updates the field if the specified value is less than the existing field value."""
        return self.deep_update({MIN: get_dict(*args, **kwargs)})

    def max(self, *args, **kwargs):
        """Only updates the field if the specified value is greater than the existing field value."""
        return self.deep_update({MAX: get_dict(*args, **kwargs)})

    def mul(self, *args, **kwargs):
        """Multiplies the value of the field by the specified amount."""
        return self.deep_update({MUL: get_dict(*args, **kwargs)})

    def rename(self, *args, **kwargs):
        """Renames a field."""
        return self.deep_update({RENAME: get_dict(*args, **kwargs)})
