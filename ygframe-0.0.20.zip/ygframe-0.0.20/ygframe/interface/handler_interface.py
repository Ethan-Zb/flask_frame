# -*- coding:utf-8 -*-
"""
--------------------------------------------
File Name:handler_interface.py
Author:jing
Copyright:yiguotech.com
date:2018/05/03
--------------------------------------------
"""
from abc import abstractmethod

__author__ = 'jing'


class HandlerInterface(object):
    """
    Base Class of all handlers
    """

    @abstractmethod
    def get_status(self) -> str:
        """
        :return: current status of the handler
        """
        pass

    @abstractmethod
    def get_description(self) -> str:
        """
        :return: description of the purpose of the handler, and other information
        """
        pass

    @abstractmethod
    def get_handle_key(self) -> str:
        """
        :return: the unique key of this handler
        """
        pass

    @classmethod
    def get_commands(cls):
        return []

    @classmethod
    def lazy_init(cls, key):
        pass
