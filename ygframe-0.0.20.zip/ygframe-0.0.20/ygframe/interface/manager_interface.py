# -*- coding:utf-8 -*-
"""
--------------------------------------------
File Name:manager_interface.py
Author:jing
Copyright:yiguotech.com
date:2018/05/03
--------------------------------------------
"""
from functools import lru_cache

from ygframe.interface.handler_interface import HandlerInterface

__author__ = 'jing'


class ManagerInterface(object):
    """
    Base Class of all handler managers
    """
    __url_key__ = None

    @classmethod
    def get_description(cls):
        """
        :return: get descriptions of all handlers
        """
        descriptions = [
            handler.get_description() for handler in cls.get_handler_dict().values()
        ]
        return '\n'.join(descriptions)

    @classmethod
    @lru_cache()
    def get_handler(cls, handler_key):
        """
        :param handler_key:
        :return: the registered handler by the `handler_key`
        """
        return cls.get_handler_dict().get(handler_key)

    @classmethod
    @lru_cache()
    def get_handler_dict(cls):
        """
        :return: all handlers with it's handler_key as key.
            the handlers comes from method `register` or the getter of class
        """
        handlers = {}
        for attr in dir(cls):
            value = getattr(cls, attr)
            if not isinstance(value, HandlerInterface):
                continue
            handlers[value.get_handle_key()] = value
        return handlers

    @classmethod
    def register(cls, handler: HandlerInterface):
        """
        :param handler:
        :return: register the handler to the manager
        """
        setattr(cls, handler.get_handle_key(), handler)

    @classmethod
    def after_class_loaded(cls):
        for key, handler in cls.get_handler_dict().items():
            if isinstance(handler, HandlerInterface):
                handler.lazy_init(key)
