# -*- coding:utf-8 -*-
#
# Author:jing
# Copyright:yiguotech.com
# date:2018/05/06
"""
init scope
"""
from ygframe.scope.scope import Scope

__author__ = 'jing'


def init_scope(system_name, subsystem_name):
    """
    :param system_name: scope system name
    :param subsystem_name: subsystem name without prefix
    :return: None
    """
    Scope.set_scope(
        system_name=system_name,
        subsystem_name=subsystem_name
    )
