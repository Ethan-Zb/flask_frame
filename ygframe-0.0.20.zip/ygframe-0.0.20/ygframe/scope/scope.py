# -*- coding:utf-8 -*-
#
# Author:jing
# Copyright:yiguotech.com
# date:2018/05/06

# pylint:disable=missing-docstring,unsubscriptable-object
from functools import lru_cache

from ygframe.const import get_const_system_name, get_const_subsystem_name
from ygframe.util import get_possible_system_name, get_possible_subsystem_name

__author__ = 'jing'


class Scope:
    GLOBAL = 'global'
    SYSTEM = 'system'
    SUBSYSTEM = 'subsystem'
    __global_name = 'yg'
    __system_name = None
    __subsystem_name = None

    @classmethod
    def set_scope(
            cls,
            system_name,
            subsystem_name=None,
    ):
        cls.__system_name = system_name
        cls.__subsystem_name = subsystem_name

    @classmethod
    @lru_cache()
    def get_system_name(cls):
        return cls.__system_name or get_const_system_name() or get_possible_system_name()

    @classmethod
    @lru_cache()
    def get_subsystem_name(cls):
        subsystem_name = cls.__subsystem_name or get_const_subsystem_name() or get_possible_subsystem_name()
        prefix = cls.get_system_name() + '_'
        if subsystem_name.startswith(prefix):
            subsystem_name = subsystem_name[len(prefix):]
        return subsystem_name

    @classmethod
    @lru_cache()
    def get_subsystem_full_name(cls):
        return '{}_{}'.format(
            cls.get_system_name(), cls.get_subsystem_name()
        )

    @classmethod
    @lru_cache()
    def get_scope_name(cls, scope: str) -> str:
        prefix_mapper = {
            Scope.GLOBAL: cls.__global_name,
            Scope.SYSTEM: cls.get_system_name(),
            Scope.SUBSYSTEM: cls.get_subsystem_full_name()
        }
        return prefix_mapper.get(scope, cls.get_subsystem_name())

    @classmethod
    @lru_cache()
    def get_url_prefix(cls) -> str:
        return '/{}/{}/api'.format(cls.get_system_name(), cls.get_subsystem_name())

    @classmethod
    @lru_cache()
    def get_admin_prefix(cls) -> str:
        return '/{}/{}/admin'.format(cls.get_system_name(), cls.get_subsystem_name())
