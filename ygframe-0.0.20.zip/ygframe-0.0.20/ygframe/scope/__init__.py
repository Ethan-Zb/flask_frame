# -*- coding:utf-8 -*-
#
# Author:jing
# Copyright:yiguotech.com
# date:2018/05/06

"""
ygframe scope
"""
__author__ = 'jing'
