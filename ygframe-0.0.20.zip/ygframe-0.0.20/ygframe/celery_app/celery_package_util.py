# -*- coding:utf-8 -*-
# File Name:celery_package_util.py
# Author:jing
# Copyright:yiguotech.com
# Date:2018/11/22
import random
import threading
import time
from functools import wraps
from multiprocessing import cpu_count
from types import FunctionType

from ygframe import SYSTEM_CONFIG
from ygframe.celery_app import celery_package_util_context, CELERY_PACKAGE_UTIL_CHECK_INTERVAL, \
    CELERY_PACKAGE_UTIL_STOP_SIGNAL
from ygframe.celery_app.task_util import task, TraceTask
from ygframe.const.common_const import CommonConst
from ygframe.logger import logger
from ygframe.setting import get_setting

__author__ = 'jing'

context_ttl = threading.local()
context_package = threading.local()
registered_utils = []


def package_util_task(
        rate_limit: (int, str) = None,
        base=TraceTask,
        package_size: (int, FunctionType) = 512,
        **kwargs
):
    def dec(func):
        @wraps(func)
        def wrapper(self, data, callback_url=None):
            kw_callback = dict(callback_url=callback_url) if callback_url else {}
            nonlocal package_size
            package_size = package_size if isinstance(package_size, int) else package_size()
            suffix = callback_url or ''
            name = self.name + suffix
            if not hasattr(context_package, name):
                setattr(context_package, name, [])
            data_list = getattr(context_package, name)

            stop_signal = CELERY_PACKAGE_UTIL_STOP_SIGNAL in celery_package_util_context

            if data == CommonConst.CELERY_DUMMY_TERMINATOR:
                if not data_list:
                    return

                if not stop_signal:
                    last_send = getattr(context_ttl, name, 0)
                    if not last_send:
                        return

                    timeout = get_setting(SYSTEM_CONFIG.CELERY_PACKAGE_UTIL_TIMEOUT_SETTING_KEY, 60)
                    if time.time() - last_send < timeout:
                        return
                # if CELERY_PACKAGE_UTIL_CHECK_INTERVAL not in celery_package_util_context or (
                #         celery_package_util_context[CELERY_PACKAGE_UTIL_CHECK_INTERVAL] == 0):
                #     celery_package_util_context[CELERY_PACKAGE_UTIL_CHECK_INTERVAL] = 1
                func(data_list, **kw_callback)
                data_list.clear()

                wait = 1 << 30 if stop_signal else 1
                logger.info('task {} end. wait for {}s'.format(name, wait))
                time.sleep(wait)  # important!
            else:
                data_list.append(data)
                setattr(context_ttl, name, time.time())
                if len(data_list) < package_size:
                    return
                func(data_list, **kw_callback)
                data_list.clear()

        if 'bind' in kwargs:
            kwargs.pop('bind')
        wrapped_task = task(rate_limit=rate_limit, base=base, bind=True, **kwargs)(wrapper)
        registered_utils.append(wrapped_task)
        return wrapped_task

    return dec


def check_all():
    # v['pool']['max-concurrency'] for k,v in inspect.stats().items()
    # try:
    #     interval = celery_package_util_context.get('celery_package_util_check_interval', 0)
    #     if interval >= 1:
    #         rand_interval = random.randint(1, interval)
    #         if rand_interval != 1:
    #             return
    #         else:
    #             celery_package_util_context[CELERY_PACKAGE_UTIL_CHECK_INTERVAL] = int(
    #                 celery_package_util_context[CELERY_PACKAGE_UTIL_CHECK_INTERVAL]) * 2
    # except:
    #     pass

    # todo temp
    signal = get_setting(CELERY_PACKAGE_UTIL_STOP_SIGNAL, None)
    if signal is not None:
        celery_package_util_context[CELERY_PACKAGE_UTIL_STOP_SIGNAL] = True

    for package_util in registered_utils:
        concurrency = get_setting(SYSTEM_CONFIG.CELERY_MAX_CONCURRENCY_SETTING_KEY) or cpu_count()
        for i in range(concurrency):
            package_util.delay(CommonConst.CELERY_DUMMY_TERMINATOR)
