# -*- coding:utf-8 -*-
"""
--------------------------------------------
File Name:celery_app_initializer.py
Author:jing
Copyright:yiguotech.com
date:2018/05/08
--------------------------------------------
"""
import json
import os
from functools import partial, lru_cache
from multiprocessing import Process
from typing import List

from celery.utils import instantiate
from kombu.serialization import register
from tzlocal import get_localzone

from ygframe import SYSTEM_CONFIG
from ygframe.celery_app import app, Worker, celery_beat_tasks, Task, YgframeCelery, celery_package_util
from ygframe.celery_app.route_util import get_celery_route_and_tasks, get_queue_name, get_task_name, \
    get_current_worker_name
from ygframe.const.common_const import CommonConst
from ygframe.logger import logger
from ygframe.scope.scope import Scope
from ygframe.serialize.yg_encoder import YgEncoder, Encoder
from ygframe.setting import get_setting
from ygframe.task.cyclic_task import CyclicTask
from ygframe.task.instance_task import InstanceTask
from ygframe.task.task_manager import CoreTaskManager
from ygframe.util import NotSet

__author__ = 'jing'


def _worker_main(argv):
    if len(argv) > 3:
        worker_name = argv[2]
        logger.info('start subprocess of celery worker {} ,pid is {}'.format(worker_name, os.getpid()))
    app.worker_main(argv)


@lru_cache()
def get_app(broker_url, task_name):
    _register_serializer(YgEncoder)
    celery_route = {task_name: {
        'queue': get_queue_name(task_name),
        'serializer': SYSTEM_CONFIG.CELERY_SERIALIZER_NAME
    }}
    custom_app = YgframeCelery(task_name)
    custom_app.conf.update({
        'broker_url': broker_url,
        'task_routes': celery_route,
        'accept_content': [SYSTEM_CONFIG.CELERY_SERIALIZER_NAME],
        'task_serializer': SYSTEM_CONFIG.CELERY_SERIALIZER_NAME,
    })
    return custom_app


def send_task(task_name, args=None, kwargs=None, broker_url=None):
    args = args or tuple()
    kwargs = kwargs or {}
    broker_url = broker_url or get_setting(SYSTEM_CONFIG.CELERY_BROKER_URL_SETTING_KEY)
    return get_app(broker_url, task_name).send_task(task_name, args, kwargs)


def init(
        broker_url: str,
        backend_url: str = None,
        custom_encoder: Encoder = NotSet,
        workers: List[Worker] = None,
        app_config: dict = None,
        common_worker_argv: List[str] = None,
        custom_local_tasks: List[str] = None,
        custom_remote_tasks: List[str] = None,
        start_local_task: bool = True
):
    """
    init celery
        format:
            task_name:'{sys}.task.celery_task.{sub_sys}.{method_name}'
            queue_name:'{task_name}_tasks'
            route:
            {
                'task_name':{
                                'queue'
                            }
            }
    :param start_local_task:
    :param app_config:
    :param workers:
    :param common_worker_argv:
    :param custom_remote_tasks:
    :param custom_local_tasks:
    :param custom_encoder:
    :param broker_url:
    :param backend_url:
    :return:

    if you set concurrency and use package_util, you must edit config CELERY_MAX_CONCURRENCY to
    right value. or you may lose your message
    """
    custom_encoder = YgEncoder if custom_encoder is NotSet else custom_encoder
    common_worker_argv = common_worker_argv or []
    workers = workers or []
    app_config = app_config or {}

    app.conf.update({
        'broker_url': broker_url,
    })

    serializer = _register_serializer(custom_encoder) if custom_encoder else 'json'

    route, local_tasks = get_celery_route_and_tasks(
        custom_local_tasks,
        custom_remote_tasks,
        serializer=serializer
    )

    if not start_local_task:
        local_tasks = []

    app.conf.update({
        'task_routes': route,
        # 'worker_prefetch_multiplier': 100,
        'timezone': get_localzone(),
        'enable_utc': True,
        **app_config,
    })

    if backend_url:
        app.conf.update({
            'result_backend': backend_url,
            'result_serializer': serializer,
            'result_expires': 3600,
            'task_ignore_result': False
        })
    else:
        app.conf.update({
            'task_ignore_result': True,
        })

    namespace = Scope.get_subsystem_full_name() + '_'
    unregistered_tasks = {
        Task.get_task(task).name: Task.get_task(task)
        for task in local_tasks
    }
    non_rate_limit_tasks = []
    non_rate_limit_only = False
    all_workers = workers.copy()
    for worker in workers:
        if not worker.worker_name.startswith(namespace):
            raise ValueError('worker name must startswith {}'.format(namespace))
        for task in worker.tasks:
            task_name = get_task_name(task)
            if task_name in unregistered_tasks:
                unregistered_tasks.pop(task_name)
    for task_name, unregistered_task in unregistered_tasks.items():
        if not hasattr(unregistered_task, 'rate_limit') or not unregistered_task.rate_limit:
            non_rate_limit_tasks.append(task_name)
        else:
            all_workers.append(Worker(task_name, [task_name]))
    if not all_workers:
        non_rate_limit_only = True
    all_workers.append(Worker(get_current_worker_name(), non_rate_limit_tasks))

    if celery_beat_tasks:
        app.conf.beat_schedule = celery_beat_tasks

        def _beat_main():
            return instantiate(
                'celery.bin.beat:beat',
                app=app).execute_from_commandline(['beat'])

        CoreTaskManager.register(InstanceTask(
            do_start=_beat_main,
            handle_key='{}_beat'.format(Scope.get_subsystem_full_name())
        ))

    if celery_package_util.registered_utils:
        CoreTaskManager.register(CyclicTask(
            task=celery_package_util.check_all,
            cyclic_wait=get_setting(SYSTEM_CONFIG.CELERY_PACKAGE_UTIL_TIMEOUT_SETTING_KEY, 60),
            handle_key='{}_check_packages'.format(Scope.get_subsystem_full_name())
        ))

    if non_rate_limit_only:
        worker = all_workers[0]
        CoreTaskManager.register(InstanceTask(
            do_start=partial(app.worker_main, [
                'worker',
                '-n', '{}@%h'.format(worker.worker_name),
                '-Q', ','.join([get_queue_name(task) for task in worker.tasks]),
                *worker.argv,
                *common_worker_argv]),
            handle_key=worker.worker_name
        ))
    else:
        for worker in all_workers:
            process = Process(target=_worker_main, args=(
                [
                    'worker',
                    '-n', '{}@%h'.format(worker.worker_name),
                    '-Q', ','.join([get_queue_name(task) for task in worker.tasks]),
                    *worker.argv,
                    *common_worker_argv],
            ))
            process.start()


def _register_serializer(custom_encoder):
    register(
        SYSTEM_CONFIG.CELERY_SERIALIZER_NAME,
        partial(json.dumps, cls=custom_encoder),
        partial(json.loads, object_hook=custom_encoder.object_hook),
        content_type=CommonConst.CONTENT_TYPE_JSON,
        content_encoding=CommonConst.UTF8
    )
    app.conf.update({
        'accept_content': [SYSTEM_CONFIG.CELERY_SERIALIZER_NAME],
        'task_serializer': SYSTEM_CONFIG.CELERY_SERIALIZER_NAME,
    })

    return SYSTEM_CONFIG.CELERY_SERIALIZER_NAME
