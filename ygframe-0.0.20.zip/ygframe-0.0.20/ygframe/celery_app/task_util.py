# -*- coding:utf-8 -*-
"""
--------------------------------------------
File Name:task_util.py
Author:jing
Copyright:yiguotech.com
date:2018/07/30
--------------------------------------------
"""
import celery

from ygframe.celery_app import app, celery_beat_tasks
from ygframe.logger import logger
from ygframe.logger.logger_context import error_exception
from ygframe.scope.scope import Scope
from ygframe.util.inspect_util import get_full_name
from ygframe.util.retry import Retry

__author__ = 'jing'

TRACE_ID = 'trace_id'


# noinspection PyAbstractClass
class TraceTask(celery.Task):
    def delay(self, *args, **kwargs):
        with error_exception():
            logger.trace(kwargs.get(TRACE_ID), 'send task {}, args: {}, kwargs: {}'.format(self.name, args, kwargs))
        return super().delay(*args, **kwargs)

    def apply_async(self, args=None, kwargs=None, task_id=None, producer=None, link=None, link_error=None, shadow=None,
                    **options):
        return super().apply_async(args, kwargs, task_id, producer, link, link_error, shadow, **options)

    def on_failure(self, exc, task_id, args, kwargs, einfo):
        with error_exception():
            logger.trace(
                kwargs.get(TRACE_ID),
                'task {} failed. args:{}, kwargs:{}, einfo:{}'.format(self.name, args, kwargs, einfo))
        super().on_failure(exc, task_id, args, kwargs, einfo)

    def on_success(self, retval, task_id, args, kwargs):
        with error_exception():
            logger.trace(
                kwargs.get(TRACE_ID),
                'task {} success. args:{}'.format(self.name, args))
        super().on_success(retval, task_id, args, kwargs)

    def on_retry(self, exc, task_id, args, kwargs, einfo):
        with error_exception():
            logger.trace(
                kwargs.get(TRACE_ID),
                '|TRACE| task {} retries.args:{}, kwargs:{}, exc: {}, einfo: {}'.format(
                    self.name, args, kwargs, str(exc), str(einfo)
                ))
        super().on_retry(exc, task_id, args, kwargs, einfo)


class ImplementedRemotely(Exception):
    pass


def task(
        *args,
        rate_limit: (int, str) = None,
        autoretry_for: (type, tuple) = None,
        retry_backoff=True,
        retry_backoff_max=180,
        max_retries=Retry.FOREVER,
        base=TraceTask,
        kw_schema: dict = None,
        callback=None,
        **kwargs
):
    if len(args) == 1 and callable(args[0]):
        return task()(args[0])

    if rate_limit:
        kwargs['rate_limit'] = rate_limit
    if autoretry_for:
        if not isinstance(autoretry_for, tuple):
            autoretry_for = (autoretry_for,)
        kwargs['autoretry_for'] = autoretry_for
    if retry_backoff:
        kwargs['retry_backoff'] = retry_backoff
    if retry_backoff_max:
        kwargs['retry_backoff_max'] = retry_backoff_max
    if base:
        kwargs['base'] = base
    kwargs['max_retries'] = max_retries

    def _dec(func):
        result = app.task(**kwargs)(func)
        result.kw_schema = kw_schema
        result.callback = callback
        if rate_limit:
            result.rate_limit = rate_limit
        return result

    return _dec


def beat_task(scheduler, scheduler_name=None, *args, **kwargs):
    def wrapper(func):
        name = scheduler_name or '{}_{}'.format(Scope.get_system_name(), get_full_name(func))
        celery_task = task(*args, **kwargs)(func)
        celery_beat_tasks[name] = {
            'task': celery_task.name,
            'schedule': scheduler,
        }
        return celery_task

    return wrapper


remote_task = task
