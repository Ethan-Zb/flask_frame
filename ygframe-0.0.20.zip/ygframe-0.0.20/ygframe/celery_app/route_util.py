# -*- coding:utf-8 -*-
"""
--------------------------------------------
File Name:route_util.py
Author:jing
Copyright:yiguotech.com
date:2018/07/26
--------------------------------------------
"""
from importlib import import_module
from itertools import chain

import celery
from werkzeug.utils import find_modules, import_string

from ygframe import SYSTEM_CONFIG
from ygframe.logger import logger
from ygframe.logger.logger_context import debug_exception, error_exception
from ygframe.scope.scope import Scope
from ygframe.util.import_util import chain_find_modules

__author__ = 'jing'


def generate_task_name(subsystem, method):
    return '{sys}.{model}.{subsys}.{task}'.format(
        sys=Scope.get_scope_name(Scope.SYSTEM),
        model=SYSTEM_CONFIG.CELERY_TASK_MODULE_NAME,
        subsys=subsystem,
        task=method
    )


def get_task_name(task):
    return getattr(task, 'name', task)


def get_queue_name(task):
    return '{}_tasks'.format(get_task_name(task))


def get_current_worker_name():
    return '{}_worker'.format(Scope.get_scope_name(Scope.SUBSYSTEM))


@error_exception
def get_celery_route_and_tasks(custom_local_tasks: list, custom_remotes: list, serializer: str):
    local_tasks = [] if not custom_local_tasks else custom_local_tasks.copy()
    all_tasks = local_tasks + (
        [] if not custom_remotes else custom_remotes.copy()
    )

    try:
        module = import_string(SYSTEM_CONFIG.CELERY_TASK_MODULE_NAME)
        path = getattr(module, '__path__', None)
        if path:
            _auto_load_tasks(all_tasks, local_tasks)
    except:
        logger.warning('not found {}'.format(SYSTEM_CONFIG.CELERY_TASK_MODULE_NAME))

    route = {
        get_task_name(task): {
            'queue': get_queue_name(task),
            'serializer': serializer
        }
        for task in all_tasks
    }

    return route, local_tasks


@debug_exception
def _auto_load_tasks(all_tasks, local_tasks):
    current_subsystem = Scope.get_subsystem_name()
    current_system_name = Scope.get_system_name()

    for module_name in chain_find_modules(
            SYSTEM_CONFIG.CELERY_TASK_MODULE_NAME,
            SYSTEM_CONFIG.CELERY_BEAT_TASK_MODULE,
            SYSTEM_CONFIG.CELERY_EXTERNAL_TASK_MODULE_NAME,
    ):
        try:
            module = import_module(module_name)
            for attr, value in module.__dict__.items():
                if isinstance(value, celery.Task):
                    task_name = value.name  # type:str
                    all_tasks.append(value)
                    check_local_flag = '{}.{}.{}'.format(
                        current_system_name, SYSTEM_CONFIG.CELERY_TASK_MODULE_NAME, current_subsystem
                    )
                    if check_local_flag in task_name:
                        if task_name.startswith(current_system_name):
                            local_tasks.append(value)
        except:
            logger.warning('load celery task {} failed'.format(module_name), exc_info=True)
