# -*- coding:utf-8 -*-
"""
--------------------------------------------
File Name:__init__.py.py
Author:jing
Copyright:yiguotech.com
date:2018/05/08
--------------------------------------------
"""
from collections import defaultdict, namedtuple
from typing import List

from celery import Celery
from celery.signals import after_setup_logger, worker_process_init
from pymongo import MongoClient

from ygframe import SYSTEM_CONFIG, shared_memory
from ygframe.celery_app.route_util import get_queue_name
from ygframe.logger import init_logger_level
from ygframe.scope.scope import Scope
from ygframe.util.str_util import get_between, split

__author__ = 'jing'

celery_beat_tasks = {}
celery_package_util_context = shared_memory.dict()
CELERY_PACKAGE_UTIL_CHECK_INTERVAL = 'celery_package_util_check_interval'
CELERY_PACKAGE_UTIL_STOP_SIGNAL = 'celery_package_util_stop_signal'


@after_setup_logger.connect
def after_setup_logger_handler(*args, **kwargs):
    init_logger_level()


@worker_process_init.connect
def process_init(sender=None, conf=None, **kwargs):
    from ygframe.builder import Builder
    if Builder.mongo_initialized:
        from ygframe import mongo_wrapper
        client = MongoClient(**mongo_wrapper.mongo_dict)
        if mongo_wrapper.auth_args:
            client.admin.authenticate(*mongo_wrapper.auth_args)
        mongo_wrapper.mongo_client = client


class Worker(namedtuple('Worker', ['worker_name', 'tasks', 'argv'])):
    """
    use in python 3.5.
    when updated to 3.6, change to:
        class Worker(NamedTuple):
            worker_name:str
            tasks:list: = []
            argv:List[str]: = []
    witch is much better to write and read
    """
    __slots__ = ()

    # noinspection PyInitNewSignature,PyArgumentList
    def __new__(cls, worker_name: str, tasks: list = None, argv: List[str] = None):
        return super(Worker, cls).__new__(cls, worker_name, tasks or [], argv or [])


class Task(object):

    def __init__(self, name, rate_limit) -> None:
        self.name = name
        self.rate_limit = rate_limit

    @classmethod
    def get_task(cls, obj):
        if isinstance(obj, str):
            ret = obj.__new__(cls)
            ret.name = obj
            return ret
        else:
            return obj


class YgframeCelery(Celery):  # pylint: disable=too-few-public-methods
    """
    add prefix to task name
    """

    def gen_task_name(self, name, module):
        ori_name = super(YgframeCelery, self).gen_task_name(name, module)
        if SYSTEM_CONFIG.CELERY_EXTERNAL_TASK_MODULE_NAME in module:
            _, remain = split(ori_name, '{}.'.format(SYSTEM_CONFIG.CELERY_EXTERNAL_TASK_MODULE_NAME))
            if '.' in remain:
                left, right = split(remain, '.')
                return '{}.{}.{}'.format(
                    left,
                    SYSTEM_CONFIG.CELERY_TASK_MODULE_NAME,
                    right
                )
        if ori_name.count('.') >= 5:
            slices = ori_name.split('.', maxsplit=3)
            return '{}.{}.{}'.format(
                slices[2], SYSTEM_CONFIG.CELERY_TASK_MODULE_NAME, slices[3]
            )

        return "{}.{}".format(
            Scope.get_scope_name(Scope.SYSTEM),
            ori_name
        )

    def get_queue_size(self, task):
        with self.connection_or_acquire() as conn:
            qsize = conn.default_channel.queue_declare(
                queue=get_queue_name(task),
                passive=True
            ).message_count
            return qsize

    def set_rate_limit(self, task, rate_limit: (int, str)):
        task_name = task if isinstance(task, str) else task.name
        queues_dict = app.control.inspect().active_queues()
        destination_set = set()
        for pong in self.control.ping():
            for name, value in pong.items():
                if value.get('ok') != 'pong':
                    continue
                if name not in queues_dict:
                    continue
                for queue in queues_dict[name]:
                    if task_name in queue['name']:
                        destination_set.add(name)
                        break

        if destination_set:
            return self.control.rate_limit(task_name, rate_limit, destination=tuple(destination_set))

    @staticmethod
    def _get_name_rate(details: str):
        name = details[:details.index(' [')]
        rate_str = get_between(details, '[rate_limit=', ']')
        rate_value, rate_type = split(rate_str, '/')
        rate_value = float(rate_value)
        if rate_type == 's':
            rate_value *= 60
        if rate_type == 'h':
            rate_value /= 60
        return name, rate_value

    def get_rate_limit(self) -> dict:
        rate_per_minute_dict = defaultdict(float)
        for worker, tasks in self.control.inspect().registered().items():
            for task_detail in tasks:
                if '[rate_limit=' not in task_detail:
                    continue
                name, rate = self._get_name_rate(task_detail)
                rate_per_minute_dict[name] += rate
        return rate_per_minute_dict


app = YgframeCelery(Scope.get_scope_name(Scope.SUBSYSTEM))  # pylint: disable=invalid-name
