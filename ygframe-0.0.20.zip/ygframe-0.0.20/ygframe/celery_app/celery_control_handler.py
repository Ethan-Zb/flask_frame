# -*- coding:utf-8 -*-
"""
--------------------------------------------
File Name:celery_control_handler.py
Author:jing
Copyright:yiguotech.com
date:2018/07/27
--------------------------------------------
"""
from ygframe.interface.handler_interface import HandlerInterface

__author__ = 'jing'


class CeleryControlHandler(HandlerInterface):
    def get_status(self) -> str:
        pass

    def get_description(self) -> str:
        pass

    def get_handle_key(self) -> str:
        pass

