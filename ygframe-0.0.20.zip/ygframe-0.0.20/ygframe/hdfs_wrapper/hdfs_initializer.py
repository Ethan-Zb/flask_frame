# -*- coding:utf-8 -*-
# File Name:hdfs_initializer.py
# Author:jing
# Copyright:yiguotech.com
# Date:2018/11/23
import os

from hdfs import Client

from ygframe import hdfs_wrapper
from ygframe.hdfs_wrapper import get_hdfs_client
from ygframe.logger.logger_context import error_exception

__author__ = 'jing'


def init(url, root=None, proxy=None, timeout=None, session=None):
    client = Client(url, root, proxy, timeout, session)
    hdfs_wrapper.__hdfs_client = client
    return client


def hdfs_read_file(path):
    client = get_hdfs_client()
    with client.read(path) as reader:
        yield from reader


def hdfs_mkdirs(path):
    get_hdfs_client().makedirs(path)


def hdfs_delete_file(path):
    get_hdfs_client().delete(path)


@error_exception(default=False)
def hdfs_upload_file(file, path):
    if os.path.isfile(file):
        return get_hdfs_client().upload(path, file, cleanup=True)


def hdfs_download_file(path, file, overwrite=False):
    get_hdfs_client().download(path, file, overwrite=overwrite)


def hdfs_append_file(file, content):
    get_hdfs_client().write(file, content, overwrite=False, append=True)


def hdfs_write_file(file, content):
    get_hdfs_client().write(file, content, overwrite=True, append=False)


def hdfs_move_file(src, dst):
    get_hdfs_client().rename(src, dst)


def hdfs_list_dir(path):
    get_hdfs_client().list(path)
