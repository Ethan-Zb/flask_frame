# -*- coding:utf-8 -*-
# 
# Author:jing
# Copyright:yiguotech.com
# Date:2018/11/23
from hdfs import Client

from ygframe.util.precondition import not_none

__author__ = 'jing'

__hdfs_client = None


def get_hdfs_client() -> Client:
    return not_none(__hdfs_client)
