# -*- coding:utf-8 -*-
# File Name:abstract_builder.py
# Author:jing
# Copyright:yiguotech.com
# Date:2018/11/30
from typing import Any

from ygframe.util.dict_util import deep_update, get_dict

__author__ = 'jing'


class AbstractBuilder:

    def __new__(cls) -> Any:
        self = super().__new__(cls)
        self._data = {}
        return self

    def update(self, *args, **kwargs):
        self._data.update(get_dict(*args, **kwargs))
        return self

    def deep_update(self, *args, **kwargs):
        deep_update(self._data, get_dict(*args, **kwargs))
        return self

    def get(self):
        return self._data
