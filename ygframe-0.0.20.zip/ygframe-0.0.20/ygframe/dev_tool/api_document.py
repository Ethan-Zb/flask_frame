# -*- coding:utf-8 -*-
"""
--------------------------------------------
File Name:api_document.py
Author:jing
Copyright:yiguotech.com
date:2018/10/12
--------------------------------------------
"""
from typing import List

__author__ = 'jing'


class RestfulApi(object):
    pass


class Get(RestfulApi):
    pass


class ApiDocument(object):
    def __init__(
            self,
            description: str,
            url: str,
            restful_list: List[RestfulApi] = None
    ) -> None:
        super().__init__()
