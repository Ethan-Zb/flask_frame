# -*- coding:utf-8 -*-
"""
--------------------------------------------
File Name:task_module_name.py
Author:{author}
Copyright:yiguotech.com
date:{date}
--------------------------------------------
"""
# from ygframe.task.instance_task import instance_task

__author__ = '{author}'


# @instance_task
def task_run_once():
    print('Edsger Dijkstra')
