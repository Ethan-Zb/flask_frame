# -*- coding:utf-8 -*-
"""
--------------------------------------------
File Name:task_module_name.py
Author:{author}
Copyright:yiguotech.com
date:{date}
--------------------------------------------
"""
# from ygframe.task.cyclic_task import cyclic_task

__author__ = '{author}'


# @cyclic_task(10)
def task_run_cyclically():
    print('Johann von Neumann')
