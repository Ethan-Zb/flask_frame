# -*- coding:utf-8 -*-
"""
--------------------------------------------
File Name:{file_name}.py
Author:{author}
Copyright:yiguotech.com
date:{date}
--------------------------------------------
"""

__author__ = '{author}'


# @task
def hello():
    print('hello', 'Linus Torvalds')


# @beat_task(scheduler=crontab(day_of_month='5'))
def beat_hello():
    print('hello', 'Dennis M.Ritchie')
