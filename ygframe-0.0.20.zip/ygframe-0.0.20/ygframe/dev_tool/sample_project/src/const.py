# -*- coding:utf-8 -*-
#
# Author: {author}
# Copyright: yiguotech.com
# Date: {date}

from ygframe.const.common_const import CommonConst

__author__ = '{author}'


class __Const(CommonConst):
    SYSTEM_NAME = '{sys}'
    SUBSYSTEM_NAME = '{sub}'


CONST = __Const
