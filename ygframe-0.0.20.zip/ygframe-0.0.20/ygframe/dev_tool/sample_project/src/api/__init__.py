# -*- coding:utf-8 -*-
"""
--------------------------------------------
File Name:__init__.py.py
Author:{author}
Copyright:yiguotech.com
date:{date}
--------------------------------------------
"""
__author__ = '{author}'
