# -*- coding:utf-8 -*-
"""
--------------------------------------------
File Name:hello_world.py
Author:{author}
Copyright:yiguotech.com
date:{date}
--------------------------------------------
"""
from flask import request
from ygframe.api_util.schema import SCHEMA

from ygframe.flask_app.yg_resource_validators import validate_json

from ygframe.flask_app import YgResource, Sample, ErrorCode

__author__ = '{author}'


class HelloWorld(YgResource):
    NAME = 'name'

    @classmethod
    @validate_json
    def post(cls):
        name = request.json.get(cls.NAME)
        return cls.success(greeting='hello {{}}'.format(name))

    __post_json_schema__ = {{
        SCHEMA.TYPE: SCHEMA.Types.OBJECT,
        SCHEMA.PROPERTIES: {{
            NAME: {{SCHEMA.TYPE: SCHEMA.Types.STRING}}
        }},
        SCHEMA.REQUIRED: [NAME]
    }}

    __post_request_sample__ = [
        Sample({{'name': 'jing'}}, 'post name to be greeting')
    ]
    __post_response_sample__ = [
        Sample(YgResource.success(greeting='hello'))
    ]
    __error_code_list__ = [
        ErrorCode(40051, 'X error')
    ]
