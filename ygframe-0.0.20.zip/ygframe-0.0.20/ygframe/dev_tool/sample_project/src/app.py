# -*- coding:utf-8 -*-
#
# Author: {author}
# Copyright: yiguotech.com
# Date: {date}

from multiprocessing import Condition

from initializer import init

__author__ = '{author}'

condition = Condition()

if __name__ == '__main__':
    init()

    with condition:
        condition.wait()
