# -*- coding:utf-8 -*-
#
# Author: {author}
# Copyright: yiguotech.com
# Date: {date}

from ygframe.builder import Builder
from ygframe.dev_tool import setting_generator, globals_generator, doc_generator

from globals import GLOBALS

__author__ = 'jing'


def init():
    builder = Builder()
    {init_lines}
    builder.build()

    if GLOBALS.debug:
        setting_generator.generate()
        globals_generator.generate()
        doc_generator.generate()
