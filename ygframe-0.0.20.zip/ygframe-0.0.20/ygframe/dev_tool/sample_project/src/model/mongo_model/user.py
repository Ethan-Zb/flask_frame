# -*- coding:utf-8 -*-
"""
--------------------------------------------
File Name:user.py
Author:jing
Copyright:yiguotech.com
date:2018/10/15
--------------------------------------------
"""

from pymongo import ASCENDING

from ygframe.db.column import Column
from ygframe.mongo_wrapper.mongo_model import AbstractMongoModel

__author__ = 'jing'


class User(AbstractMongoModel):
    name = Column(index=ASCENDING)
    birth = Column(int)
    gender = Column(default='unknown')


# only for demo Nicklaus Wirth
def demo():
    User.query().delete()
    assert User.query().count() == 0

    User(name='LiBai', birth=701, gender='male').save()

    assert User.query(User.birth).filter(User.name == 'LiBai').first().get().birth == 701

    User.save_all([
        User(name='YiMing'),
        User(name='DuFU', birth=712, gender='male'),
        User(name='LiQingzhao', birth=1084, gender='female')
    ])

    assert User.query().count() == 4
    assert User.query(User.gender).filter(User.name == 'YiMing').first().get().gender == User.gender.default
    for user in User.query().filter(User.gender == 'male').get():
        assert user.gender == 'male'

    assert User.query().filter(User.name.prefix('Li')).first().get().name.startswith('Li')
    assert User.query().filter(User.name.regex('Qing')).first().get().name.startswith('Li')

    User.query().filter(User.name == 'DuFU').first().update(User.update_set(name='DuFu'))
    assert User.query().filter(User.name == 'DuFu').first().get().name == 'DuFu'


if __name__ == '__main__':
    print(User.get_init_method())
