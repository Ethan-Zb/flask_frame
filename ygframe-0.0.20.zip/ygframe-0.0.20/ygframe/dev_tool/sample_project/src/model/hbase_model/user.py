# -*- coding:utf-8 -*-
"""
--------------------------------------------
File Name:user.py
Author:{author}
Copyright:yiguotech.com
date:{date}
--------------------------------------------
"""
from abc import abstractmethod
from datetime import datetime

from ygframe.hbase_wrapper.hbase_scanner import HbaseScanner

from ygframe.util.scanner_util import with_log

from ygframe.hbase_wrapper.hbase_model import AbstractHbaseModel, generate_hbase_methods, HbaseColumn

__author__ = '{author}'


class User(AbstractHbaseModel):
    name = HbaseColumn()
    age = HbaseColumn(int)

    def get_row_key(self):
        return self.name


# only for demo.
def hbase_demo_as_if_shannon_is_alive():
    # save single object
    user = User.create('Claude Elwood Shannon', datetime.now().year - 1916)
    user.save()

    # get all data
    for user in with_log(HbaseScanner(User).scan()):
        print(user)


# generate __slots__, __init__, create
if __name__ == '__main__':
    print(User.get_init_method())
    # generate_hbase_methods(User, {{'age': int}}) for python3.6 or later version
