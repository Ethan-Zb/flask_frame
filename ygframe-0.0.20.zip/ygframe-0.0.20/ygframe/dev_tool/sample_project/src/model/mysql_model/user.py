# -*- coding:utf-8 -*-
"""
--------------------------------------------
File Name:user.py
Author:{author}
Copyright:yiguotech.com
date:{date}
--------------------------------------------
"""
from datetime import datetime

from sqlalchemy import Integer, Column, String
from sqlalchemy.orm import Session
from ygframe.mysql_wrapper import Base, session_scope

__author__ = '{author}'


class User(Base):
    id = Column(Integer, primary_key=True, index=True)
    name = Column(String(128))
    age = Column(Integer)


# only for demo. orm should not be there
def mysql_demo_usage_as_if_turing_is_alive():
    with session_scope() as session:  # type:Session
        session.add(User(1, 'Alan Mathison Turing', datetime.now().year - 1912))
