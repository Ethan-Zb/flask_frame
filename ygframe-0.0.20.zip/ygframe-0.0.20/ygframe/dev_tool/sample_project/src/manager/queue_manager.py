# -*- coding:utf-8 -*-
"""
--------------------------------------------
File Name:queue_manager.py
Author:{author}
Copyright:yiguotech.com
date:{date}
--------------------------------------------
"""
from ygframe.rabbitmq_wrapper.rabbitmq_initializer import register_consumers

from ygframe.rabbitmq_wrapper.rabbit_queue import RabbitQueue

from ygframe.queue.queue_manager import BaseQueueManager

__author__ = '{author}'


# demo
def simple_queue():
    # producer
    QueueManager.GUIDO_VAN_ROSSUM.put({{'key': 'value'}})
    # consumer
    value = QueueManager.GUIDO_VAN_ROSSUM.get(block=True, timeout=None)
    print(value)


# consumer
def simple_queue_callback(**kwargs):
    print(kwargs)


class QueueManager(BaseQueueManager):
    GUIDO_VAN_ROSSUM = RabbitQueue('guido_van_rossum', simple_queue_callback)


# demo
def subscribe():
    # publish
    from ygframe.rabbitmq_wrapper.rabbitmq_initializer import publish
    publish({{'key': 'value'}}, 'ex_name', 'topic', 'a.b.c')

    # consumers
    # in initializer.py, before builder.build().
    def callback(body, message):
        # do something
        message.ack()

    from ygframe.rabbitmq_wrapper import Consumer
    register_consumers([
        Consumer('qn', callback, 'ex_name', 'a.b.*'),
        Consumer('qn2', callback, 'ex_name', 'a.#')
    ])
