# -*- coding:utf-8 -*-
"""
--------------------------------------------
File Name:statistic_manager.py
Author:{author}
Copyright:yiguotech.com
date:{date}
--------------------------------------------
"""
from ygframe.redis_wrapper.redis_statistic import RedisStringHandler

from ygframe.statistic.statistic_manager import BaseStatisticManager

__author__ = '{author}'


class StatisticManager(BaseStatisticManager):
    DONALD_ERVIN_KNUTH = RedisStringHandler('donald_ervin_knuth')


# this is a demo
if __name__ == '__main__':
    StatisticManager.DONALD_ERVIN_KNUTH.increase()
    StatisticManager.DONALD_ERVIN_KNUTH.increase(5)
    StatisticManager.DONALD_ERVIN_KNUTH.get()
    StatisticManager.DONALD_ERVIN_KNUTH.reset()
