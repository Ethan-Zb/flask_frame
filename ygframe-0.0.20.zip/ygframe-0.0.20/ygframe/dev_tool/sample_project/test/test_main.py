# -*- coding:utf-8 -*-
#
# Author: {author}
# Copyright: yiguotech.com
# Date: {date}

from ygframe.test_util.abstract_test_main import AbstractTestMain

__author__ = '{author}'


class TestMain(AbstractTestMain):
    debug = False
    source = ['../../src']
    wait_running = 6


if __name__ == '__main__':
    TestMain.main()
