# -*- coding:utf-8 -*-
# File Name:model_doc_generator.py
# Author:jing
# Copyright:yiguotech.com
# Date:2018/11/28
from pymongo import DESCENDING
from ygframe.db.column_docable import ColumnDocable

from ygframe import SYSTEM_CONFIG
from ygframe.dev_tool.generator_util import get_md_table
from ygframe.mongo_wrapper.mongo_model import AbstractMongoModel
from ygframe.util.file_util import ensure_file
from ygframe.util.import_util import get_all
from ygframe.util.inspect_util import get_full_name

__author__ = 'jing'


def generate_mongo_table_doc():
    file_name = '../doc/models/mongo_tables.md'
    tables = []
    try:
        for mongo_model in get_all(SYSTEM_CONFIG.MONGO_MODEL_MODULE_NAME, AbstractMongoModel):
            lines = [['field', 'type', 'default', 'index', 'unique', 'description', 'options']]
            if not issubclass(mongo_model, AbstractMongoModel):
                continue
            for column in mongo_model.get_columns():
                lines.append([
                    column.key,
                    column.key_type.__name__,
                    column.default if column.default is not None else '',
                    '' if column.index is False
                    else 'DESC' if column.index == DESCENDING
                    else 'ASC',
                    column.unique if column.unique is not False else '',
                    column.description,
                    '' if not column.one_of else '<br>'.join([
                        '{}={}'.format(key, value)
                        for key, value in column.one_of.__dict__.items()
                        if not key.startswith('_')
                    ])
                ])
            tables.append('{}.{}\n\n{}'.format(
                mongo_model.get_db_name(),
                mongo_model.get_collection_name(),
                get_md_table(lines)
            ))
        with open(ensure_file(file_name), 'w') as file:
            file.write('  \n\n'.join(tables))
    except:
        pass


def generate_data_model_doc():
    file_name = '../doc/models/data_models.md'
    tables = []
    try:
        for model in get_all(SYSTEM_CONFIG.DATA_MODEL_MODULE_NAME, ColumnDocable):
            lines = [['field', 'type', 'default', 'description', 'options']]
            if not issubclass(model, ColumnDocable):
                continue
            for column in model.get_columns():
                lines.append([
                    column.key,
                    column.key_type.__name__,
                    column.default if column.default is not None else '',
                    column.description,
                    '' if not column.one_of else '<br>'.join([
                        '{}={}'.format(key, value)
                        for key, value in column.one_of.__dict__.items()
                        if not key.startswith('_')
                    ])
                ])
            tables.append('{}\n\n{}'.format(
                get_full_name(model),
                get_md_table(lines)
            ))
        with open(ensure_file(file_name), 'w') as file:
            file.write('  \n\n'.join(tables))
    except:
        pass
