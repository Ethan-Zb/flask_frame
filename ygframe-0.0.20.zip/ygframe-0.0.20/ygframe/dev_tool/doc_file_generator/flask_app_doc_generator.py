# -*- coding:utf-8 -*-
# File Name:flask_app_doc_generator.py
# Author:jing
# Copyright:yiguotech.com
# Date:2018/11/28
import inspect

from ygframe.api_util.schema import SCHEMA
from ygframe.api_util.schema_builder import Args

from ygframe.dev_tool.generator_util import get_md_table, get_template
from ygframe.flask_app import YgCallback, YgResource, get_url_list, Sample
from ygframe.util.file_util import ensure_file

__author__ = 'jing'


def generate_flask_doc_files(resources):
    restful_template, restful_api_template, = get_template(
        'restful.md', 'restful_api.md'
    )
    for resource, version in resources:
        if issubclass(resource, YgCallback):
            continue
        content = get_restful_content(resource, version, restful_template, restful_api_template)
        file_name = '../doc/restful/{}/{}.md'.format(version, resource.__name__)
        with open(ensure_file(file_name), 'w') as file:
            file.write(content)


def get_restful_content(resource, version, restful_tmp, restful_api_tmp):
    if not issubclass(resource, YgResource):
        return 'not yg_resource'
    route_list = get_url_list(resource, version)
    if len(route_list) == 1:
        route_list = route_list[0]
    configs = []
    method_dict = {}
    for attr in dir(resource):
        if not attr.startswith('__'):
            continue
        param = getattr(resource, attr)
        if param is None:
            continue
        resolve_resource(method_dict, attr, param)
    error_code = method_dict.pop('error_code', '')
    for method, attr_dict in method_dict.items():
        if attr_dict:
            configs.append({
                'method': method,
                'param_table': '\n\n'.join(
                    attr_dict.get('args', []) + attr_dict.get('json', [])
                ),
                'request_sample': '\n'.join(attr_dict.get('request', [])),
                'response_sample': '\n'.join(attr_dict.get('response', []))
            })

    return restful_tmp.format(
        url=route_list,
        class_doc=resource.__doc__,
        error_code=error_code,
        api='\n\n'.join([
            restful_api_tmp.format(**config)
            for config in configs
        ])
    )


def get_sample(param):
    if isinstance(param, Sample):
        param = [param]
    if not isinstance(param, list):
        return 'unknown'
    return get_md_table([
        ['data', 'description'],
        *[[sample.data, sample.description] for sample in param]
    ])


def resolve_resource(method_dict, attr, param):
    if attr == '__error_code_list__' and isinstance(param, list) and param:
        method_dict.setdefault('error_code', get_md_table([
            ['code', 'description'],
            *[[error_code.code, error_code.description] for error_code in param]
        ]))
        return

    words = attr.strip('__').split('_')
    if len(words) != 3:
        return
    if words[0] not in ['get', 'put', 'post', 'delete']:
        return
    attr_dict = method_dict.setdefault(words[0].upper(), {})
    attr_list = attr_dict.setdefault(words[1], [])
    if words[2] == 'schema':
        attr_list.append(get_schema(words[1], param))
    if words[2] == 'sample':
        attr_list.append(get_sample(param))


def get_celery_content(tasks, celery_tmp, celery_api_tmp):
    return celery_tmp.format(
        class_doc='',
        api='\n\n'.join([
            celery_api_tmp.format(
                task_name=task.name,
                signature=task.__name__ + str(inspect.signature(task)),
                param_table='',
                return_table=''
            )
            for task in tasks
        ])
    )


def get_filed_list(key, value, requires):
    value_type = value.get(SCHEMA.TYPE)
    options = [repr(item) for item in value.get(SCHEMA.ENUM, [])]
    if value_type is None:
        value_type = SCHEMA.ENUM if options else 'string'
    return [
        key,
        'int' if value_type == SCHEMA.Types.INT else value_type,
        'required' if key in requires else '',
        value.get(SCHEMA.DESCRIPTION, ''),
        '<br>'.join(options)
    ]


def get_schema(table_type, param):
    if isinstance(param, Args):
        param = param.get()
    requires = param.get(SCHEMA.REQUIRED, [])
    return '\n\n'.join([table_type, get_md_table([
        ['field', 'type', 'require', 'description', 'options'],
        *[get_filed_list(key, value, requires) for key, value in param.get(SCHEMA.PROPERTIES, {}).items()]
    ])])