# -*- coding:utf-8 -*-
# File Name:celery_interface_generator.py
# Author:jing
# Copyright:yiguotech.com
# Date:2018/11/28
from importlib import import_module

import celery

from ygframe import SYSTEM_CONFIG
from ygframe.dev_tool.generator_util import get_template
from ygframe.dev_tool.doc_file_generator.flask_app_doc_generator import get_celery_content
from ygframe.scope.scope import Scope
from ygframe.util.file_util import ensure_file
from ygframe.util.import_util import chain_find_modules

__author__ = 'jing'


def generate_celery_files():
    restful_template, restful_api_template, celery_template, celery_api_template = get_template(
        'restful.md', 'restful_api.md', 'celery.md', 'celery_api.md'
    )
    current_subsystem = Scope.get_subsystem_name()
    tasks = []
    for module_name in chain_find_modules(
            SYSTEM_CONFIG.CELERY_TASK_MODULE_NAME,
            SYSTEM_CONFIG.CELERY_BEAT_TASK_MODULE,
    ):
        try:
            module = import_module(module_name)
            if hasattr(module, 'export'):
                tasks.extend(getattr(module, 'export'))
                continue
            subsystem = module_name[module_name.rindex('.'):].strip('.')
            is_current_subsystem = current_subsystem == subsystem
            for attr, value in module.__dict__.items():
                if isinstance(value, celery.Task):
                    task_name = value.name  # type:str
                    if is_current_subsystem and task_name.endswith('{}.{}'.format(subsystem, value.__name__)):
                        tasks.append(value)
        except:
            pass
    file_name = '../doc/celery/{}.md'.format(current_subsystem)
    with open(ensure_file(file_name), 'w') as file:
        file.write(get_celery_content(tasks, celery_template, celery_api_template))