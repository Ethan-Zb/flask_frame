# -*- coding:utf-8 -*-
"""
--------------------------------------------
File Name:doc_generator.py
Author:jing
Copyright:yiguotech.com
date:2018/07/26
--------------------------------------------
"""

from ygframe.builder import Builder
from ygframe.dev_tool.doc_file_generator.celery_interface_generator import generate_celery_files
from ygframe.dev_tool.doc_file_generator.flask_app_doc_generator import generate_flask_doc_files
from ygframe.dev_tool.doc_file_generator.model_doc_generator import generate_mongo_table_doc, generate_data_model_doc
from ygframe.flask_app import travel_resources

__author__ = 'jing'


def generate():
    resources = travel_resources()
    if resources:
        generate_flask_doc_files(resources)

    if Builder.celery_initialized:
        generate_celery_files()

    if Builder.mongo_initialized:
        generate_mongo_table_doc()

    generate_data_model_doc()
