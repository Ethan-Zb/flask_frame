# -*- coding:utf-8 -*-
"""
--------------------------------------------
File Name:globals_generator.py
Author:jing
Copyright:yiguotech.com
date:2018/05/13
--------------------------------------------
"""
import time

import pkg_resources

from ygframe import SYSTEM_CONFIG
from ygframe.logger import logger
from ygframe.util.date_util import get_date
from ygframe.util.file_util import protect_open

__author__ = 'jing'


def generate(with_init=False, is_read_only=True):
    if with_init:
        __import__(SYSTEM_CONFIG.INITIALIZER_MODULE_NAME).init()
    globals_value = __import__(SYSTEM_CONFIG.GLOBALS_MODULE_NAME).GLOBALS
    globals_file_name = SYSTEM_CONFIG.GLOBALS_MODULE_FILE

    content = get_file_content(globals_value)

    with protect_open(globals_file_name, is_read_only) as globals_file:
        globals_file.write(content)

    logger.info('generate globals done')


def get_file_content(globals_value):
    getter_template = pkg_resources.resource_string('ygframe', 'dev_tool/template/getter').decode()
    setter_template = pkg_resources.resource_string('ygframe', 'dev_tool/template/setter').decode()
    globals_template = pkg_resources.resource_string('ygframe', 'dev_tool/template/globals').decode()
    main_template = pkg_resources.resource_string('ygframe', 'dev_tool/template/globals_main').decode()
    import_list = []
    init_list = []
    attribute_list = []
    for attr in dir(globals_value):
        if attr.startswith('_'):
            continue
        if attr == 'debug':
            continue

        try:
            value = getattr(globals_value, attr)
            if value is None:
                continue
            if hasattr(value, '__module__'):
                module = value.__module__
                class_name = value.__class__.__name__
                import_list.append('from {} import {}'.format(module, class_name))
            else:
                class_name = str(type(value).__name__)

            init_list.append('self._{} = None'.format(attr))
            attribute_list.append('\n\n    '.join([
                getter_template.format(attribute=attr, class_name=class_name),
                setter_template.format(attribute=attr, class_name=class_name)
            ]))
        except Exception as e:
            logger.exception(str(e))
    date = get_date()
    import_lines = '\n'.join(sorted(list(set(import_list))))
    init_lines = '\n        '.join(sorted(list(set(init_list)))) or '\n        pass'
    attribute_lines = '\n\n    '.join(sorted(attribute_list))
    return globals_template.format(
        date=date, import_lines=import_lines,
        attribute_lines=attribute_lines,
        init_lines=init_lines,
        main=main_template
    )


def reset(is_read_only=True):
    globals_template = pkg_resources.resource_string('ygframe', 'dev_tool/template/globals').decode()
    main_template = pkg_resources.resource_string('ygframe', 'dev_tool/template/globals_main').decode()
    date = get_date()
    globals_file_name = SYSTEM_CONFIG.GLOBALS_MODULE_FILE
    content = globals_template.format(
        date=date, import_lines="",
        attribute_lines='',
        init_lines='pass',
        main=main_template
    )

    with protect_open(globals_file_name, is_read_only) as globals_file:
        globals_file.write(content)
