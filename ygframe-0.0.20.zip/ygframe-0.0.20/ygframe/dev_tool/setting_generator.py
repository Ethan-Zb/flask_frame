# -*- coding:utf-8 -*-
"""
--------------------------------------------
File Name:setting_generator.py
Author:jing
Copyright:yiguotech.com
date:2018/05/13
--------------------------------------------
"""
import time

import pkg_resources
import yaml

from ygframe import SYSTEM_CONFIG
from ygframe.logger import logger
from ygframe.util.date_util import get_date
from ygframe.util.dict_util import flatten_dict
from ygframe.util.file_util import make_read_only, protect_open
from ygframe.util.str_util import get_between

__author__ = 'jing'


def get_type(v):
    if v is None:
        return 'None'
    return {
        int: 'int()',
        float: 'float()',
        bool: 'bool()',
        str: 'str()'
    }.get(type(v))


def generate(is_read_only=True):
    template = pkg_resources.resource_string('ygframe', 'dev_tool/template/setting').decode()
    main_template = pkg_resources.resource_string('ygframe', 'dev_tool/template/setting_main').decode()
    date = get_date()
    config_file_name = SYSTEM_CONFIG.CONFIG_FILE
    setting_file_name = SYSTEM_CONFIG.SETTING_MODULE_FILE
    with open(setting_file_name) as old_setting:
        try:
            methods = get_between(old_setting.read(), ' def ', 'SETTING = __SETTING()', include_left=True)
            methods = '\n    ' + methods.strip() + '\n'
        except:
            methods = ''

    with open(config_file_name) as config_file, protect_open(setting_file_name, is_read_only) as setting_file:
        setting_dict = yaml.safe_load(config_file.read())
        lines = []
        for key, value in flatten_dict(setting_dict).items():
            upper_key = key.strip('/').split('/')[-1].upper()
            lines.append(
                '{} = {}  # {}'.format(
                    upper_key, get_type(value), value
                )
            )
        setting_file.write(template.format(
            date=date, lines='\n    '.join(sorted(lines)), main=main_template, methods=methods))
        logger.info('generate setting done')
    make_read_only(setting_file_name)


def reset(is_read_only=True):
    template = pkg_resources.resource_string('ygframe', 'dev_tool/template/setting').decode()
    main_template = pkg_resources.resource_string('ygframe', 'dev_tool/template/setting_main').decode()
    date = get_date()
    setting_file_name = SYSTEM_CONFIG.SETTING_MODULE_FILE
    with protect_open(setting_file_name, is_read_only) as file:
        file.write(template.format(date=date, lines='pass', main=main_template, methods=''))
