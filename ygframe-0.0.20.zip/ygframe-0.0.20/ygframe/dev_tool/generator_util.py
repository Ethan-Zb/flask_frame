# -*- coding:utf-8 -*-
# File Name:generator_util.py
# Author:jing
# Copyright:yiguotech.com
# Date:2018/11/28
from typing import List

import pkg_resources

from ygframe.serialize.yg_encoder import dumps

__author__ = 'jing'


def get_md_table(data: List[List]):
    value = ['|{}|'.format('|'.join([resolve(_) for _ in line])) for line in data]
    value.insert(1, '|{}|'.format('|'.join(['-----'] * len(data[0]))))
    return '\n'.join(value)


def get_template(*args):
    return (
        pkg_resources.resource_string('ygframe', 'dev_tool/sample_project/doc/' + arg).decode()
        for arg in args
    )


def resolve(value):
    if isinstance(value, dict):
        return dumps(value, indent=4).replace('\n', '<br>').replace(' ', '&nbsp;')
    return str(value)
