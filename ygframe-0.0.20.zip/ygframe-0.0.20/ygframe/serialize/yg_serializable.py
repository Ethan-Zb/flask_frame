# -*- coding:utf-8 -*-
"""
--------------------------------------------
File Name:yg_serializable.py
Author:jing
Copyright:yiguotech.com
date:2018/09/07
--------------------------------------------
"""
from abc import abstractmethod
from typing import Any

from ygframe.util.inspect_util import get_full_name

__author__ = 'jing'


class YgSerializable(object):
    def __new__(cls, *args, **kwargs) -> Any:
        value = super().__new__(cls)
        value.__serialize_class__ = get_full_name(value.__class__)
        return value

    @abstractmethod
    def to_dict(self):
        raise NotImplemented

    @classmethod
    @abstractmethod
    def from_dict(cls, obj: dict):
        raise NotImplemented

    @abstractmethod
    def dumps(self):
        raise NotImplemented

    @classmethod
    @abstractmethod
    def loads(cls, obj: str):
        raise NotImplemented
