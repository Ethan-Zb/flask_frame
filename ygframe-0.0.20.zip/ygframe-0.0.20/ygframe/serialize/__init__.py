# -*- coding:utf-8 -*-
"""
--------------------------------------------
File Name:__init__.py.py
Author:jing
Copyright:yiguotech.com
date:2018/09/07
--------------------------------------------
"""
__author__ = 'jing'

SERIALIZE_CLASS = '__serialize_class__'
SERIALIZE_TYPE = '__serialize_type__'
