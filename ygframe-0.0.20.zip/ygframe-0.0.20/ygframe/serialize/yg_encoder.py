# -*- coding:utf-8 -*-
"""
--------------------------------------------
File Name:yg_encoder.py
Author:jing
Copyright:yiguotech.com
date:2018/09/12
--------------------------------------------
"""
import json
from abc import abstractmethod
from enum import Enum

from ygframe.serialize import SERIALIZE_CLASS, SERIALIZE_TYPE
from ygframe.serialize.yg_serializable import YgSerializable
from ygframe.util.inspect_util import load_by_full_name, get_full_name

__author__ = 'jing'


class Encoder(json.JSONEncoder):
    @abstractmethod
    def default(self, o):
        raise NotImplemented

    @staticmethod
    @abstractmethod
    def object_hook(obj):
        raise NotImplemented


class YgEncoder(Encoder):

    def default(self, o):
        if isinstance(o, YgSerializable):
            from ygframe.logger.logger_context import error_exception
            with error_exception():
                return o.to_dict()
        if isinstance(o, type):
            return {SERIALIZE_TYPE: get_full_name(o)}

        return json.JSONEncoder.default(self, o)

    @staticmethod
    def object_hook(obj):
        if isinstance(obj, dict):
            cls_name = obj.get(SERIALIZE_CLASS)
            if cls_name:
                cls = load_by_full_name(cls_name)
                if issubclass(cls, YgSerializable):
                    return cls.from_dict(obj)
            type_name = obj.get(SERIALIZE_TYPE)
            if type_name:
                return load_by_full_name(type_name)

        return obj


def dumps(obj, **kwargs):
    return json.dumps(obj, cls=YgEncoder, **kwargs)


def loads(obj):
    return json.loads(obj, object_hook=YgEncoder.object_hook)
