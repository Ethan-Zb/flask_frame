# -*- coding:utf-8 -*-
"""
--------------------------------------------
File Name:dict_serializable.py
Author:jing
Copyright:yiguotech.com
date:2018/09/07
--------------------------------------------
"""
import json

from ygframe.serialize import yg_encoder

from ygframe.serialize.yg_serializable import YgSerializable
from ygframe.util import NotSet

__author__ = 'jing'


class DictSerializable(YgSerializable):

    def to_dict(self):
        return {
            key: value
            for key, value in self.__dict__.items()
            if value is not NotSet
        }

    @classmethod
    def from_dict(cls, obj: dict):
        ret = object.__new__(cls)
        ret.__dict__.update(obj)
        return ret

    def dump_to_dict(self):
        return json.loads(yg_encoder.dumps(self))

    @classmethod
    def load_from_dict(cls, obj):
        return cls.loads(json.dumps(obj))

    def dumps(self):
        return yg_encoder.dumps(self)

    @classmethod
    def loads(cls, obj: str):
        return yg_encoder.loads(obj)
