# -*- coding:utf-8 -*-
# File Name:type_serializable.py
# Author:jing
# Copyright:yiguotech.com
# Date:2018/11/12
from ygframe.serialize import SERIALIZE_TYPE, yg_encoder
from ygframe.serialize.yg_serializable import YgSerializable
from ygframe.util.inspect_util import load_by_full_name, get_full_name

__author__ = 'jing'


class TypeSerializable(YgSerializable):
    def to_dict(self):
        return {SERIALIZE_TYPE: get_full_name(self)}

    @classmethod
    def from_dict(cls, obj: dict):
        return load_by_full_name(obj.get(SERIALIZE_TYPE))

    def dumps(self):
        return yg_encoder.dumps(self)

    @classmethod
    def loads(cls, obj: str):
        return yg_encoder.loads(obj)
