# -*- coding:utf-8 -*-
"""
--------------------------------------------
File Name:hbase_model.py
Author:jing
Copyright:yiguotech.com
date:2018/05/10
--------------------------------------------
"""
from abc import abstractmethod
from contextlib import contextmanager
from functools import lru_cache

from happybase import Connection, Table, Batch

from ygframe.db import GetMode
from ygframe.db.abstract_model import AbstractModel
from ygframe.db.column import Column
from ygframe.db.filter import SimpleFilter, And, FilterOp, Filter
from ygframe.db.query import Query
from ygframe.hbase_wrapper import hbase_connection
from ygframe.util import NotSet
from ygframe.util.str_util import get_snake_case

__author__ = 'jing'


class AbstractHbaseModel(AbstractModel):
    __default_column_family__ = None
    __table_name__ = None

    @classmethod
    def get_column_key(cls, k: bytes):
        # if ':' in k.decode():
        #     return k.decode().split(':', maxsplit=1)[1]
        # else:
        return k.decode()

    @classmethod
    def _get_criteria(cls, flt: Filter):
        if isinstance(flt, SimpleFilter):
            if flt.op != FilterOp.EQUAL:
                raise NotImplemented
            if not isinstance(flt.field, bytes):
                raise ValueError
            return {cls.get_column_key(flt.field): flt.value}
        if isinstance(flt, And):
            create_dict = {}
            for f in flt.filters:
                create_dict.update(cls._get_criteria(f))
            return create_dict
        raise NotImplemented

    @classmethod
    def get(cls, query: Query):
        with cls.table() as table:  # type:Table
            if query.get_mode_ == GetMode.FIRST:
                if query.filter_:
                    row_value = table.row(
                        cls.create(**cls._get_criteria(query.filter_)).get_row_key(),
                        columns=query.query_
                    )
                    return cls.load_row_value(row_value)

    @classmethod
    def load_row_value(cls, row_value):
        model = object.__new__(cls)
        type_dict = cls.get_type_dict()
        for key, value in row_value.items():
            try:
                cf, column = key.decode().split(':', maxsplit=1)
                if '-' in column:
                    column = column.replace('-', '_')
                setattr(model, column, type_dict[key](value.decode()))
            except Exception as e:
                continue

        return model

    @classmethod
    def update(cls, query: Query, obj):
        raise NotImplemented

    @classmethod
    def delete(cls, query: Query):
        with cls.table() as table:  # type:Table
            key = cls.create(**cls._get_criteria(query.filter_)).get_row_key()
            if query.query_:
                table.delete(key, columns=query.query_)
            else:
                table.delete(key)

    def save(self):
        with self.table() as table:  # type:Table
            table.put(self.get_row_key(), self.get_row_value())

    @classmethod
    def save_all(cls, obj):
        with cls.batch() as batch:  # type:Batch
            for item in obj:  # type:AbstractHbaseModel
                batch.put(item.get_row_key(), item.get_row_value())

    @classmethod
    @contextmanager
    def batch(cls):
        with cls.table() as table:  # type:Table
            batch = table.batch()
            yield batch
            batch.send()

    @abstractmethod
    def get_row_key(self) -> str:
        raise NotImplemented

    def get_row_value(self) -> dict:
        value_dict = {}
        for column in self.get_columns():
            key = self.get_column_key(column.key)
            cf = column.cf.name
            if hasattr(self, key):
                value = getattr(self, key)
                if value is None:
                    continue
                value_dict['{}:{}'.format(cf, key)] = str(value)
        return value_dict

    @classmethod
    def get_table(cls, connection: Connection) -> Table:
        return connection.table(cls.get_table_name())

    @classmethod
    @contextmanager
    def table(cls):
        with hbase_connection() as connection:  # type:Connection
            yield connection.table(cls.get_table_name())

    @classmethod
    def get_table_name(cls):
        if not cls.__table_name__:
            cls.__table_name__ = get_snake_case(cls.__name__)
        return cls.__table_name__

    @classmethod
    @lru_cache()
    def get_column_families(cls):
        column_families = {}
        cls.__default_column_family__ = None
        for k, v in cls.__dict__.items():
            if isinstance(v, ColumnFamily):
                if not v.name:
                    v.name = k
                column_families[v.name] = {
                    key: value
                    for key, value in v.family.items()
                    if value is not NotSet
                }
                if v.is_default:
                    if cls.__default_column_family__:
                        raise ValueError('Multiple default column family')
                    else:
                        cls.__default_column_family__ = v
        if not column_families:
            column_families = {'info': dict()}
            cls.__default_column_family__ = ColumnFamily('info')
        return column_families

    @classmethod
    @lru_cache()
    def get_columns(cls):
        cls.get_column_families()
        columns = []
        for k, v in cls.__dict__.items():
            if isinstance(v, HbaseColumn):
                if not v.cf:
                    v.cf = cls.__default_column_family__
                if not v.key:
                    v.key = '{}:{}'.format(v.cf.name, k).encode()
                if not isinstance(v.key, bytes):
                    v.key = v.key.encode()
                columns.append(v)
        return columns

    @classmethod
    @lru_cache()
    def get_type_dict(cls):
        return {
            column.key: column.key_type
            for column in cls.get_columns()
        }

    @classmethod
    @lru_cache()
    def get_column_keys(cls):
        return [cls.get_column_key(column.key) for column in cls.get_columns()]

    def upsert(self, query: Query, obj):
        pass  # todo  

    def count(self, query: Query):
        pass  # todo


class ColumnFamily(object):
    """
     * ``max_versions`` (`int`)
        * ``compression`` (`str`)
        * ``in_memory`` (`bool`)
        * ``bloom_filter_type`` (`str`)
        * ``bloom_filter_vector_size`` (`int`)
        * ``bloom_filter_nb_hashes`` (`int`)
        * ``block_cache_enabled`` (`bool`)
        * ``time_to_live`` (`int`)

        NotSet to use happy base default value
    """

    def __init__(
            self,
            name: str = NotSet,
            is_default: bool = False,
            max_versions: int = NotSet,
            compression: str = NotSet,
            in_memory: bool = NotSet,
            bloom_filter_type: str = NotSet,
            bloom_filter_vector_size: int = NotSet,
            bloom_filter_nb_hashes: int = NotSet,
            block_cache_enabled: bool = NotSet,
            time_to_live: int = NotSet
    ) -> None:
        self.name = name
        self.is_default = is_default
        self.family = dict(
            max_versions=max_versions,
            compression=compression,
            in_memory=in_memory,
            bloom_filter_type=bloom_filter_type,
            bloom_filter_vector_size=bloom_filter_vector_size,
            bloom_filter_nb_hashes=bloom_filter_nb_hashes,
            block_cache_enabled=block_cache_enabled,
            time_to_live=time_to_live
        )


class HbaseColumn(Column):

    def __init__(self, key_type: type = str, key: str = NotSet, default=None, cf: ColumnFamily = None):
        super().__init__(key_type, key, default, index=False)
        self.cf = cf


def generate_hbase_methods(model_class):
    """
    :param model_class:
    :return:
    """
    if not issubclass(model_class, AbstractHbaseModel):
        raise ValueError('model_class must be a subclass of AbstractHbaseModel')
    template = """    def __init__(
        self,
        {column_lines}
    ) -> None:
        {init_lines}
"""
    columns = model_class.get_columns()
    column_list = '"{}"'.format(
        '", "'.join(model_class.get_column_keys())
    )
    column_lines = ',\n        '.join([
        '{}: {} = NotSet'.format(model_class.get_column_key(column.key), column.key_type.__name__)
        for column in columns
    ])
    init_lines = '\n        '.join([
        'self.{}={}'.format(model_class.get_column_key(column.key), model_class.get_column_key(column.key))
        for column in columns
    ])
    return template.format(**dict(
        column_list=column_list, column_lines=column_lines, init_lines=init_lines
    ))


if __name__ == '__main__':
    class A(AbstractHbaseModel):
        info = ColumnFamily(is_default=True)

        name = HbaseColumn(cf=info)
        age = HbaseColumn(int, cf=info)

        def __init__(
                self,
                age: int = NotSet,
                name: str = NotSet
        ) -> None:
            self.age = age
            self.name = name


    print(generate_hbase_methods(A))
