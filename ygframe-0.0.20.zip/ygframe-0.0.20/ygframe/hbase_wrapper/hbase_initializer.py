# -*- coding:utf-8 -*-
"""
--------------------------------------------
File Name:hbase_initializer.py
Author:jing
Copyright:yiguotech.com
date:2018/05/09
--------------------------------------------
"""

import happybase

from ygframe import hbase_wrapper, SYSTEM_CONFIG
from ygframe.hbase_wrapper.hbase_model import AbstractHbaseModel
from ygframe.logger import logger
from ygframe.scope.scope import Scope
from ygframe.util import NotSet
from ygframe.util.import_util import get_all
from ygframe.util.str_util import get_snake_case

__author__ = 'jing'


def get_pool(
        host='localhost',
        port=9090,
        size=64,
        table_prefix=None,
        timeout=60000,
):
    pool = happybase.ConnectionPool(size=size, host=host, port=port, table_prefix=table_prefix, timeout=timeout)
    return pool


def get_connection(
        host='localhost',
        port=9090,
        table_prefix=None,
        timeout=60000,
):
    return happybase.Connection(host=host, port=port, timeout=timeout, table_prefix=table_prefix)


def init(
        host: str = 'localhost',
        port: int = 9090,
        size: int = 64,
        timeout: int = 60000,
        table_prefix: str = NotSet,
        create_tables: dict = None,
        auto_load: bool = True,
):
    if table_prefix is NotSet:
        table_prefix = Scope.get_scope_name(Scope.SYSTEM)
    pool = get_pool(size=size, host=host, port=port, timeout=timeout, table_prefix=table_prefix)
    hbase_wrapper.__hbase_pool = pool

    conn_params = {
        'host': host,
        'port': port,
        'table_prefix': table_prefix,
        'timeout': timeout,
    }
    hbase_wrapper.__hbase_conn_params = conn_params
    connection = hbase_wrapper.get_connection()

    create_tables = create_tables or {}

    if auto_load:
        for value in get_all(SYSTEM_CONFIG.HBASE_MODEL_MODULE_NAME, AbstractHbaseModel):  # type:AbstractHbaseModel
            try:
                create_tables[value.get_table_name()] = value.get_column_families()
            except:
                logger.exception('auto_load {} error'.find(value.__name__))

    if create_tables:
        for table_name, families in create_tables.items():
            try:
                connection.create_table(table_name, families)
                logger.info('created hbase table: {}_{}'.format(table_prefix, table_name))
            except:
                logger.info(
                    'hbase table : {}_{} exists. or other exception raised'.format(table_prefix, table_name))

    logger.info('init hbase done')
    return connection
