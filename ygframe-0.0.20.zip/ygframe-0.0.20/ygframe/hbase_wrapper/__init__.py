# -*- coding:utf-8 -*-
"""
--------------------------------------------
File Name:__init__.py.py
Author:jing
Copyright:yiguotech.com
date:2018/05/09
--------------------------------------------
"""
import contextlib
import socket

from happybase import Connection, ConnectionPool
from thriftpy.thrift import TException

from ygframe.logger import logger
from ygframe.logger.logger_context import error_exception
from ygframe.util.precondition import not_none
from ygframe.util.retry import scope_retry

__author__ = 'jing'

__hbase_pool = None
__hbase_conn_params = dict()


def get_connection() -> Connection:
    return Connection(**__hbase_conn_params)


@contextlib.contextmanager
def hbase_connection():
    pool = not_none(__hbase_pool, error_message='hbase has not been initialized')  # type: ConnectionPool
    for turn in scope_retry():
        with error_exception(exception=(TException, socket.error), message='hbase connection error'):
            with pool.connection() as connection:
                yield connection
                if turn >= 1:
                    logger.info('success yield and exit...')
                break
