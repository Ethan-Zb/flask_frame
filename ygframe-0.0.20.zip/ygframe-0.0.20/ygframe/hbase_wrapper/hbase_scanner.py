# -*- coding:utf-8 -*-
"""
--------------------------------------------
File Name:hbase_scanner.py
Author:jing
Copyright:yiguotech.com
date:2018/05/11
--------------------------------------------
"""
from ygframe.logger.logger_context import error_exception

from ygframe.util.retry import scope_retry, Retry

from ygframe.hbase_wrapper import hbase_connection
from ygframe.hbase_wrapper.hbase_model import AbstractHbaseModel, HbaseColumn
from ygframe.logger import logger
from ygframe.util.ensure import ensure_str
from ygframe.util.persistence_util import PersistenceHandler

__author__ = 'jing'


class HbaseScanner(object):
    MAX_VISIBLE_ASCII = '~'

    def __init__(
            self,
            hbase_model_class: type,
            auto_convert=True,
            after_batch=None,
            persistence_handler: PersistenceHandler = None,
            max_retries=Retry.FOREVER,
    ):
        self.cls = hbase_model_class  # type:AbstractHbaseModel
        if issubclass(hbase_model_class, AbstractHbaseModel):
            self.table_name = hbase_model_class.__table_name__
            self.auto_convert = auto_convert
            self.after_batch = after_batch
            self.persistence_handler = persistence_handler
            self.max_retries = max_retries
        else:
            raise ValueError()

    def scan(self, row_start: str = None, row_stop: str = None, row_prefix: str = None,
             columns=None, filter=None, timestamp=None, include_timestamp=False,
             batch_size=1000, limit=None, sorted_columns=False, reverse=False):
        """
        :param auto_convert: if set True, return model object, or (object,ts) when set include_timestamp
        :param row_start: \
        :param row_stop:   |-> scan range
        :param row_prefix:/
        :param columns:            \
        :param filter:              |-> result format
        :param timestamp:           |
        :param include_timestamp:  /
        :param batch_size:        \
        :param limit:             /  -> batch and limit
        :param sorted_columns:    \  -> sort
        :param reverse:           /
        :return:
        """

        last_start_row = row_start or ''

        if row_prefix:
            last_start_row, row_stop = row_prefix, row_prefix + self.MAX_VISIBLE_ASCII
        elif not row_start and self.persistence_handler:
            last_persistence = self.persistence_handler.load()
            if last_persistence:
                last_start_row = last_persistence
        if columns:
            if isinstance(columns[0], HbaseColumn):
                columns = [
                    column.key for column in columns
                ]

        if self.auto_convert and include_timestamp:
            logger.warning('not support convert with include_timestamp, auto_convert will be ignored')

        logger.info('start scanning {} from row {}...'.format(self.table_name, last_start_row))
        n_returned = 0

        while last_start_row is not None:
            for turn in scope_retry(max_retries=self.max_retries):
                with error_exception():
                    last_start_row = yield from self.get_item(
                        batch_size, columns, filter, include_timestamp,
                        last_start_row, limit, n_returned, reverse, row_stop,
                        sorted_columns, timestamp)

                    if turn >= 1:
                        logger.info('success after retries for {} turn'.format(turn))
                    break

            if callable(self.after_batch):
                self.after_batch()

    def get_item(self, batch_size, columns, filter, include_timestamp, last_start_row, limit, n_returned, reverse,
                 row_stop, sorted_columns, timestamp):
        with hbase_connection() as connection:
            table = connection.table(self.table_name)
            scanner = table.scan(
                row_start=last_start_row, row_stop=row_stop, columns=columns,
                filter=filter, timestamp=timestamp, include_timestamp=include_timestamp,
                batch_size=batch_size + 1, limit=batch_size + 1,
                sorted_columns=sorted_columns, reverse=reverse
            )
            index = 0
            for index, item in enumerate(scanner):
                if index == batch_size:
                    last_start_row = item[0]
                    if self.persistence_handler:
                        self.persistence_handler.save(ensure_str(last_start_row))
                else:
                    if not include_timestamp and self.auto_convert:
                        yield self.cls.load_row_value(item[1])
                    else:
                        yield item
                    n_returned += 1
                    if limit and n_returned >= limit:
                        break
            if index != batch_size:
                last_start_row = None
                if self.persistence_handler:
                    self.persistence_handler.reset()
        return last_start_row
