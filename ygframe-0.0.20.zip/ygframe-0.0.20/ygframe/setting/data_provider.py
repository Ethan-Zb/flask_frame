# -*- coding:utf-8 -*-
#
# Author:jing
# Copyright:yiguotech.com
# date:2018/05/06

# pylint:disable=missing-docstring
from abc import abstractmethod

from ygframe.util.singleton import Singleton

__author__ = 'jing'


class DataProvider(metaclass=Singleton):
    @abstractmethod
    def read_data(self):
        pass

    @abstractmethod
    def write_data(self, data):
        pass
