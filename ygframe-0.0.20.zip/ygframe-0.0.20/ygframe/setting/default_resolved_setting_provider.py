# -*- coding:utf-8 -*-
#
# Author:jing
# Copyright:yiguotech.com
# date:2018/05/06

# pylint:disable=missing-docstring
from etcd import Client

from ygframe.setting.data_provider import DataProvider
from ygframe.setting.etcd2_data_provider import Etcd2DataProvider
from ygframe.setting.resolved_setting_provider import ResolvedSettingProvider
from ygframe.setting.yaml_data_provider import YamlDataProvider

__author__ = 'jing'


class DefaultResolvedSettingProvider(ResolvedSettingProvider):
    def __init__(
            self,
            use_local_setting: bool = False,
            config_file: str = 'config.yaml',
            etcd_client: Client = None
    ) -> None:
        self.config_file = config_file
        self.etcd_client = etcd_client
        super().__init__(use_local_setting)

    def get_refresh_data_provider(self) -> Etcd2DataProvider:
        return Etcd2DataProvider(self.etcd_client, self.config_file)

    def get_init_data_provider(self) -> DataProvider:
        return YamlDataProvider(self.config_file)

    def watch_data(self):
        pass
