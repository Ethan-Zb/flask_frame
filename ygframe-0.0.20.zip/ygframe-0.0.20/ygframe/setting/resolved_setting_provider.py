# -*- coding:utf-8 -*-
#
# Author:jing
# Copyright:yiguotech.com
# date:2018/05/06

# pylint:disable=missing-docstring
from abc import abstractmethod

from ygframe.logger import logger
from ygframe.setting import SETTING
from ygframe.setting.data_provider import DataProvider
from ygframe.setting.setting_provider import SettingProvider

__author__ = 'jing'


class ResolvedSettingProvider(SettingProvider):
    def __init__(self, use_local_setting: bool = False) -> None:
        self.use_local_setting = use_local_setting
        self._init_data_provider = self.get_init_data_provider()
        self._refresh_data_provider = self.get_refresh_data_provider()

    @abstractmethod
    def get_init_data_provider(self) -> DataProvider:
        pass

    @abstractmethod
    def get_refresh_data_provider(self) -> DataProvider:
        pass

    @abstractmethod
    def watch_data(self):
        pass

    def _init_data(self):
        init_provider_data = self._init_data_provider.read_data()
        if not self.use_local_setting:
            self._refresh_data_provider.write_data(init_provider_data)
        return init_provider_data

    def heart_beat(self, on_init=False):
        fresh_data = self._refresh_data_provider.read_data()
        SETTING.refresh(fresh_data, on_init)
        logger.info('etcd refreshed')

    def init_setting(self):
        local_data = self._init_data()
        if self.use_local_setting:
            SETTING.refresh(local_data, on_init=True)
        else:
            self.heart_beat(on_init=True)
            self.watch_data()
