# -*- coding:utf-8 -*-
#
# Author:jing
# Copyright:yiguotech.com
# date:2018/05/06

# pylint:disable=missing-docstring
from abc import abstractmethod

__author__ = 'jing'


class SettingProvider:
    @abstractmethod
    def init_setting(self):
        pass

    @abstractmethod
    def heart_beat(self, on_init=False):
        pass
