# -*- coding:utf-8 -*-
#
# Author:jing
# Copyright:yiguotech.com
# date:2018/05/06

# pylint:disable=missing-docstring
import os

import etcd

from ygframe import SYSTEM_CONFIG
from ygframe.logger import logger
from ygframe.setting.default_resolved_setting_provider import DefaultResolvedSettingProvider
from ygframe.setting.setting_provider import SettingProvider
from ygframe.task.cyclic_task import CyclicTask
from ygframe.task.task_manager import CoreTaskManager

__author__ = 'jing'


def init(provider: SettingProvider = None, heart_beating_seconds=600, use_local_setting=False):
    provider.init_setting()
    if not use_local_setting:
        CoreTaskManager.register(CyclicTask(
            task=provider.heart_beat,
            cyclic_wait=heart_beating_seconds,
            handle_key='etcd_beat'
        ))
    logger.info('init setting done')


def init_default(
        use_local_setting: bool = False,
        etcd_host: str = None,
        etcd_port: int = None,
        heart_beating_seconds=SYSTEM_CONFIG.ETCD_REFRESH_INTERVAL
):
    etcd_host = etcd_host or os.environ.get(SYSTEM_CONFIG.ETCD_HOST_ENV_KEY, 'localhost')
    etcd_port = etcd_port or int(os.environ.get(SYSTEM_CONFIG.ETCD_PORT_ENV_KEY, 2379))
    client = etcd.Client(host=etcd_host, port=etcd_port)
    provider = DefaultResolvedSettingProvider(
        use_local_setting=use_local_setting,
        config_file=SYSTEM_CONFIG.CONFIG_FILE,
        etcd_client=client
    )
    init(provider, heart_beating_seconds=heart_beating_seconds, use_local_setting=use_local_setting)
    return client
