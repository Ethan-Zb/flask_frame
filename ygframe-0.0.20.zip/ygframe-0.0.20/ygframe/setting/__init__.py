# -*- coding:utf-8 -*-
#
# Author:jing
# Copyright:yiguotech.com
# date:2018/05/06

# pylint:disable=missing-docstring
import time
from numbers import Number

from ygframe import SYSTEM_CONFIG, shared_memory
from ygframe.setting.abstract_setting import AbstractSetting
from ygframe.util.singleton import Singleton

__author__ = 'jing'

try:
    MODULE = __import__(SYSTEM_CONFIG.SETTING_MODULE_NAME).SETTING
    if isinstance(MODULE, AbstractSetting):
        SETTING = MODULE
    else:
        raise AttributeError

except (ImportError, AttributeError):
    SETTING = AbstractSetting()


def get_setting(key, default=None):
    value = getattr(SETTING, key, default)
    return value if value is not None else default


def sleep_by_setting(key):
    value = get_setting(key)
    if value and isinstance(value, Number):
        time.sleep(key)
