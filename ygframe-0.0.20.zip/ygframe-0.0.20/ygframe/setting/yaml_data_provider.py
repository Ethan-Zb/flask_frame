# -*- coding:utf-8 -*-
#
# Author:jing
# Copyright:yiguotech.com
# date:2018/05/06

# pylint:disable=missing-docstring
import yaml

from ygframe.setting.data_provider import DataProvider
from ygframe.util.dict_util import flatten_dict

__author__ = 'jing'


class YamlDataProvider(DataProvider):
    """
    格式说明：
    1、所有的key必须是字符串
    2、不支持原生数组，-.inf 和.NaN，date类型数据。可以用resolver来解决。（yaml格式错误或者使用不支持的数据，可能
        造成不可预见的错误）
    3、其他情况请参考yaml文档，
    """

    def __init__(self, config_file='config.yaml') -> None:
        self.config_file = config_file

    def read_data(self):
        with open(self.config_file) as file:
            setting_dict = yaml.safe_load(file.read())
            return flatten_dict(setting_dict)

    def write_data(self, data):
        pass
