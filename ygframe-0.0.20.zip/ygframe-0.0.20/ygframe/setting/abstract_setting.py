# -*- coding:utf-8 -*-
#
# Author:jing
# Copyright:yiguotech.com
# date:2018/05/06

# pylint:disable=missing-docstring
from ygframe import shared_memory
from ygframe.util.singleton import Singleton

__author__ = 'jing'

setting = shared_memory.dict()


class BaseSetting:
    def __getattribute__(self, name: str):
        if not name.startswith('_') and name.isupper():
            return setting.get(name)
        return super().__getattribute__(name)

    def __setattr__(self, key, value):
        if not key.startswith('_') and key.isupper():
            setting[key] = value
        return super().__setattr__(key, value)


class AbstractSetting(BaseSetting, metaclass=Singleton):
    def __init__(self) -> None:
        self.flatten_dict = {}

    def refresh_key(self, key, value, on_init=False):
        self.flatten_dict[key] = value
        upper_key = key.split('/')[-1].upper()
        old_value = getattr(self, upper_key, None)
        setattr(self, upper_key, value)
        if value != old_value and not on_init:
            self.after_refresh_key(upper_key, old_value, value)

    def refresh(self, data: dict, on_init=False):
        for key, value in data.items():
            self.refresh_key(key, value, on_init)
        if not on_init:
            self.after_refresh(data)

    def after_refresh(self, data: dict):
        pass

    def after_refresh_key(self, key, old_value, value):
        pass
