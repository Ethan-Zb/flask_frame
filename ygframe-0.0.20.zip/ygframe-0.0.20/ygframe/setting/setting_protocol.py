# -*- coding:utf-8 -*-
#
# Author:jing
# Copyright:yiguotech.com
# date:2018/05/06

# pylint:disable=missing-docstring
from ygframe.util.ensure import ensure_bytes, ensure_str

__author__ = 'jing'

SPECIAL_VALUES = {'None': None, 'True': True, 'False': False}


def _is_special_value(value: str) -> bool:
    if value in SPECIAL_VALUES:
        return True
    if isinstance(value, str):
        if len(value) >= 2 and value[0] == '"' and value[-1] == '"':
            return True
        try:
            int(value)
            return True
        except ValueError:
            try:
                float(value)
                return True
            except ValueError:
                pass

    return False


def resolve_upload_value(value) -> bytes:
    if _is_special_value(value):
        value = '"{}"'.format(value)
    return ensure_bytes(value)


def resolve_download_value(value):
    value = ensure_str(value)
    if len(value) >= 2 and value[0] == '"' and value[-1] == '"':
        value = value[1:-1]
    else:
        if value in SPECIAL_VALUES:
            return SPECIAL_VALUES.get(value)
        if '.' in value:
            try:
                return float(value)
            except ValueError:
                pass
        else:
            try:
                return int(value)
            except ValueError:
                pass
    return value
