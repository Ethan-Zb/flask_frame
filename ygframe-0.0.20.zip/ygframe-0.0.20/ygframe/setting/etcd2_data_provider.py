# -*- coding:utf-8 -*-
#
# Author:jing
# Copyright:yiguotech.com
# date:2018/05/06

# pylint:disable=missing-docstring
import etcd
import yaml

from ygframe.logger import logger
from ygframe.setting.data_provider import DataProvider
from ygframe.setting.setting_protocol import resolve_upload_value, resolve_download_value
from ygframe.util.dict_util import flatten_dict

__author__ = 'jing'


class Etcd2DataProvider(DataProvider):
    def __init__(self, etcd_client, meta_file) -> None:
        self.key_list = self._get_key_list(meta_file)
        self.client = etcd_client

    @classmethod
    def _get_key_list(cls, meta_file: str):
        with open(meta_file) as file:
            setting_dict = yaml.safe_load(file.read())
            return flatten_dict(setting_dict).keys()

    def read_data(self):
        result = {}
        for key in self.key_list:
            try:
                value = self.client.get(key).value
                result[key] = resolve_download_value(value)
            except Exception: #pylint:disable=broad-except
                logger.exception('read key from etcd error, key: {}'.format(key))
        return result

    def write_data(self, data):
        for key, value in data.items():
            value = resolve_upload_value(value)
            try:
                self.client.write(key, value, prevExist=False)
            except etcd.EtcdAlreadyExist:
                pass
            except Exception: #pylint:disable=broad-except
                logger.exception('write key to etcd error, key: {}'.format(key))
