# -*- coding:utf-8 -*-
# File Name:setting_decorator.py
# Author:jing
# Copyright:yiguotech.com
# date:2018/10/26

"""
setting decorator
"""
from ygframe.task.task_manager import CoreTaskManager

from ygframe.globals.abstract_globals import AbstractGlobals

from ygframe.setting import setting_initializer

__author__ = 'jing'


def with_init_setting(func):
    """
    :param func: method be decorated
    :return: decorate target of sub process so that SETTING can be refreshed
    """

    def _dec(*args, **kwargs):
        setting_initializer.init_default(AbstractGlobals().debug)
        CoreTaskManager.start('etcd_beat')
        func(*args, **kwargs)

    return _dec
