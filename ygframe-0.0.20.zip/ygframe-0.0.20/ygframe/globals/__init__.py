# -*- coding:utf-8 -*-
#
# Author:jing
# Copyright:yiguotech.com
# date:2018/05/06

"""
provide base class of GLOBALS
"""
__author__ = 'jing'
