# -*- coding:utf-8 -*-
#
# Author:jing
# Copyright:yiguotech.com
# date:2018/05/06

"""
base class of GLOBALS
"""
import os

from ygframe import SYSTEM_CONFIG

__author__ = 'jing'


class AbstractGlobals:  # pylint:disable=missing-docstring,too-few-public-methods
    @property
    def debug(self) -> bool:
        debug_mode = os.environ.get(SYSTEM_CONFIG.DEBUG_MODE_ENV_KEY, '0')
        return debug_mode.lower() not in ['', '0', 'false', 'off']
