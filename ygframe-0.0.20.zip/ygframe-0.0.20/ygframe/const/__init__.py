# -*- coding:utf-8 -*-
#
# Author:jing
# Copyright:yiguotech.com
# date:2018/05/06

"""
provide common const
"""
from ygframe import SYSTEM_CONFIG

__author__ = 'jing'


def get_const_system_name():
    try:
        const_model = __import__(SYSTEM_CONFIG.CONST_MODULE_NAME)
        return const_model.CONST.SYSTEM_NAME
    except:
        return None


def get_const_subsystem_name():
    try:
        const_model = __import__(SYSTEM_CONFIG.CONST_MODULE_NAME)
        return const_model.CONST.SUBSYSTEM_NAME  # type:str
    except:
        return None
