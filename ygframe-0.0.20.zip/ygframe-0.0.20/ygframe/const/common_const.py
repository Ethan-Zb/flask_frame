# -*- coding:utf-8 -*-
#
# Author:jing
# Copyright:yiguotech.com
# date:2018/05/06

"""
base class of Const
"""
__author__ = 'jing'


class CommonConst:  # pylint: disable=too-few-public-methods
    """
    base class of Const
    """

    def __setattr__(self, *_):
        raise ValueError('Trying to change a constant value')

    # yiguo standard http response
    RESULT = 'result'
    SUCCESS = 'success'
    FAILURE = 'failure'
    ERROR_CODE = 'error_code'
    REASON = 'reason'

    # seconds
    HOUR_SECONDS = 3600
    DAY_SECONDS = 86400
    MONTH_SECONDS = 2592000

    # encode
    UTF8 = 'utf-8'

    # content_type
    CONTENT_TYPE_JSON = 'application/json'

    # yg validation
    SESSION_TOKEN = 'ygtoken'
    SID = 'sid'
    SESSION_ID = 'sessionid'
    PERMISSION = 'permission'

    # celery
    CELERY_DUMMY_TERMINATOR = '===cElErY@DuMmy#tErmiNaTor==='
