# -*- coding:utf-8 -*-
"""
--------------------------------------------
File Name:base_meta_handler.py
Author:jing
Copyright:yiguotech.com
date:2018/07/19
--------------------------------------------
"""
from abc import abstractmethod

__author__ = 'jing'


class BaseMetaHandler(object):
    @abstractmethod
    def increase(self, value: int = 1) -> int:
        raise NotImplemented

    @abstractmethod
    def reset(self, value: int = 0):
        raise NotImplemented

    @abstractmethod
    def get(self) -> int:
        raise NotImplemented

    @abstractmethod
    def expire(self, ex: int):
        raise NotImplemented

    @abstractmethod
    def exist(self) -> bool:
        raise NotImplemented
