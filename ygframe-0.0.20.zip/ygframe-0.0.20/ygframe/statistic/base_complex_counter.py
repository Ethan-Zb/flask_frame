# -*- coding:utf-8 -*-
"""
--------------------------------------------
File Name:base_complex_counter.py
Author:jing
Copyright:yiguotech.com
date:2018/06/25
--------------------------------------------
"""
from ygframe.statistic.base_counter_item import BaseCounterItem
from ygframe.statistic.statistic_handler import StatisticHandler

__author__ = 'jing'


class BaseComplexCounter(StatisticHandler):
    def increase(self, *args, **kwargs):
        pass

    def __init__(self, *counter_items):
        self.counter_items = list(counter_items)

    def register(self, counter_item: BaseCounterItem):
        self.counter_items.append(counter_item)

    def count(self, data: dict):
        for counter_item in self.counter_items:
            counter_item.save(data)

    def get_values(self, key_data: dict):
        result = {}
        for counter_item in self.counter_items:
            if counter_item.match(key_data):
                result[counter_item.get_key()] = counter_item.get(key_data)
        return result

    def reset(self, counter_key: str, values: dict):
        pass

    def get_status(self) -> str:
        pass

    def get_description(self) -> str:
        pass

    def get_handle_key(self) -> str:
        pass
