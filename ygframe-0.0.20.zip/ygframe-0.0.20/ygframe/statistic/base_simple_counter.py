# -*- coding:utf-8 -*-
"""
--------------------------------------------
File Name:base_simple_count.py
Author:jing
Copyright:yiguotech.com
date:2018/05/02
--------------------------------------------
"""
import time
from abc import abstractmethod

from ygframe.const.common_const import CommonConst
from ygframe.statistic.base_meta_handler import BaseMetaHandler
from ygframe.statistic.statistic_handler import StatisticHandler

__author__ = 'jing'


class TsStrategy(object):

    def __init__(self, interval: int, max_record: int) -> None:
        self.interval = interval
        self.max_record = max_record

    def _get_suffix(self, ts: int = None) -> str:
        if not ts:
            now = int(time.time())
            ts = now - now % self.interval
        return "{}-{}".format(ts, self.interval)

    def get_description(self):
        if not self.interval:
            return 'no interval set'
        if self.interval % CommonConst.MONTH_SECONDS == 0:
            return '{} months'.format(self.interval / CommonConst.MONTH_SECONDS)
        if self.interval % CommonConst.DAY_SECONDS == 0:
            return '{} days'.format(self.interval / CommonConst.DAY_SECONDS)
        if self.interval % 3600 == 0:
            return '{} hours'.format(self.interval / 3600)
        if self.interval % 60 == 0:
            return '{} minutes'.format(self.interval / 60)
        return '{} seconds'.format(self.interval)

    def get_key(self, key, ts: int = None) -> str:
        return '{}_{}'.format(key, self._get_suffix(ts))

    def get_ts_keys(self, key) -> dict:
        result = {}
        now = int(time.time())
        for i in range(self.max_record):
            ts = now - now % self.interval - i * self.interval
            result[ts] = self.get_key(key, ts)
        return result

    def get_ttl(self) -> int:
        return self.interval * (self.max_record + 1)


class BaseSimpleCounter(StatisticHandler):
    def __init__(
            self,
            key: str = None,
            with_h: int = 0,
            with_d: int = 0,
            other_ts_strategies=None
    ) -> None:
        """
        注意：由于抽象方法所需数据可能需要子类提供，因此在继承时需要先初始化子类，再调用父类
        :param key:
        :param with_h:
        :param with_d:
        :param other_ts_strategies:
        """
        self.key = key
        self.strategies = []
        if with_h:
            self.strategies.append(TsStrategy(CommonConst.HOUR_SECONDS, with_h))
        if with_d:
            self.strategies.append(TsStrategy(CommonConst.DAY_SECONDS, with_d))
        if other_ts_strategies:
            self.strategies.extend(other_ts_strategies)

        self.current = None
        self.last_reset_handler = None

    def lazy_init(self, key):
        self.current = self.get_meta_handler(self.key)
        self.last_reset_handler = self.get_meta_handler(self.key + '_reset_ts')
        if not self.last_reset_handler.exist():
            self.last_reset_handler.reset(int(time.time()))

    def get_status(self) -> str:
        return '{} count up to  {} from {}'.format(
            self.key,
            self.current.get(),
            self.last_reset_handler.get(),
        )

    def increase(self, value: int = 1) -> int:
        for strategy in self.strategies:
            handler = self.get_meta_handler(strategy.get_key(self.key))
            handler.increase(value)
            handler.expire(strategy.get_ttl())
        return self.current.increase(value)

    def reset(self, init_value: int = 0) -> int:
        for strategy in self.strategies:
            handler = self.get_meta_handler(strategy.get_key(self.key))
            handler.reset(init_value)
            handler.expire(strategy.get_ttl())
        self.current.reset(init_value)
        return self.last_reset_handler.reset(int(time.time()))

    def get(self) -> int:
        return self.current.get()

    def get_details(self) -> dict:
        result = {}
        for strategy in self.strategies:
            ts_dict = {}
            result[strategy.get_description()] = ts_dict
            for ts, key in strategy.get_ts_keys(self.key).items():
                ts_dict[ts] = self.get_meta_handler(key).get()
        result['current'] = self.current.get()
        result['last_reset_at'] = self.last_reset_handler.get()

        return result

    def get_description(self) -> str:
        return 'count {}'.format(self.key)

    def get_handle_key(self) -> str:
        return self.key

    @abstractmethod
    def get_meta_handler(self, key) -> BaseMetaHandler:
        pass
