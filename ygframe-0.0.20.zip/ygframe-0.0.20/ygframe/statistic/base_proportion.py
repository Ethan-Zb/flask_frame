# -*- coding:utf-8 -*-
"""
--------------------------------------------
File Name:base_proportion.py
Author:jing
Copyright:yiguotech.com
date:2018/07/23
--------------------------------------------
"""
import time
from abc import abstractmethod

from ygframe.statistic.base_meta_handler import BaseMetaHandler
from ygframe.statistic.base_simple_counter import BaseSimpleCounter
from ygframe.statistic.statistic_handler import StatisticHandler

__author__ = 'jing'


class BaseSimpleProportion(StatisticHandler):

    def __init__(self, key: str, counters: list) -> None:
        self.key = key
        self.counters = counters
        self.last_reset_handler = self.get_meta_handler(key + '_reset_ts')

    def get_details(self):
        total_details = {'current': []}
        counter_len = len(self.counters)
        for counter in self.counters:
            if not isinstance(counter, BaseSimpleCounter):
                continue
            details = counter.get_details()
            for key, value in details.items():
                if key == 'current':
                    total_details['current'].append(value)
                elif isinstance(value, dict):
                    total_dict = total_details.setdefault(key, {})  # type:dict
                    for vk, vv in value.items():
                        vv_dict = total_dict.setdefault(vk, {})  # ensure_get(total_dict, vk, dict)
                        vvv_list = vv_dict.setdefault('values', [])  # ensure_get(vv_dict, 'values', list)
                        vvv_list.append(vv if vv else 0.0)
                        if len(vvv_list) == counter_len:
                            self._proportion(vv_dict, vvv_list)
        total_details['last_reset_at'] = self.last_reset_handler.get()
        return total_details

    def _proportion(self, target_dict, target_list):
        for index, counter in enumerate(self.counters):
            value = target_list[index]
            if isinstance(counter, BaseSimpleCounter):
                target_dict[counter.get_handle_key()] = [
                    item / value if value else 0.0
                    for item in target_list
                ]

    def reset(self, *args, **kwargs):
        self.last_reset_handler.reset(int(time.time()))

    def increase(self, *args, **kwargs):
        raise NotImplemented

    def get_status(self) -> str:
        return ''  # todo

    def get_description(self) -> str:
        return ''  # todo

    def get_handle_key(self) -> str:
        return ''  # todo

    @abstractmethod
    def get_meta_handler(self, key) -> BaseMetaHandler:
        pass
