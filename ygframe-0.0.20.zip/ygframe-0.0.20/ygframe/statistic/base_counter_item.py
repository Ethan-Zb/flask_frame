# -*- coding:utf-8 -*-
"""
--------------------------------------------
File Name:base_counter_item.py
Author:jing
Copyright:yiguotech.com
date:2018/06/25
--------------------------------------------
"""
__author__ = 'jing'


class BaseCounterItem(object):

    def get_key(self) -> str:
        pass

    def save(self, data: dict):
        pass

    def match(self, key_data: dict) -> bool:
        pass

    def get(self, key_data: dict) -> dict:
        pass
