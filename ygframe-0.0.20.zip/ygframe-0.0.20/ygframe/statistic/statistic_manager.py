# -*- coding:utf-8 -*-
"""
--------------------------------------------
File Name:statistic_manager.py
Author:jing
Copyright:yiguotech.com
date:2018/04/27
--------------------------------------------
"""
from ygframe.interface.manager_interface import ManagerInterface
from ygframe.statistic.base_simple_counter import BaseSimpleCounter

__author__ = 'jing'


class BaseStatisticManager(ManagerInterface):
    __url_key__ = 'statistic'

    @classmethod
    def reset(cls):
        for key, handler in cls.get_handler_dict().items():
            if not isinstance(handler, BaseSimpleCounter):
                pass
            handler.reset()

    @classmethod
    def get(cls):
        lines = []
        for key, handler in cls.get_handler_dict().items():
            if not isinstance(handler, BaseSimpleCounter):
                continue
            lines.append('{}==>{}'.format(key, handler.get()))
        return '\n'.join(lines)

    @classmethod
    def get_details(cls):
        lines = []
        for key, handler in cls.get_handler_dict().items():
            if not isinstance(handler, BaseSimpleCounter):
                continue
            lines.append('{}==>{}'.format(key, handler.get_details()))

        return '\n'.join(lines)
