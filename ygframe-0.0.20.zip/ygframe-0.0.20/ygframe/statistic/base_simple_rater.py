# -*- coding:utf-8 -*-
"""
--------------------------------------------
File Name:base_simple_rater.py
Author:jing
Copyright:yiguotech.com
date:2018/05/03
--------------------------------------------
"""
from ygframe.statistic.statistic_handler import StatisticHandler
from ygframe.statistic.base_simple_counter import BaseSimpleCounter

__author__ = 'jing'


class BaseSimpleRater(StatisticHandler):
    def __init__(self, key) -> None:
        self.key = key
        self.value_counter = self._get_counter(key)
        self.counter_counter = self._get_counter('{}_rate_counter'.format(key))

    def rate(self, value=1, counter=1) -> float:
        value_total = self.value_counter.increase(value)
        counter_total = self.counter_counter.increase(counter)
        return value_total / counter_total if counter_total > 0 else 0.0

    def reset(self, init_value=0, init_counter=0):
        self.value_counter.reset(init_value)
        self.counter_counter.reset(init_counter)

    def get(self):
        value_total = self.value_counter.get()
        counter_total = self.counter_counter.get()
        return value_total / counter_total if counter_total > 0 else 0.0

    def get_status(self):
        return 'rate counter {} count up to {}/{} from {}'.format(
            self.key, self.value_counter.get(), self.counter_counter.get(), self._get_last_rest_ts()
        )

    def _get_counter(self, key) -> BaseSimpleCounter:
        pass

    def get_description(self):
        pass

    def get_handle_key(self):
        return self.key

    def _get_last_rest_ts(self):
        pass
