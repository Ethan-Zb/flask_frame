# -*- coding:utf-8 -*-
"""
--------------------------------------------
File Name:statistic_handler.py
Author:jing
Copyright:yiguotech.com
date:2018/04/27
--------------------------------------------
"""
from abc import abstractmethod

from ygframe.interface.handler_interface import HandlerInterface

__author__ = 'jing'


class StatisticHandler(HandlerInterface):

    @abstractmethod
    def increase(self, *args, **kwargs):
        raise NotImplemented

    @abstractmethod
    def reset(self, *args, **kwargs):
        raise NotImplemented
