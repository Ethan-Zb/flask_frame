# -*- coding:utf-8 -*-
"""
--------------------------------------------
File Name:queue_manager.py
Author:jing
Copyright:yiguotech.com
date:2018/05/03
--------------------------------------------
"""
from ygframe.interface.manager_interface import ManagerInterface

__author__ = 'jing'


class BaseQueueManager(ManagerInterface):
    __url_key__ = 'queues'
