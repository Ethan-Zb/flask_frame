# -*- coding:utf-8 -*-
"""
--------------------------------------------
File Name:__init__.py.py
Author:jing
Copyright:yiguotech.com
date:2018/05/03
--------------------------------------------
"""
from ygframe.scope.scope import Scope

__author__ = 'jing'


def get_package_result_queue_name(key: str = None):
    name = Scope.get_scope_name(Scope.SUBSYSTEM)
    key = '_{}'.format(key) if key else ''
    return '{}{}_package_result'.format(name, key)
