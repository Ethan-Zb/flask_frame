# -*- coding:utf-8 -*-
"""
--------------------------------------------
File Name:queue_handler.py
Author:jing
Copyright:yiguotech.com
date:2018/05/03
--------------------------------------------
"""
from abc import abstractmethod

from ygframe.interface.handler_interface import HandlerInterface

__author__ = 'jing'


class QueueHandler(HandlerInterface):

    @abstractmethod
    def clear(self):
        pass

    @abstractmethod
    def empty(self) -> bool:
        pass

    @abstractmethod
    def full(self) -> bool:
        pass

    @abstractmethod
    def put(self, *args, **kwargs):
        pass

    @abstractmethod
    def get(self, *args, **kwargs):
        pass
