# -*- coding:utf-8 -*-
"""
--------------------------------------------
File Name:es_update_util.py
Author:jing
Copyright:yiguotech.com
date:2018/09/03
--------------------------------------------
"""
import json

from ygframe.es_wrapper import MAX_LIST_LEN, MAX_DICT_KEYS, MAX_FIELD_SIZE
from ygframe.logger import logger

__author__ = 'jing'


def update_list(ori_list, item, limit=MAX_LIST_LEN, multi=False):
    if limit and len(ori_list) > limit:
        logger.warning('len of list reached {} while limit is {}'.format(len(ori_list), MAX_LIST_LEN))
    elif multi or item not in ori_list:
        ori_list.append(item)


def update_dict(ori_dict, item, keys_limit=MAX_DICT_KEYS, size_limit=MAX_FIELD_SIZE):
    added_size = len(json.dumps(ori_dict)) + len(json.dumps(item))  # performance issue
    if size_limit and added_size > size_limit:
        logger.warning('len of field reached {} while limit is {}'.format(added_size, size_limit))
    elif keys_limit and len(ori_dict) > keys_limit:
        logger.warning('size of keys reached {} while limit is {}'.format(len(ori_dict), keys_limit))
    else:
        ori_dict.update(item)
    return ori_dict
