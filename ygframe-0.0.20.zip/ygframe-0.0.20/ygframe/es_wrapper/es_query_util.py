# -*- coding:utf-8 -*-
"""
--------------------------------------------
File Name:es_query_util.py
Author:jing
Copyright:yiguotech.com
date:2018/08/08
--------------------------------------------
"""
__author__ = 'jing'


def get_kwargs(args, kwargs):
    if len(args) == 1 and not kwargs:
        return args[0]
    return kwargs


class Key(object):

    def __init__(self, key: str) -> None:
        self.key = key

    def __eq__(self, value: object):
        return {'term': {self.key: value}}

    def in_(self, items):
        return {'terms': {self.key: items}}

    def prefix(self, value):
        return {'prefix': {self.key: value}}

    def __lt__(self, other):
        self.lt = other
        return self

    def __gt__(self, other):
        self.gt = other
        return self

    def __le__(self, other):
        self.lte = other
        return self

    def __ge__(self, other):
        self.gte = other
        return self

    def range(self):
        return {
            'range': {
                self.key: {
                    op: getattr(self, op)
                    for op in ['lt', 'gt', 'lte', 'gte']
                    if hasattr(self, op)
                }
            }
        }


def _resolve_range(items):
    return [item if not isinstance(item, Key) else item.range() for item in items]


def and_(*_):
    return {
        'bool': {
            'must': _resolve_range(_)
        }
    }


def or_(*_):
    return {
        'bool': {
            'should': _resolve_range(_)
        }
    }


def not_(q):
    return {
        'not': q
    }


def desc(key):
    return {
        key: 'desc'
    }


def asc(key):
    return {
        key: 'asc'
    }


def make_query(flt, **kwargs):
    query_json = {'query': flt}
    if kwargs:
        query_json.update(kwargs)
    return query_json


def get_source(result):
    return [_['_source'] for _ in result['hits']['hits']]
