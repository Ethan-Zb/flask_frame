# -*- coding:utf-8 -*-
"""
--------------------------------------------
File Name:es_initializer.py
Author:jing
Copyright:yiguotech.com
date:2018/08/08
--------------------------------------------
"""
from elasticsearch5 import Elasticsearch

from ygframe import es_wrapper

__author__ = 'jing'


def init(*hosts):
    es_wrapper.__es_client = Elasticsearch(hosts=hosts)
    return es_wrapper.__es_client
