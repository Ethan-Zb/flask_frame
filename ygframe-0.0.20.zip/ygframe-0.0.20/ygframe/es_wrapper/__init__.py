# -*- coding:utf-8 -*-
"""
--------------------------------------------
File Name:__init__.py.py
Author:jing
Copyright:yiguotech.com
date:2018/08/08
--------------------------------------------
"""
from elasticsearch5 import Elasticsearch
from elasticsearch5.client import CatClient

from ygframe.util.precondition import not_none

__author__ = 'jing'

__es_client = None
MAX_LIST_LEN = 1000
MAX_DICT_KEYS = 1000
MAX_FIELD_SIZE = 1 << 14

SOURCE = '_source'


# noinspection PyTypeChecker
def get_client() -> Elasticsearch:
    return not_none(__es_client)


def get_cat():
    return CatClient(get_client())
