# -*- coding:utf-8 -*-
"""
--------------------------------------------
File Name:es_util.py
Author:jing
Copyright:yiguotech.com
date:2018/08/09
--------------------------------------------
"""
from contextlib import contextmanager

from elasticsearch5 import helpers
from elasticsearch5.helpers import expand_action

from ygframe import es_wrapper
from ygframe.es_wrapper import SOURCE

__author__ = 'jing'


class EsUtil(object):
    def __init__(self, _index, _doc_type) -> None:
        self._index = _index
        self._doc_type = _doc_type

    def bulk_upsert(self, generator, stats_only=False, chunk_size=500, max_chunk_bytes=100 * 1024 * 1024,
                    raise_on_error=True, expand_action_callback=expand_action,
                    raise_on_exception=True, max_retries=0, initial_backoff=2,
                    max_backoff=600, yield_ok=True, **kwargs):
        return helpers.bulk(
            es_wrapper.get_client(),
            self._actions(generator),
            stats_only=stats_only,
            chunk_size=chunk_size,
            max_chunk_bytes=max_chunk_bytes,
            raise_on_error=raise_on_error,
            expand_action_callback=expand_action_callback,
            raise_on_exception=raise_on_exception,
            max_retries=max_retries,
            initial_backoff=initial_backoff,
            max_backoff=max_backoff,
            yield_ok=yield_ok,
            **kwargs)

    def search(
            self,
            body,
            from_=0,
            size=20,
            **kwargs
    ):
        """
                Execute a search query and get back search hits that match the query.
                `<http://www.elastic.co/guide/en/elasticsearch/reference/current/search-search.html>`_

                :param _source: True or false to return the _source field or not, or a
                    list of fields to return
                :param size:  Number of hits to return (default: 10)
                :param body: The search definition using the Query DSL
                :param from_: offset
                :arg _source_exclude: A list of fields to exclude from the returned
                    _source field
                :arg _source_include: A list of fields to extract and return from the
                    _source field
                :arg allow_no_indices: Whether to ignore if a wildcard indices
                    expression resolves into no concrete indices. (This includes `_all`
                    string or when no indices have been specified)
                :arg analyze_wildcard: Specify whether wildcard and prefix queries
                    should be analyzed (default: false)
                :arg analyzer: The analyzer to use for the query string
                :arg batched_reduce_size: The number of shard results that should be
                    reduced at once on the coordinating node. This value should be used
                    as a protection mechanism to reduce the memory overhead per search
                    request if the potential number of shards in the request can be
                    large., default 512
                :arg default_operator: The default operator for query string query (AND
                    or OR), default 'OR', valid choices are: 'AND', 'OR'
                :arg df: The field to use as default where no field prefix is given in
                    the query string
                :arg docvalue_fields: A comma-separated list of fields to return as the
                    docvalue representation of a field for each hit
                :arg expand_wildcards: Whether to expand wildcard expression to concrete
                    indices that are open, closed or both., default 'open', valid
                    choices are: 'open', 'closed', 'none', 'all'
                :arg explain: Specify whether to return detailed information about score
                    computation as part of a hit
                :arg fielddata_fields: A comma-separated list of fields to return as the
                    docvalue representation of a field for each hit
                :arg ignore_unavailable: Whether specified concrete indices should be
                    ignored when unavailable (missing or closed)
                :arg lenient: Specify whether format-based query failures (such as
                    providing text to a numeric field) should be ignored
                :arg lowercase_expanded_terms: Specify whether query terms should be
                    lowercased
                :arg pre_filter_shard_size: A threshold that enforces a pre-filter
                    roundtrip to prefilter search shards based on query rewriting if
                    the number of shards the search request expands to exceeds the
                    threshold. This filter roundtrip can limit the number of shards
                    significantly if for instance a shard can not match any documents based
                    on it's rewrite method ie. if date filters are mandatory to match
                    but the shard bounds and the query are disjoint. (default: 128)
                :arg preference: Specify the node or shard the operation should be
                    performed on (default: random)
                :arg q: Query in the Lucene query string syntax
                :arg request_cache: Specify if request cache should be used for this
                    request or not, defaults to index level setting
                :arg routing: A comma-separated list of specific routing values
                :arg scroll: Specify how long a consistent view of the index should be
                    maintained for scrolled search
                :arg search_type: Search operation type, valid choices are:
                    'query_then_fetch', 'dfs_query_then_fetch'
                :arg sort: A comma-separated list of <field>:<direction> pairs
                :arg stats: Specific 'tag' of the request for logging and statistical
                    purposes
                :arg stored_fields: A comma-separated list of stored fields to return as
                    part of a hit
                :arg suggest_field: Specify which field to use for suggestions
                :arg suggest_mode: Specify suggest mode, default 'missing', valid
                    choices are: 'missing', 'popular', 'always'
                :arg suggest_size: How many suggestions to return in response
                :arg suggest_text: The source text for which the suggestions should be
                    returned
                :arg terminate_after: The maximum number of documents to collect for
                    each shard, upon reaching which the query execution will terminate
                    early.
                :arg timeout: Explicit operation timeout
                :arg track_scores: Whether to calculate and return scores even if they
                    are not used for sorting
                :arg typed_keys: Specify whether aggregation and suggester names should
                    be prefixed by their respective types in the response
                :arg version: Specify whether to return document version as part of a
                    hit
                """
        return es_wrapper.get_client().search(index=self._index, doc_type=self._doc_type, body=body, from_=from_,
                                              size=size, **kwargs)

    @classmethod
    def scan(cls, query=None, scroll='5m', _index=None, _doc_type=None, raise_on_error=True,
             preserve_order=False, size=1000, request_timeout=None, clear_scroll=True,
             scroll_kwargs=None, **kwargs):
        return helpers.scan(
            es_wrapper.get_client(),
            query=query,
            scroll=scroll,
            index=_index,
            doc_type=_doc_type,
            raise_on_error=raise_on_error,
            preserve_order=preserve_order,
            size=size,
            request_timeout=request_timeout,
            clear_scroll=clear_scroll,
            scroll_kwargs=scroll_kwargs,
            **kwargs
        )

    def _actions(self, generator):
        for key, dict_item in generator:
            yield {
                '_index': self._index,
                '_type': self._doc_type,
                '_id': key,
                '_op_type': 'update',
                'doc': dict_item,
                'doc_as_upsert': True
            }

    # noinspection PyShadowingBuiltins
    @contextmanager
    def data_context(self, id, default=None):
        client = es_wrapper.get_client()
        if client.exists(self._index, self._doc_type, id):
            resp = client.get(self._index, doc_type=self._doc_type, id=id)
            source = resp.get(SOURCE)
        else:
            source = default or {}
        yield source
        client.index(self._index, self._doc_type, source, id)
