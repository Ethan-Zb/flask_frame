# -*- coding:utf-8 -*-
"""
--------------------------------------------
File Name:es_model.py
Author:jing
Copyright:yiguotech.com
date:2018/08/08
--------------------------------------------
"""
from abc import abstractmethod
from functools import lru_cache

from ygframe import es_wrapper
from ygframe.db import SortOrder, GetMode
from ygframe.db.filter import Filter, SimpleFilter, And, Or, Not, FilterOp
from ygframe.db.query import Query
from ygframe.db.abstract_model import AbstractModel
from ygframe.es_wrapper.es_query_util import get_source
from ygframe.scope.scope import Scope
from ygframe.util.str_util import get_snake_case

__author__ = 'jing'


class AbstractEsModel(AbstractModel):
    __index_name__ = None
    __doc_type__ = None

    @classmethod
    @lru_cache()
    def _get_op(cls, op):
        return {
            FilterOp.EQUAL: 'term',
            FilterOp.NOT_EQUAL: '#',
            FilterOp.IN: 'terms',
            FilterOp.NOT_IN: '#',
            FilterOp.EXIST: 'exists',
            FilterOp.GREATER_THAN: 'gt',
            FilterOp.GREATER_OR_EQUAL: 'gte',
            FilterOp.LESS_THAN: 'lt',
            FilterOp.LESS_OR_EQUAL: 'lte',
            FilterOp.AND: 'must',
            FilterOp.OR: 'should',
            FilterOp.NOT: 'not',
            FilterOp.REGEX: 'regexp',
            FilterOp.CONTAINS: 'term',
            FilterOp.PREFIX: 'prefix'
        }.get(op)

    @classmethod
    def _not(cls, field, op, value):
        return {cls._get_op(FilterOp.NOT): cls._get_criteria(SimpleFilter(field, op, value))}

    @abstractmethod
    def get_id(self):
        return None

    @classmethod
    def _get_criteria(cls, flt: Filter):
        if isinstance(flt, SimpleFilter):
            if flt.op == FilterOp.EXIST:
                if flt.value:
                    return {cls._get_op(flt.op): {'field': flt.field}}
                else:
                    return cls._not(flt.field, flt.op, True)
            if flt.op in [FilterOp.GREATER_THAN, FilterOp.GREATER_OR_EQUAL, FilterOp.LESS_THAN, FilterOp.LESS_OR_EQUAL]:
                return {'range': {flt.field: {cls._get_op(flt.op): flt.value}}}
            if flt.op == FilterOp.NOT_EQUAL:
                return cls._not(flt.field, FilterOp.EQUAL, flt.value)
            if flt.op == FilterOp.NOT_IN:
                return cls._not(flt.field, FilterOp.IN, flt.value)
            return {cls._get_op(flt.op): {flt.field: flt.value}}
        if isinstance(flt, And):
            return {'bool': {cls._get_op(FilterOp.AND): [
                cls._get_criteria(f)
                for f in flt.filters
            ]}}
        if isinstance(flt, Or):
            return {'bool': {cls._get_op(FilterOp.OR): [
                cls._get_criteria(f)
                for f in flt.filters
            ]}}
        if isinstance(flt, Not):
            return {cls._get_op(FilterOp.NOT): cls._get_criteria(flt.flt)}

    @classmethod
    def _get_projection(cls, query):
        if query.query_:
            return query.query_
        else:
            return [column.key for column in cls.get_columns() if column not in query.exclude_]

    @classmethod
    def _get_sort(cls, sort_by):
        return {field: 'desc' if order == SortOrder.DESC else 'asc' for field, order in sort_by}

    @classmethod
    def get(cls, query: Query):
        query_criteria = cls._get_criteria(query.filter_)
        projection = cls._get_projection(query)
        sort = cls._get_sort(query.sort_by_)
        response = es_wrapper.get_client().search(
            index=cls.get_index_name(),
            doc_type=cls.get_doc_type(),
            body=dict(query=query_criteria, fields=projection, sort=sort),
            from_=query.page_num_ * query.page_size_,
            size=query.page_size_)
        result = get_source(response)
        if query.get_mode_ == GetMode.FIRST:
            if result:
                return cls.create(**result[0])
            else:
                return None
        else:
            return [cls.create(**obj) for obj in result]

    @classmethod
    def update(cls, query: Query, obj):
        es_wrapper.get_client().update(cls.__index_name__, cls.__doc_type__, **obj)

    @classmethod
    def delete(cls, query: Query):
        es_wrapper.get_client().delete(cls.__index_name__, cls.__doc_type__)

    def dumps(self):
        return self.__dict__

    def save(self):
        es_wrapper.get_client().index(self.__index_name__, self.__doc_type__, id=self.get_id(), body=self.dumps())

    @classmethod
    def save_all(cls, obj):
        pass

    @classmethod
    def get_index_name(cls):
        if not cls.__index_name__:
            cls.__index_name__ = Scope.get_system_name()
        return cls.__index_name__

    @classmethod
    def get_doc_type(cls):
        if not cls.__doc_type__:
            cls.__doc_type__ = get_snake_case(cls.__name__)
        return cls.__doc_type__
