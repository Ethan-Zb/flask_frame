# -*- coding:utf-8 -*-
"""
--------------------------------------------
File Name:proportion_control_manager.py
Author:jing
Copyright:yiguotech.com
date:2018/07/27
--------------------------------------------
"""
import time

from ygframe.logger import logger

from ygframe.feedback_controller.proportion_control_handler import ProportionControlHandler
from ygframe.interface.manager_interface import ManagerInterface
from ygframe.task.cyclic_task import CyclicTask
from ygframe.task.task_manager import CoreTaskManager

__author__ = 'jing'


class ProportionControlManager(ManagerInterface):

    @classmethod
    def register_trigger(cls):
        CoreTaskManager.register(CyclicTask(
            task=cls._start,
            cyclic_wait=10,
            handle_key='controller trigger'
        ))

    @classmethod
    def _start(cls):
        minute = int(time.time() / 60)
        for key, handler in cls.get_handler_dict().items():
            if not isinstance(handler, ProportionControlHandler):
                continue
            interval = handler.get_interval()
            if minute % interval == 0:
                logger.info('feedback controller {} updating...'.format(key))
                handler.update()
                logger.info('feedback controller {} updated.'.format(key))
