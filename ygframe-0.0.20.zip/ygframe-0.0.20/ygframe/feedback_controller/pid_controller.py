# -*- coding:utf-8 -*-
"""
--------------------------------------------
File Name:pid_controller.py
Author:jing
Copyright:yiguotech.com
date:2018/07/27
--------------------------------------------
"""
import time
from abc import abstractmethod

from ygframe.feedback_controller import FeedbackController

__author__ = 'jing'


class PidController(FeedbackController):
    def __init__(
            self,
            point: float,
            windup: float,
            kp: float = 0.2,
            ki: float = 0.0,
            kd: float = 0.0
    ) -> None:
        self.point = point
        self.windup = windup
        self.kp = kp
        self.ki = ki
        self.kd = kd

        # init
        self.last_time = time.time()
        self.last_error = 0.0
        self.i_term = 0.0

    def update(self):
        feedback = self.get_feed_back()
        error = self.point - feedback
        current = time.time()

        delta_time = current - self.last_time
        delta_error = error - self.last_error

        self.i_term += error * delta_time
        self.i_term = max(self.i_term, -self.windup)
        self.i_term = min(self.i_term, self.windup)

        d_term = delta_error / delta_time if delta_time else 0.0

        self.last_time = current
        self.last_error = error

        return self.kp * error + self.ki * self.i_term + self.kd * d_term

    @abstractmethod
    def get_feed_back(self):
        raise NotImplemented
