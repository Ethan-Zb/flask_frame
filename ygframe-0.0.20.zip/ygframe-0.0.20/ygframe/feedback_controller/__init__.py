# -*- coding:utf-8 -*-
"""
--------------------------------------------
File Name:__init__.py.py
Author:jing
Copyright:yiguotech.com
date:2018/07/27
--------------------------------------------
"""
from abc import abstractmethod


class FeedbackController(object):
    @abstractmethod
    def update(self):
        pass
