# -*- coding:utf-8 -*-
"""
--------------------------------------------
File Name:proportion_control_handler.py
Author:jing
Copyright:yiguotech.com
date:2018/07/28
--------------------------------------------
"""
from abc import abstractmethod

from ygframe.feedback_controller import FeedbackController
from ygframe.interface.handler_interface import HandlerInterface
from ygframe.util.float_util import BIG_FLOAT

__author__ = 'jing'


class ProportionControlHandler(FeedbackController, HandlerInterface):

    @classmethod
    def update(cls):
        current = cls.get_current()
        min_ignore_limit = cls.get_min_ignore_limit()
        max_ignore_limit = cls.get_max_ignore_limit()
        expect = (min_ignore_limit + max_ignore_limit) / 2
        if min_ignore_limit < current < max_ignore_limit:
            return
        if current < cls.get_min_current_limit():
            cls.on_reach_bottom(current)
            return
        if current > cls.get_max_current_limit():
            cls.on_reach_top(current)
            return

        error = expect - current
        cls.adjust(error)

    @classmethod
    @abstractmethod
    def on_reach_top(cls, current):
        raise NotImplemented

    @classmethod
    @abstractmethod
    def on_reach_bottom(cls, current):
        raise NotImplemented

    @classmethod
    @abstractmethod
    def adjust(cls, error: float):
        raise NotImplemented

    @classmethod
    @abstractmethod
    def get_current(cls):
        raise NotImplemented

    @classmethod
    def get_interval(cls) -> int:
        return 1

    @classmethod
    def get_min_current_limit(cls) -> float:
        return 0.0

    @classmethod
    def get_max_current_limit(cls) -> float:
        return BIG_FLOAT

    @classmethod
    def get_min_ignore_limit(cls) -> float:
        return 0.0

    @classmethod
    def get_max_ignore_limit(cls) -> float:
        return BIG_FLOAT

    @classmethod
    def get_max_controller_limit(cls) -> float:
        return BIG_FLOAT

    @classmethod
    def get_min_controller_limit(cls) -> float:
        return 0.0
