# -*- coding:utf-8 -*-
#
# Author:jing
# Copyright:yiguotech.com
# date:2018/05/06

# pylint:disable=invalid-name

"""
logger context
"""
import logging
import traceback
from functools import wraps

from ygframe.logger import logger
from ygframe.util import NotSet

__author__ = 'jing'


def _get_logger_method(level: int):
    return {
        logging.INFO: logger.info,
        logging.DEBUG: logger.debug,
        logging.WARNING: logger.warning,
        logging.ERROR: logger.error
    }.get(level, logger.error)


class _LogException:

    def __init__(  # pylint:disable=too-many-arguments
            self,
            decorated=None,
            level=logging.ERROR,
            exception=None,
            message='',
            default=NotSet,
    ) -> None:
        self.decorated = decorated
        self.message = message
        self.default = default
        self.level = level
        if not isinstance(exception, tuple):
            exception = (exception,) if exception else (Exception,)
        self.exception = exception

    def __call__(self, *args, **kwargs):
        if len(args) == 1 and callable(args[0]):
            func = args[0]

            @wraps(func)
            def _wrapper(*func_args, **func_kwargs):
                try:
                    return func(*func_args, **func_kwargs)
                except self.exception:
                    _get_logger_method(self.level)(self.message, exc_info=True)
                    if self.default is not NotSet:
                        return self.default

            return _wrapper
        if callable(self.decorated):
            try:
                return self.decorated(*args, **kwargs)
            except self.exception:
                _get_logger_method(self.level)(self.message, exc_info=True)
        return None

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        is_excepted = any([isinstance(exc_val, except_type) for except_type in self.exception])
        if is_excepted:
            _get_logger_method(self.level)('{} {}'.format(
                self.message,
                ''.join(traceback.format_exception(exc_type, exc_val, exc_tb))
            ))
        return is_excepted


class _DebugException:
    def __new__(
            cls,
            decorated=None,
            exception=None,
            message='',
            default=NotSet
    ):
        return _LogException(decorated, logging.DEBUG, exception, message, default)


class _InfoException:
    def __new__(
            cls,
            decorated=None,
            exception=None,
            message='',
            default=NotSet
    ):
        return _LogException(decorated, logging.INFO, exception, message, default)


class _WarningException:
    def __new__(
            cls,
            decorated=None,
            exception=None,
            message='',
            default=NotSet
    ):
        return _LogException(decorated, logging.WARNING, exception, message, default)


class _ErrorException:
    def __new__(
            cls,
            decorated=None,
            exception=None,
            message='',
            default=NotSet
    ):
        return _LogException(decorated, logging.ERROR, exception, message, default)


debug_exception = _DebugException
info_exception = _InfoException
warning_exception = _WarningException
error_exception = _ErrorException
