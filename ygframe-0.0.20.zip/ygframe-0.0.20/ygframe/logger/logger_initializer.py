# -*- coding:utf-8 -*-
#
# Author:jing
# Copyright:yiguotech.com
# date:2018/05/06

"""
logger initializer
"""
import os
from logging import config, basicConfig, getLogger, INFO

import yaml

from ygframe import SYSTEM_CONFIG
from ygframe.logger import logger, init_logger_level
from ygframe.scope.scope import Scope
from ygframe.util.file_util import ensure_file

__author__ = 'jing'


def init_default_logger(
        log_config_file: str = SYSTEM_CONFIG.LOGGER_CONFIG_FILE,
        env_key: str = SYSTEM_CONFIG.LOGGER_CONFIG_ENV_KEY,
):
    """
    :param log_config_file: file path of logger config
    :param env_key: by setting environment variable, you can set a file path
    params above provide a logger config file path.
    """
    init_logger_level()
    path = os.getenv(env_key, None) or log_config_file
    if os.path.exists(path):
        with open(path, 'r') as file:
            configuration = yaml.safe_load(file.read())
            _prepare_for(configuration)
        config.dictConfig(configuration)
    else:
        basicConfig(level=INFO)

    logger.initialize(getLogger(Scope.get_subsystem_full_name()))

    return logger


def _prepare_for(configuration: dict):
    """
    create file if file not exist
    :param configuration:
    :return:
    """
    for handler in configuration.get('handlers', {}).values():
        file_name = handler.get('filename')
        if file_name:
            ensure_file(file_name)
