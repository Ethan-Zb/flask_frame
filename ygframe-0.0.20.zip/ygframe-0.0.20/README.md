ygframe
author: jing

教程：
### 1、如何更新ygframe
https://gitee.com/ygshop/ygframe.git
从这里克隆项目，在项目的目录dist下有最新的包,通过命令
> pip install <ygframe_package_name> -U

来安装和更新包。如果版本有更新，注意同步更新requirements.txt文档及相关的docker文档。

### 2、如何配置环境变量
etcd参数环境变量：ETCD_SERVICE_SERVICE_HOST 和 ETCD_SERVICE_SERVICE_PORT
debug环境变量： DEBUG_MODE=1
debug环境变量解释：DEBUG_MODE=1标志位可能会影响一些功能，这些功能仅在开发阶段起作用，
在代码里通过
> if GLOBALS.debug：

来获取这个环境变量的值。
这个变量仅用于开发环境，不建议用于线上环境。

环境变量可以配置到机器上，也可以利用IDE的相关功能，在代码启动前加上。

### 3、如何理解Scope
ygframe里的Scope概念，用于命名空间的划分，保证两个模块之间公用资源时不会造成命名冲突。

这里的system_name和subsystem_name仅表示两层结构。subsystem_name对应最小的微服务
模块，system_name是多个共享相关资源（如hbase,mysql,队列）等的多个subsystem_name
对应模块的集合。更高层的划分建议放在system_name上用前缀加下划线进行标识

### 4、如何创建工程
ygframe提供了一套project_generator机制，用于生成相关的代码结构和范例。
建议代码的文件存放目录是<工作空间>/<system_name>/<subsystem_name>。（不强制要求）
如果项目目录下有文件内容，建议备份并清空。（暂不支持自动合并）
用临时Python代码文件或python交互命令行执行：
> from ygframe.dev_tool import project_generator
> project_generator.generate()

控制台交互会引导完成项目基本目录和基本范例的搭建。

### 5、目录结构说明

+ data: 所有代码运行时产生的数据文件
    + logs: 日志文件
+ doc: 文档
    + celery: celery接口文档
    + restful: restful接口文档
+ script: 脚本文件
+ src: 源码根目录（需要用IDE标记为源码目录）
    + api: restful api
        + v{version}: api版本
    + orm: 所有数据库的操作文件。
    + service： 其他代码文件。建议细分目录，并且将celery和API里的相关实现放到这里来
    + task:
        + celery_task: 当前system下的任务。任务所在文件的文件名是改任务实现所在的子系统名
        + celery_beat_task: 按照某种调度规则，周期性产生的celery任务
        + celery_external_task: 其他system下的任务。下层目录是system_name，
        再下一层规则与celery_task相同
        + cyclic_task: 周期调度的后台任务
        + instance_task: 只启动一次的后台任务
    + app.py 系统入口
    + config.yaml 配置文件
    + const.py 常量文件
    + globals.py 全局变量文件。（自动生成，需要在init中赋初始值）
    + initializer.py 启动文件
    + logger.yaml 日志配置文件
    + setting.py 配置类文件。（自动根据config.yaml生成）、
+ test
    + test_case: 所有测试用例
    + test_temp: 所有临时测试
    + test_main.py: 驱动test_case下所有TestCase的入口。会自动初始化环境。

### 6、初始化配置与启动。
创建好初始文件后，先查看config.yaml里的配置，修改相关参数。
在initializer.init方法中，为各个init_xxx方法添加其他参数。
注释掉暂时不启动的init_xxx行，在cyclic_task和instance_task中
注释掉不需要的后台任务。运行app.py，生成初始的setting，globals，和文档文件

### 7、为什么setting.py和globals.py是只读的，如果这两个文件意外损坏怎么办。
这两个文件的只读标记是因为这两个文件是自动生成的，不建议修改的。即使修改了，也有可能在
下次生成时被覆盖掉。
如果这两个文件出现意外无法通过编译的情况，可以删掉后，在src目录下运行
> from ygframe.dev_tool import setting_generator, globals_generator
> setting_generator.reset()
> globals_generator.reset()

这两个文件自带main方法可以单独更新。

### 8、为什么有些模型类的范例代码里会有main方法？
有些模型类的一些方法模板有大量重复的操作的，执行main
方法可以自动生成一些代码，用以节约程序员的时间，同时可以减少因为前后不一致导致代码bug
或代码可读性上的障碍

